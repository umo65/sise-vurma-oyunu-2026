/*
 * Android yama aracı testleri (Node). Çalıştır: node tests/android-patch.test.js
 *
 * Sabit dosyalar, @capacitor-community/admob demo projesinde bulunan GERÇEK Capacitor 8.5.2
 * şablonundan alınmıştır (AdMob satırları çıkarılmış hâli). Böylece yama, Capacitor'un
 * ürettiği gerçek biçime karşı sınanır. (APK derlemesinin kendisi bu ortamda yapılamaz.)
 */
const assert = require('assert');
const P = require('../tools/android-patch.js');

let passed = 0, failed = 0;
function test(name, fn) {
  try { fn(); passed++; console.log('  ok   ' + name); }
  catch (e) { failed++; console.log('  FAIL ' + name + '\n       ' + (e && e.message || e)); }
}

const MANIFEST = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/AppTheme">

        <activity
            android:exported="true"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode|navigation"
            android:name="io.ionic.starter.MainActivity"
            android:label="@string/title_activity_main"
            android:theme="@style/AppTheme.NoActionBarLaunch"
            android:launchMode="singleTask">

            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>

        </activity>

        <provider
            android:name="androidx.core.content.FileProvider"
            android:authorities="\${applicationId}.fileprovider"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/file_paths"></meta-data>
        </provider>
    </application>

    <!-- Permissions -->

    <uses-permission android:name="android.permission.INTERNET" />
</manifest>
`;

const STRINGS = `<?xml version='1.0' encoding='utf-8'?>
<resources>
    <string name="app_name">Şişe Vurma</string>
    <string name="title_activity_main">Şişe Vurma</string>
    <string name="package_name">com.example.sisevurma</string>
    <string name="custom_url_scheme">com.example.sisevurma</string>
</resources>
`;

/** Çok küçük bir "iyi biçimli XML" denetimi: etiketler dengeli mi? */
function wellFormed(xml) {
  const stack = [];
  const re = /<!--[\s\S]*?-->|<\?[\s\S]*?\?>|<\/([\w:.-]+)\s*>|<([\w:.-]+)((?:\s+[\w:.-]+\s*=\s*"[^"]*")*)\s*(\/?)>/g;
  let m, last = 0;
  while ((m = re.exec(xml))) {
    const gap = xml.slice(last, m.index);
    if (/[<>]/.test(gap)) return false;                       // yorum dışı kaçak '<' veya '>'
    last = re.lastIndex;
    if (m[1]) { if (stack.pop() !== m[1]) return false; }
    else if (m[2] && !m[4]) stack.push(m[2]);
  }
  return stack.length === 0 && !/[<>]/.test(xml.slice(last));
}

const APP_ID = 'ca-app-pub-3940256099942544~3347511713';

test('T0  sınama dosyaları kendi içinde iyi biçimli XML', () => {
  assert.ok(wellFormed(MANIFEST));
  assert.ok(wellFormed(STRINGS));
  assert.ok(!wellFormed(MANIFEST.replace('</application>', '')), 'denetleyici bozuk XML\'i yakalamalı');
});

test('T1  manifest: AdMob APPLICATION_ID <application> altına, tam bir kez eklenir', () => {
  const out = P.patchManifest(MANIFEST);
  const n = (out.match(/com\.google\.android\.gms\.ads\.APPLICATION_ID/g) || []).length;
  assert.strictEqual(n, 1);
  assert.ok(out.includes('android:value="@string/admob_app_id"'));
  assert.ok(out.indexOf('APPLICATION_ID') > out.indexOf('<application'));
  assert.ok(out.indexOf('APPLICATION_ID') < out.indexOf('<activity'), 'meta-data <application> içinde, activity\'den önce');
  assert.ok(wellFormed(out), 'yama sonrası XML bozulmamalı');
});

test('T2  manifest: MainActivity yatay kilitlenir, provider\'a dokunulmaz', () => {
  const out = P.patchManifest(MANIFEST);
  const act = out.match(/<activity\b[^>]*>/)[0];
  assert.ok(act.includes('android:screenOrientation="sensorLandscape"'));
  assert.ok(act.includes('android:name="io.ionic.starter.MainActivity"'), 'mevcut özellikler korunmalı');
  assert.ok(!/<provider[^>]*screenOrientation/.test(out));
  assert.ok(out.includes('<uses-permission android:name="android.permission.INTERNET" />'), 'INTERNET izni korunmalı');
});

test('T3  manifest: yama tekrar uygulanınca değişmez (idempotent)', () => {
  const once = P.patchManifest(MANIFEST);
  assert.strictEqual(P.patchManifest(once), once);
});

test('T4  manifest: ".MainActivity" kısa adıyla da çalışır; hazır screenOrientation ezilmez', () => {
  const short = MANIFEST.replace('io.ionic.starter.MainActivity', '.MainActivity');
  assert.ok(P.patchManifest(short).includes('sensorLandscape'));
  const custom = MANIFEST.replace('<activity', '<activity\n            android:screenOrientation="portrait"');
  const out = P.patchManifest(custom);
  assert.ok(out.includes('android:screenOrientation="portrait"') && !out.includes('sensorLandscape'));
});

test('T5  manifest: <application> ya da MainActivity yoksa anlaşılır hata verir', () => {
  assert.throws(() => P.patchManifest('<manifest></manifest>'), /<application>/);
  assert.throws(() => P.patchManifest(MANIFEST.replace(/MainActivity/g, 'Other')), /MainActivity/);
});

test('T6  strings.xml: admob_app_id eklenir, tekrar çalışınca güncellenir, çoğalmaz', () => {
  const a = P.patchStrings(STRINGS, APP_ID);
  assert.ok(a.includes('<string name="admob_app_id">' + APP_ID + '</string>'));
  assert.ok(wellFormed(a));
  const b = P.patchStrings(a, 'ca-app-pub-1234567890123456~1234567890');
  assert.strictEqual((b.match(/admob_app_id/g) || []).length, 1);
  assert.ok(b.includes('~1234567890<'));
  assert.ok(b.includes('Şişe Vurma'), 'Türkçe karakterler korunmalı');
});

test('T7  gerçek config okunur; test modunda Google örnek uygulama kimliği seçilir', () => {
  const cfg = P.readAdsConfig();
  assert.ok(cfg && cfg.admob);
  assert.strictEqual(cfg.admob.useTestAds, true, 'varsayılan: test reklamları');
  assert.strictEqual(P.pickAppId(cfg), APP_ID);
});

test('T8  kimlik denetimi: gerçek mod + boş kimlik, ya da yanlış biçim -> hata', () => {
  const base = { admob: { useTestAds: false, appId: { android: '' }, testAppId: { android: APP_ID } } };
  assert.throws(() => P.pickAppId(base), /appId\.android/);
  // reklam BİRİMİ kimliği ("/" içerir) uygulama kimliği yerine girilirse yakalanmalı
  const unit = { admob: { useTestAds: false, appId: { android: 'ca-app-pub-3940256099942544/5224354917' } } };
  assert.throws(() => P.pickAppId(unit), /biçimi yanlış/);
  const ok = { admob: { useTestAds: false, appId: { android: 'ca-app-pub-1234567890123456~1234567890' } } };
  assert.strictEqual(P.pickAppId(ok), 'ca-app-pub-1234567890123456~1234567890');
});

console.log('\n' + passed + ' geçti, ' + failed + ' kaldı');
process.exit(failed ? 1 : 0);
