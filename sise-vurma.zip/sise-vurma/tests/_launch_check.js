const { chromium } = require('/opt/npm-tools/node_modules/playwright');
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage();
  await p.setContent('<canvas id=c width=50 height=50></canvas>');
  console.log('chromium ok, canvas2d:', await p.evaluate(() => !!document.getElementById('c').getContext('2d')));
  await b.close();
})().catch(e => { console.error('LAUNCH FAIL', e.message); process.exit(1); });
