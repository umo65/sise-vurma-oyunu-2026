/* Çekirdek mantık testleri (Node). Çalıştır: node tests/core.test.js */
const assert = require('assert');
const path = require('path');
const load = (p) => require(path.join(__dirname, '..', p));

load('config/ads.config.js');
['util', 'storage', 'audio', 'state', 'shapes', 'levels', 'ads'].forEach((m) => load('src/core/' + m + '.js'));
const SV = globalThis.SV;

let passed = 0, failed = 0;
const pending = [];
function test(name, fn) {
  pending.push(Promise.resolve().then(fn).then(
    () => { passed++; console.log('  ok   ' + name); },
    (e) => { failed++; console.log('  FAIL ' + name + '\n       ' + (e && e.stack || e)); }
  ));
}
// Testleri sırayla çalıştır (Storage ortak olduğu için)
const queue = [];
function seq(name, fn) { queue.push([name, fn]); }
async function runAll() {
  for (const [name, fn] of queue) {
    try { await fn(); passed++; console.log('  ok   ' + name); }
    catch (e) { failed++; console.log('  FAIL ' + name + '\n       ' + (e && e.stack || e)); }
  }
}

const ORDER6 = ['red', 'blue', 'green', 'yellow', 'purple', 'orange'];
const newState = () => { const s = new SV.GameState({ rewardBalls: 3 }); s.startLevel(1, ORDER6); return s; };

/* ------------------------------ DURUM ------------------------------ */
seq('S1  oyun 2 top hakkıyla başlar', () => {
  const s = newState();
  assert.strictEqual(s.balls, 2); assert.strictEqual(s.maxBalls, 2); assert.strictEqual(s.status, 'playing');
});
seq('S2  yanlış atışta top azalır: 2 -> 1 -> 0', () => {
  const s = newState();
  assert.strictEqual(s.registerWrong().balls, 1);
  assert.strictEqual(s.status, 'playing');
  const r = s.registerWrong();
  assert.strictEqual(r.balls, 0); assert.strictEqual(r.outOfBalls, true);
  assert.strictEqual(s.status, 'outOfBalls');
});
seq('S3  doğru vuruş top hakkı harcamaz, puan verir, hedefi ilerletir', () => {
  const s = newState();
  const r = s.registerCorrect();
  assert.strictEqual(s.balls, 2); assert.strictEqual(r.points, 100); assert.strictEqual(s.score, 100);
  assert.strictEqual(s.target, 'blue'); assert.strictEqual(r.complete, false);
});
seq('S4  üst üste doğru vuruşta seri bonusu; yanlış seriyi sıfırlar', () => {
  const s = newState();
  assert.strictEqual(s.registerCorrect().points, 100);
  assert.strictEqual(s.registerCorrect().points, 125);
  assert.strictEqual(s.registerCorrect().points, 150);
  s.registerWrong();
  assert.strictEqual(s.registerCorrect().points, 100);
});
seq('S5  6 doğru vuruş bölümü bitirir, kalan top başına 50 bonus', () => {
  const s = newState();
  let last;
  for (let i = 0; i < 6; i++) last = s.registerCorrect();
  assert.strictEqual(last.complete, true); assert.strictEqual(last.bonus, 100);
  assert.strictEqual(s.status, 'levelComplete');
  assert.strictEqual(s.stars, 3);
  // bölüm bittikten sonra vuruş sayılmaz
  assert.strictEqual(s.registerCorrect(), null);
});
seq('S6  ödül: tam 3 top, yalnızca bir kez, yalnızca topsuzken', () => {
  const s = newState();
  assert.strictEqual(s.grantReward(), false, 'oyun sürerken ödül verilmemeli');
  s.registerWrong(); s.registerWrong();
  assert.strictEqual(s.grantReward(), true);
  assert.strictEqual(s.balls, 3); assert.strictEqual(s.maxBalls, 3); assert.strictEqual(s.status, 'playing');
  assert.strictEqual(s.grantReward(), false, 'ikinci kez verilmemeli');
  assert.strictEqual(s.balls, 3);
});
seq('S7  ödülden sonra yine biterse yeni bir ödül hakkı doğar', () => {
  const s = newState();
  s.registerWrong(); s.registerWrong(); s.grantReward();
  s.registerWrong(); s.registerWrong(); s.registerWrong();
  assert.strictEqual(s.status, 'outOfBalls');
  assert.strictEqual(s.grantReward(), true);
});
seq('S8  bölümü yeniden başlatma puanı ve topları sıfırlar', () => {
  const s = newState();
  s.registerCorrect(); s.registerCorrect(); s.registerWrong(); s.registerWrong();
  s.restartLevel();
  assert.strictEqual(s.score, 0); assert.strictEqual(s.balls, 2); assert.strictEqual(s.targetIndex, 0);
  assert.strictEqual(s.status, 'playing');
});
seq('S9  puan bölümler arasında birikir; yeniden başlatma bölüm başına döner', () => {
  const s = newState();
  for (let i = 0; i < 6; i++) s.registerCorrect();
  const afterL1 = s.score;
  s.startLevel(2, ORDER6);
  assert.strictEqual(s.levelStartScore, afterL1);
  s.registerCorrect();
  s.restartLevel();
  assert.strictEqual(s.score, afterL1);
});
seq('S10 yıldızlar hata sayısına göre', () => {
  const s = newState(); s.registerWrong();
  assert.strictEqual(s.stars, 2);
  s.registerWrong(); assert.strictEqual(s.stars, 1);
});

/* ------------------------------ BÖLÜMLER ------------------------------ */
seq('L1  1. bölüm: 6 şişe, tam olarak 6 farklı renk, sabit platform', () => {
  const L = SV.Levels.build(1, 1280);
  assert.strictEqual(L.bottles.length, 6);
  assert.deepStrictEqual(L.bottles.map((b) => b.colorId).sort(), ORDER6.slice().sort());
  assert.strictEqual(L.plats.length, 1); assert.strictEqual(L.plats[0].move, null);
});
seq('L2  her bölüm 6 şişe, benzersiz renk, hedef sırası permütasyon', () => {
  for (const W of [960, 1280, 1600]) for (let n = 1; n <= 40; n++) {
    const L = SV.Levels.build(n, W);
    assert.strictEqual(L.bottles.length, 6, 'n=' + n);
    const ids = L.bottles.map((b) => b.colorId);
    assert.strictEqual(new Set(ids).size, 6, 'n=' + n + ' renkler benzersiz olmalı');
    assert.deepStrictEqual(L.order.slice().sort(), ids.slice().sort());
  }
});
seq('L3  şişeler platform üzerinde, platformlar ekran içinde (hareket dahil)', () => {
  for (const W of [960, 1280, 1600]) for (let n = 1; n <= 40; n++) {
    const L = SV.Levels.build(n, W);
    L.plats.forEach((p, pi) => {
      const ax = p.move ? p.move.ax : 0;
      assert.ok(p.cx - p.w / 2 - ax >= SV.Levels.SLING.x + 60, `n=${n} W=${W} platform sapana çok yakın`);
      assert.ok(p.cx + p.w / 2 + ax <= W - 10, `n=${n} W=${W} platform ekran dışına taşıyor`);
      assert.ok(p.top - (p.move ? p.move.ay : 0) >= 200, `n=${n} platform HUD'a çok yakın`);
      assert.ok(p.top + (p.move ? p.move.ay : 0) < SV.Levels.GROUND_Y - 60);
    });
    L.bottles.forEach((b) => {
      const p = L.plats[b.platIndex];
      const half = SV.Shapes.width(b.shape, b.scale) / 2;
      assert.ok(Math.abs(b.ox) + half <= p.w / 2, `n=${n} şişe platform kenarından taşıyor`);
    });
    // Aynı platformdaki şişeler birbirine girmemeli
    L.plats.forEach((p, pi) => {
      const bs = L.bottles.filter((b) => b.platIndex === pi).sort((a, b) => a.ox - b.ox);
      for (let i = 1; i < bs.length; i++) {
        const gap = (bs[i].ox - bs[i - 1].ox) - (SV.Shapes.width(bs[i].shape, bs[i].scale) + SV.Shapes.width(bs[i - 1].shape, bs[i - 1].scale)) / 2;
        assert.ok(gap >= 8, `n=${n} W=${W} şişeler çakışıyor (boşluk ${gap.toFixed(1)})`);
      }
    });
  }
});
seq('L4  aynı bölüm numarası her zaman aynı düzeni verir', () => {
  assert.deepStrictEqual(SV.Levels.build(9, 1280), SV.Levels.build(9, 1280));
});
seq('L5  zorluk artar: hareketli platformlar var, nişan yardımı azalır', () => {
  const moving = [4, 5, 6].map((n) => SV.Levels.build(n, 1280).plats.some((p) => p.move));
  assert.deepStrictEqual(moving, [true, true, true]);
  assert.ok(SV.Levels.build(1, 1280).guide > SV.Levels.build(8, 1280).guide);
  assert.ok(SV.Levels.build(2, 1280).plats.length > 1, '2. bölüm farklı dizilişte olmalı');
});

/* ------------------------------ REKLAM ------------------------------ */
const mkCfg = (over) => ({
  provider: 'mock', allowQueryOverrides: false, rewardBalls: 3,
  mock: Object.assign({ loadDelayMs: 1, durationMs: 5, forceResult: null }, over && over.mock),
  admob: Object.assign({
    useTestAds: true,
    testRewardedAdUnitId: { android: 'TEST-UNIT' },
    rewardedAdUnitId: { android: '' }
  }, over && over.admob)
});
const presenterWith = (result) => ({ showMockAd: async () => result });

seq('A1  test reklamı tamamlanınca durum "rewarded"', async () => {
  const m = new SV.Ads.AdManager(mkCfg(), presenterWith('completed'));
  assert.strictEqual(m.providerName, 'mock');
  assert.strictEqual((await m.showRewarded()).status, 'rewarded');
});
seq('A2  reklam tamamlanmadan kapatılırsa "dismissed" (ödül yok)', async () => {
  const m = new SV.Ads.AdManager(mkCfg(), presenterWith('closed'));
  assert.strictEqual((await m.showRewarded()).status, 'dismissed');
});
seq('A3  yükleme hatası -> "failed" + mesaj; sonra tekrar deneme çalışır', async () => {
  const cfg = mkCfg({ mock: { forceResult: 'loadfail' } });
  const m = new SV.Ads.AdManager(cfg, presenterWith('completed'));
  const r1 = await m.showRewarded();
  assert.strictEqual(r1.status, 'failed'); assert.strictEqual(r1.stage, 'load');
  assert.ok(r1.error && r1.error.length > 5);
  m.provider.options.forceResult = null; // bağlantı düzeldi
  assert.strictEqual((await m.showRewarded()).status, 'rewarded');
});
seq('A4  gösterme hatası -> "failed" (stage show)', async () => {
  const m = new SV.Ads.AdManager(mkCfg({ mock: { forceResult: 'showfail' } }), presenterWith('completed'));
  const r = await m.showRewarded();
  assert.strictEqual(r.status, 'failed'); assert.strictEqual(r.stage, 'show');
});
seq('A5  reklam sürerken ikinci istek "busy" döner (çift ödül yok)', async () => {
  let release;
  const slow = { showMockAd: () => new Promise((res) => { release = res; }) };
  const m = new SV.Ads.AdManager(mkCfg(), slow);
  const p1 = m.showRewarded();
  await new Promise((r) => setTimeout(r, 20));
  assert.strictEqual((await m.showRewarded()).status, 'busy');
  release('completed');
  assert.strictEqual((await p1).status, 'rewarded');
});
seq('A6  preload reklamı GÖSTERMEZ', async () => {
  let shown = 0;
  const m = new SV.Ads.AdManager(mkCfg(), { showMockAd: async () => { shown++; return 'completed'; } });
  assert.strictEqual((await m.preload()).ok, true);
  assert.strictEqual(shown, 0);
});

function fakeAdMob(script) {
  const listeners = {};
  const plugin = {
    calls: [],
    initialize: async (o) => { plugin.calls.push(['initialize', o]); },
    prepareRewardVideoAd: async (o) => { plugin.calls.push(['prepare', o]); if (script.prepareFails) throw new Error('no fill'); },
    addListener: async (ev, cb) => { listeners[ev] = cb; return { remove() { delete listeners[ev]; } }; },
    showRewardVideoAd: async () => {
      plugin.calls.push(['show']);
      setTimeout(() => {
        if (script.failShow) return listeners['onRewardedVideoAdFailedToShow'] && listeners['onRewardedVideoAdFailedToShow']({});
        if (script.reward) listeners['onRewardedVideoAdReward'] && listeners['onRewardedVideoAdReward']({ type: 'x', amount: 1 });
        listeners['onRewardedVideoAdDismissed'] && listeners['onRewardedVideoAdDismissed']();
      }, 5);
    }
  };
  return plugin;
}
const withCapacitor = async (plugin, fn) => {
  globalThis.Capacitor = { Plugins: { AdMob: plugin }, isNativePlatform: () => true, getPlatform: () => 'android' };
  try { return await fn(); } finally { delete globalThis.Capacitor; }
};

seq('A7  AdMob: ödül olayı gelirse "rewarded"', () => withCapacitor(fakeAdMob({ reward: true }), async () => {
  const m = new SV.Ads.AdManager(Object.assign(mkCfg(), { provider: 'auto' }), presenterWith('closed'));
  assert.strictEqual(m.providerName, 'admob');
  assert.strictEqual((await m.showRewarded()).status, 'rewarded');
}));
seq('A8  AdMob: ödül olayı gelmeden kapanırsa "dismissed"', () => withCapacitor(fakeAdMob({ reward: false }), async () => {
  const m = new SV.Ads.AdManager(Object.assign(mkCfg(), { provider: 'auto' }), presenterWith('completed'));
  assert.strictEqual((await m.showRewarded()).status, 'dismissed');
}));
seq('A9  AdMob: yükleme/gösterme hataları "failed"', async () => {
  await withCapacitor(fakeAdMob({ prepareFails: true }), async () => {
    const m = new SV.Ads.AdManager(Object.assign(mkCfg(), { provider: 'auto' }), presenterWith('completed'));
    const r = await m.showRewarded(); assert.strictEqual(r.status, 'failed'); assert.strictEqual(r.stage, 'load');
  });
  await withCapacitor(fakeAdMob({ failShow: true }), async () => {
    const m = new SV.Ads.AdManager(Object.assign(mkCfg(), { provider: 'auto' }), presenterWith('completed'));
    const r = await m.showRewarded(); assert.strictEqual(r.status, 'failed'); assert.strictEqual(r.stage, 'show');
  });
});
seq('A10 AdMob: gerçek kimlik boşsa ve test kapalıysa hata (sahte reklama düşmez)', () => withCapacitor(fakeAdMob({ reward: true }), async () => {
  const cfg = Object.assign(mkCfg({ admob: { useTestAds: false, testRewardedAdUnitId: { android: 'T' }, rewardedAdUnitId: { android: '' } } }), { provider: 'admob' });
  const m = new SV.Ads.AdManager(cfg, presenterWith('completed'));
  const r = await m.showRewarded();
  assert.strictEqual(r.status, 'failed'); assert.ok(/yapılandırılmamış/.test(r.error), r.error);
}));
seq('A11 AdMob: test modunda test birimi, değilse gerçek birim kullanılır', async () => {
  const p1 = fakeAdMob({ reward: true });
  await withCapacitor(p1, async () => {
    const m = new SV.Ads.AdManager(Object.assign(mkCfg(), { provider: 'auto' }), presenterWith('x'));
    await m.showRewarded();
  });
  assert.strictEqual(p1.calls.find((c) => c[0] === 'prepare')[1].adId, 'TEST-UNIT');
  const p2 = fakeAdMob({ reward: true });
  await withCapacitor(p2, async () => {
    const cfg = Object.assign(mkCfg({ admob: { useTestAds: false, testRewardedAdUnitId: { android: 'T' }, rewardedAdUnitId: { android: 'REAL-UNIT' } } }), { provider: 'auto' });
    await new SV.Ads.AdManager(cfg, presenterWith('x')).showRewarded();
  });
  assert.strictEqual(p2.calls.find((c) => c[0] === 'prepare')[1].adId, 'REAL-UNIT');
});
seq('A12 tarayıcıda (eklenti yok) "auto" sahte sağlayıcıya düşer', () => {
  const m = new SV.Ads.AdManager(Object.assign(mkCfg(), { provider: 'auto' }), presenterWith('completed'));
  assert.strictEqual(m.providerName, 'mock');
});
seq('A13 kodda gerçek reklam kimliği yok (yalnızca config dosyasında)', () => {
  const fs = require('fs');
  const code = fs.readFileSync(path.join(__dirname, '../src/core/ads.js'), 'utf8');
  assert.ok(!/ca-app-pub-\d/.test(code), 'ads.js içinde reklam kimliği bulunmamalı');
});

/* Bundler'sız düz sayfa: yalnızca ham yerel köprü (nativePromise/nativeCallback) var.
 * Capacitor.Plugins.AdMob burada OLUŞMAZ (gerçek Capacitor davranışı) -> köprü kullanılmalı. */
function fakeRawBridge(script) {
  const listeners = {};
  let nextId = 1;
  const log = [];
  const cap = {
    log,
    Plugins: {},                                   // boş: registerPlugin hiç çağrılmadı
    PluginHeaders: [{ name: 'AdMob', methods: [] }],
    isNativePlatform: () => true,
    getPlatform: () => 'android',
    nativeCallback: (plugin, method, opts, cb) => {
      assert.strictEqual(plugin, 'AdMob'); assert.strictEqual(method, 'addListener');
      listeners[opts.eventName] = cb; log.push(['listen', opts.eventName]);
      return nextId++;
    },
    nativePromise: async (plugin, method, opts) => {
      assert.strictEqual(plugin, 'AdMob'); log.push([method, opts]);
      if (method === 'prepareRewardVideoAd' && script.prepareFails) throw new Error('no fill');
      if (method === 'showRewardVideoAd') {
        setTimeout(() => {
          if (script.reward) listeners['onRewardedVideoAdReward'] && listeners['onRewardedVideoAdReward']({ type: 'x', amount: 1 });
          listeners['onRewardedVideoAdDismissed'] && listeners['onRewardedVideoAdDismissed']();
        }, 5);
      }
      return {};
    }
  };
  return cap;
}
const withCap = async (cap, fn) => { globalThis.Capacitor = cap; try { return await fn(); } finally { delete globalThis.Capacitor; } };

seq('A14 düz sayfa + yerel köprü: AdMob bulunur ve ödül akışı çalışır', async () => {
  const cap = fakeRawBridge({ reward: true });
  await withCap(cap, async () => {
    const m = new SV.Ads.AdManager(Object.assign(mkCfg(), { provider: 'auto' }), presenterWith('closed'));
    assert.strictEqual(m.providerName, 'admob', 'registerPlugin olmadan da köprüden bulunmalı');
    assert.strictEqual((await m.showRewarded()).status, 'rewarded');
    assert.ok(cap.log.some((l) => l[0] === 'initialize'), 'initialize çağrılmalı');
    assert.strictEqual(cap.log.find((l) => l[0] === 'prepareRewardVideoAd')[1].adId, 'TEST-UNIT');
  });
});
seq('A15 düz sayfa + yerel köprü: ödülsüz kapatma "dismissed"', async () => {
  await withCap(fakeRawBridge({ reward: false }), async () => {
    const m = new SV.Ads.AdManager(Object.assign(mkCfg(), { provider: 'auto' }), presenterWith('completed'));
    assert.strictEqual((await m.showRewarded()).status, 'dismissed');
  });
});
seq('A16 Capacitor var ama yerel eklenti kurulu değilse (PluginHeaders boş) sahte sağlayıcıya düşer', async () => {
  const cap = fakeRawBridge({ reward: true }); cap.PluginHeaders = [];
  await withCap(cap, async () => {
    const m = new SV.Ads.AdManager(Object.assign(mkCfg(), { provider: 'auto' }), presenterWith('completed'));
    assert.strictEqual(m.providerName, 'mock');
  });
});
seq('A17 Capacitor tarayıcı modunda (native değil) sahte sağlayıcı kullanılır', async () => {
  const cap = fakeRawBridge({ reward: true }); cap.isNativePlatform = () => false;
  await withCap(cap, async () => {
    const m = new SV.Ads.AdManager(Object.assign(mkCfg(), { provider: 'auto' }), presenterWith('completed'));
    assert.strictEqual(m.providerName, 'mock');
  });
});

runAll().then(() => {
  console.log('\n' + passed + ' geçti, ' + failed + ' kaldı');
  process.exit(failed ? 1 : 0);
});
