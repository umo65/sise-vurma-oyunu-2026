/* Fizik + oynanabilirlik testleri (Node). Çalıştır: node tests/physics.test.js */
const assert = require('assert');
const path = require('path');
const load = (p) => require(path.join(__dirname, '..', p));
['util', 'storage', 'shapes', 'levels'].forEach((m) => load('src/core/' + m + '.js'));
load('src/game/physics.js');
const SV = globalThis.SV, P = SV.Physics, L = SV.Levels;

let passed = 0, failed = 0;
function test(name, fn) {
  try { fn(); passed++; console.log('  ok   ' + name); }
  catch (e) { failed++; console.log('  FAIL ' + name + '\n       ' + (e && e.message || e)); }
}

const mkBall = (x, y, vx, vy) => ({ x, y, vx, vy, r: P.BALL_R, angle: 0 });

test('P1  top yere düşer ve durur (zeminin altına geçmez)', () => {
  const ball = mkBall(500, 100, 200, 0);
  const world = { colliders: [], groundY: L.GROUND_Y };
  for (let i = 0; i < 240 * 8; i++) P.stepBall(ball, P.STEP, world);
  assert.ok(ball.y + ball.r <= L.GROUND_Y + 0.01, 'zemine gömüldü: ' + ball.y);
  assert.ok(Math.abs(ball.vy) < 5, 'dinlenmeli, vy=' + ball.vy);
});

test('P2  en yüksek hızda bile ince boyundan geçmez (tunneling yok)', () => {
  const layout = L.build(1, 1280);
  const set = new P.ColliderSet(layout);
  const b = layout.bottles[0];
  const pose = set.poses[b.platIndex];
  const neckX = pose.x + b.ox;
  const neckY = pose.y - SV.Shapes.height(b.shape, b.scale) * 0.8;
  const ball = mkBall(neckX - 400, neckY, 1750, 0);
  let hit = false;
  const world = { colliders: set.list, groundY: L.GROUND_Y, onContact: (c) => { if (c.type === 'bottle') hit = true; } };
  for (let i = 0; i < 240; i++) { set.update(i * P.STEP); P.stepBall(ball, P.STEP, world); if (hit) break; }
  assert.ok(hit, 'hızlı top şişeden geçti');
});

test('P3  top platformun üstüne konar (içinden geçmez)', () => {
  const layout = L.build(1, 1280);
  const set = new P.ColliderSet(layout);
  const p = layout.plats[0];
  const ball = mkBall(p.cx - p.w / 2 + 12, p.top - 200, 0, 0); // şişeden uzak, kenara yakın
  const world = { colliders: set.list, groundY: L.GROUND_Y };
  for (let i = 0; i < 240; i++) { set.update(i * P.STEP); P.stepBall(ball, P.STEP, world); }
  assert.ok(ball.y < p.top + 30, 'platformdan geçti, y=' + ball.y);
});

test('P4  hareketli platformda çarpışma göreli hızla çözülür (top platformu "geçmez")', () => {
  const layout = L.build(4, 1280); // yatay hareketli
  assert.ok(layout.plats[0].move);
  const set = new P.ColliderSet(layout);
  const p = layout.plats[0];
  const ball = mkBall(p.cx, p.top - 120, 0, 0);
  const world = { colliders: set.list, groundY: L.GROUND_Y };
  let minGap = 1e9;
  for (let i = 0; i < 240 * 2; i++) {
    set.update(i * P.STEP); P.stepBall(ball, P.STEP, world);
    const pose = set.poses[0];
    if (Math.abs(ball.x - pose.x) < p.w / 2 - 80) minGap = Math.min(minGap, pose.y - (ball.y + ball.r));
  }
  assert.ok(minGap > -2, 'top platformun içine girdi: ' + minGap);
});

/* ---------- Oynanabilirlik: her şişe vurulabilir mi? ---------- */
// Varsayılan: yalnızca 1280 genişlik (~1-2 dk). --full ile 960/1280/1600 hepsi (~4 dk).
const FULL = process.argv.includes('--full') || !!process.env.FULL;
const WIDTHS = FULL ? [960, 1280, 1600] : [1280];
const LEVELS = 12;
const t0 = Date.now();
const problems = [];
let checked = 0, notRobust1 = 0;

for (const W of WIDTHS) {
  for (let n = 1; n <= LEVELS; n++) {
    const layout = L.build(n, W);
    const moving = layout.plats.some((p) => p.move);
    // Hareketli bölümlerde oyuncu doğru anı bekleyebilir: birkaç başlangıç zamanı dene
    const launchTimes = moving ? [0, 0.6, 1.2, 1.8, 2.4, 3.0] : [0];
    layout.bottles.forEach((b, i) => {
      checked++;
      let best = null;
      for (const tl of launchTimes) {
        const s = P.solveShot(layout, i, tl);
        if (s && (!best || (s.robust && !best.robust))) best = s;
        if (best && best.robust) break;
      }
      if (!best) problems.push(`W=${W} bölüm ${n} şişe ${i} (${b.colorId}/${b.shape}) VURULAMIYOR`);
      else if (n === 1 && !best.robust) notRobust1++;
    });
  }
}
const secs = ((Date.now() - t0) / 1000).toFixed(1);

test(`P5  ${checked} şişenin hepsi vurulabilir (W=${WIDTHS.join('/')}, bölüm 1-${LEVELS}) [${secs} sn]`, () => {
  assert.strictEqual(problems.length, 0, '\n       ' + problems.slice(0, 12).join('\n       '));
});
test('P6  1. bölümde her şişe için nişan toleranslı (±4 px) bir çözüm var', () => {
  assert.strictEqual(notRobust1, 0, notRobust1 + ' şişe sadece çok dar bir açıyla vurulabiliyor');
});

console.log('\n' + passed + ' geçti, ' + failed + ' kaldı');
process.exit(failed ? 1 : 0);
