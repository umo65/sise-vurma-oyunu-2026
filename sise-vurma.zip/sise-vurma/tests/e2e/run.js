/*
 * UÇTAN UCA TESTLER (gerçek Chromium, gerçek fare/dokunma olayları)
 * Çalıştır:  node tests/e2e/run.js
 *
 * "SON KONTROL" listesindeki 8 senaryoyu oyunun gerçek arayüzü üzerinden sınar:
 *  K1 2 top ile başlar            K5 reklam tamamlanmazsa ödül yok (+ yükleme hatası / tekrar dene)
 *  K2 yanlış atış top azaltır     K6 doğru vuruş: puan + bölüm ilerlemesi
 *  K3 2. yanlışta pencere açılır  K7 şeffaf şişeler, 6 sıvı rengi
 *  K4 reklam bitince 3 top        K8 dokunmatik cihaz (telefon emülasyonu)
 */
const path = require('path');
const fs = require('fs');
const H = require('./helpers');
const assert = require('assert');

const ROOT = path.join(__dirname, '..', '..');
const SHOTS = path.join(__dirname, 'screenshots');
fs.mkdirSync(SHOTS, { recursive: true });

let passed = 0, failed = 0;
const results = [];
const ONLY = ((process.argv.find((a) => a.startsWith('--only=')) || '').slice(7));
async function test(name, fn) {
  if (ONLY && !name.startsWith(ONLY) && !name.startsWith('K9')) return;   // örn: node tests/e2e/run.js --only=K7
  const t0 = Date.now();
  try { await fn(); passed++; results.push(['ok', name]); console.log('  ok   ' + name + '  (' + ((Date.now() - t0) / 1000).toFixed(1) + ' sn)'); }
  catch (e) { failed++; results.push(['FAIL', name]); console.log('  FAIL ' + name + '\n       ' + String((e && e.stack) || e).split('\n').slice(0, 6).join('\n       ')); }
}
const shot = (page, name) => page.screenshot({ path: path.join(SHOTS, name + '.png') });

/** Menüden "OYNA"ya gerçek tıklama ile 1. bölümü başlatır. */
async function startGame(page) {
  await H.clickButton(page, 'OYNA');
  await page.waitForFunction(() => SV.App.scene && SV.App.scene.constructor.name === 'GameScene' && SV.App.scene.phase === 'ready', null, { timeout: 20000 });
  await page.waitForTimeout(700);
}

/** Hedef olmayan, hedeften en az 2 şişe uzaktaki bir şişeyi vuran çekiş (yanlış atış). */
async function wrongPull(page, pick) {
  const info = await page.evaluate(() => {
    const sc = SV.App.scene;
    return { t: sc.targetBottleIndex(), alive: sc.bottles.map((b, i) => (b.dead ? -1 : i)).filter((i) => i >= 0) };
  });
  const cands = info.alive.filter((i) => Math.abs(i - info.t) >= 2).sort((a, b) => Math.abs(b - info.t) - Math.abs(a - info.t));
  const idx = cands[pick % cands.length];
  const s = await H.solve(page, idx);
  assert.ok(s, 'şişe ' + idx + ' için çözüm yok');
  return s;
}

const panelInfo = (page) => page.evaluate(() => {
  const sc = SV.App.scene;
  if (!sc.panel) return null;
  const texts = [];
  const walk = (o) => { if (o.list) o.list.forEach(walk); if (o.type === 'Text') texts.push(o.text); };
  walk(sc.panel.modal.root);
  return { texts };
});

(async () => {
  const { srv, url } = await H.startServer(ROOT);
  const browser = await H.launch();
  const allErrors = [];
  const open = (opts) => H.openPage(browser, url, opts);
  // Her sayfa işi bitince kapatılır (yazılım GL'de açık sayfalar CPU yer ve diğerlerini yavaşlatır)
  const closePage = async (p) => { allErrors.push(...p.errors); await p.ctx.close().catch(() => {}); };

  console.log('\nUÇTAN UCA TESTLER  (' + url + ')\n');

  /* ===== K1-K5: aynı oyun üzerinde sıralı akış ===== */
  const page = await open({ query: '?adms=1200' });

  await test('K1  Oyun 2 top hakkıyla başlıyor (OYNA tıklaması -> 2/2)', async () => {
    const menu = await H.buttons(page);
    assert.ok(menu.some((b) => b.label === 'OYNA'), 'menüde OYNA düğmesi yok');
    await startGame(page);
    const s = await H.snap(page);
    assert.strictEqual(s.level, 1);
    assert.strictEqual(s.balls, 2);
    assert.strictEqual(s.maxBalls, 2);
    assert.strictEqual(s.hud, '2/2', 'HUD "2/2" göstermeli');
    assert.strictEqual(s.status, 'playing');
    const n = await page.evaluate(() => SV.App.scene.layout.bottles.length);
    assert.strictEqual(n, 6, '6 şişe olmalı');
  });

  await test('K2  Yanlış atışta top sayısı 2 -> 1 azalıyor, puan değişmiyor', async () => {
    const before = await H.snap(page);
    await H.shoot(page, await wrongPull(page, 0));
    const s = await H.snap(page);
    assert.strictEqual(s.balls, 1, 'top 1 kalmalı');
    assert.strictEqual(s.hud, '1/2');
    assert.strictEqual(s.score, before.score, 'yanlış atış puan vermemeli');
    assert.strictEqual(s.targetIndex, 0, 'hedef ilerlememeli');
    assert.strictEqual(s.status, 'playing');
    assert.strictEqual(s.hasPanel, false, 'henüz pencere açılmamalı');
    // Şişeler yerinde (devrilmedi, hiçbiri kırılmadı)
    const alive = await page.evaluate(() => SV.App.scene.bottles.filter((b) => !b.dead).length);
    assert.strictEqual(alive, 6);
  });

  await test('K3  2. yanlış atıştan sonra "Topların bitti!" penceresi iki seçenekle açılıyor', async () => {
    await H.shoot(page, await wrongPull(page, 1));
    const s = await H.snap(page);
    assert.strictEqual(s.balls, 0);
    assert.strictEqual(s.hud, '0/2');
    assert.strictEqual(s.status, 'outOfBalls');
    assert.strictEqual(s.hasPanel, true, 'pencere açılmalı');
    const p = await panelInfo(page);
    assert.ok(p.texts.includes('Topların bitti!'), 'başlık: ' + p.texts.join(' | '));
    assert.ok(p.texts.includes('REKLAM İZLE — 3 EKSTRA TOP KAZAN'), 'reklam düğmesi yok: ' + p.texts.join(' | '));
    assert.ok(p.texts.includes('BÖLÜMÜ YENİDEN BAŞLAT'), 'yeniden başlat düğmesi yok');
    // Reklam, kullanıcı basmadan başlamamalı
    const adOpen = await page.evaluate(() => !document.getElementById('mockad').hidden);
    assert.strictEqual(adOpen, false, 'reklam kullanıcı basmadan açıldı');
    await page.waitForTimeout(500);
    await shot(page, 'k3_topların_bitti');
  });

  await test('K5a Reklam tamamlanmadan kapatılırsa ekstra top VERİLMİYOR', async () => {
    await page.evaluate(() => { SV.App.ads.provider.options.durationMs = 6000; });
    await H.clickButton(page, 'REKLAM İZLE');
    await page.waitForFunction(() => !document.getElementById('mockad').hidden, null, { timeout: 8000 });
    const t = await page.evaluate(() => document.querySelector('#mockad .ad-badge').textContent);
    assert.strictEqual(t, 'TEST REKLAMI');
    await page.waitForTimeout(500);
    await page.click('#mockad .ad-close');                    // süre dolmadan kapat
    await page.waitForFunction(() => document.getElementById('mockad').hidden, null, { timeout: 5000 });
    await page.waitForTimeout(400);
    const s = await H.snap(page);
    assert.strictEqual(s.balls, 0, 'ödülsüz kapatmada top verilmemeli');
    assert.strictEqual(s.status, 'outOfBalls');
    assert.strictEqual(s.hasPanel, true, 'pencere açık kalmalı');
    const p = await panelInfo(page);
    assert.ok(p.texts.some((t2) => t2.includes('ekstra top verilmedi')), 'bilgi mesajı yok: ' + p.texts.join(' | '));
    const btns = await H.buttons(page);
    assert.ok(btns.find((b) => b.label === 'REKLAM İZLE — 3 EKSTRA TOP KAZAN' && b.enabled), 'reklam düğmesi tekrar kullanılabilir olmalı');
    await shot(page, 'k5_odulsuz_kapatildi');
  });

  await test('K4  Test reklamı tamamlanınca 3 top veriliyor ve oyun devam ediyor', async () => {
    await page.evaluate(() => { SV.App.ads.provider.options.durationMs = 1200; });
    await H.clickButton(page, 'REKLAM İZLE');
    await page.waitForFunction(() => !document.getElementById('mockad').hidden, null, { timeout: 8000 });
    await shot(page, 'k4_test_reklami');
    assert.strictEqual((await H.snap(page)).balls, 0, 'reklam sürerken top verilmemeli');
    await page.waitForSelector('#mockad .ad-claim:not([hidden])', { timeout: 8000 });
    await page.click('#mockad .ad-claim');
    await page.waitForFunction(() => SV.App.state.status === 'playing' && SV.App.scene.phase === 'ready', null, { timeout: 8000 });
    const s = await H.snap(page);
    assert.strictEqual(s.balls, 3, '3 ekstra top');
    assert.strictEqual(s.maxBalls, 3);
    assert.strictEqual(s.hud, '3/3');
    assert.strictEqual(s.hasPanel, false, 'pencere kapanmalı');
    // ödül sonrası gerçekten atış yapılabiliyor
    await H.shoot(page, await wrongPull(page, 0));
    assert.strictEqual((await H.snap(page)).balls, 2, 'ödül sonrası atış 3 -> 2 düşürmeli');
  });

  await closePage(page);

  await test('K5b Reklam yüklenemezse hata mesajı + "TEKRAR DENE"; tekrar deneyince ödül çalışıyor', async () => {
    const p2 = await open({ query: '?ad=loadfail&adms=900' });
    try {
    await startGame(p2);
    await H.shoot(p2, await wrongPull(p2, 0));
    await H.shoot(p2, await wrongPull(p2, 1));
    assert.strictEqual((await H.snap(p2)).status, 'outOfBalls');
    await H.clickButton(p2, 'REKLAM İZLE');
    await p2.waitForFunction(() => SV.App.scene.panel && !SV.App.scene.panel.busy, null, { timeout: 10000 });
    const info = await panelInfo(p2);
    assert.ok(info.texts.some((t) => t.includes('Reklam yüklenemedi')), 'hata mesajı yok: ' + info.texts.join(' | '));
    const btns = await H.buttons(p2);
    assert.ok(btns.some((b) => b.label === 'TEKRAR DENE'), '"TEKRAR DENE" düğmesi yok');
    assert.strictEqual((await H.snap(p2)).balls, 0);
    await shot(p2, 'k5b_reklam_yuklenemedi');
    // sorunu gider ve yeniden dene
    await p2.evaluate(() => { SV.App.ads.provider.options.forceResult = null; });
    await H.clickButton(p2, 'TEKRAR DENE');
    await p2.waitForSelector('#mockad .ad-claim:not([hidden])', { timeout: 10000 });
    await p2.click('#mockad .ad-claim');
    await p2.waitForFunction(() => SV.App.state.balls === 3, null, { timeout: 8000 });
    assert.strictEqual((await H.snap(p2)).hud, '3/3');
    } finally { await closePage(p2); }
  });

  await test('K5c Bölümü yeniden başlat: 2/2 top, puan bölüm başına döner, aynı bölüm', async () => {
    const p3 = await open({ query: '?adms=800' });
    try {
    await startGame(p3);
    await H.shoot(p3, await wrongPull(p3, 0));
    await H.shoot(p3, await wrongPull(p3, 1));
    await H.clickButton(p3, 'BÖLÜMÜ YENİDEN BAŞLAT');
    await p3.waitForFunction(() => SV.App.scene.phase === 'ready' && SV.App.state.balls === 2 && !SV.App.scene.panel, null, { timeout: 15000 });
    const s = await H.snap(p3);
    assert.strictEqual(s.level, 1);
    assert.strictEqual(s.balls, 2);
    assert.strictEqual(s.hud, '2/2');
    assert.strictEqual(s.status, 'playing');
    assert.strictEqual(s.targetIndex, 0);
    // alt çubuktaki yeniden başlat düğmesi de çalışmalı
    await H.shoot(p3, await wrongPull(p3, 0));
    assert.strictEqual((await H.snap(p3)).balls, 1);
    await H.clickButton(p3, 'icon:restart');
    await p3.waitForFunction(() => SV.App.scene.phase === 'ready' && SV.App.state.balls === 2, null, { timeout: 15000 });
    assert.strictEqual((await H.snap(p3)).hud, '2/2');
    } finally { await closePage(p3); }
  });

  /* ===== K6: doğru vuruş, puan, bölüm geçişi ===== */
  await test('K6  Doğru hedefler sırayla vurulunca puan artıyor, topu götürmüyor, bölüm tamamlanıp 2. bölüme geçiliyor', async () => {
    const p4 = await open({ query: '?adms=800' });
    try {
    await startGame(p4);
    let last = 0, shots = 0;
    // Bir atış, kırılan şişeden geçip sıradaki hedefi de vurabilir (seri); bu yüzden
    // "her atışta en az 1 hedef ilerler" diye sınanır ve bölüm bitene kadar atılır.
    while ((await H.snap(p4)).status === 'playing' && shots < 8) {
      const s0 = await H.snap(p4);
      const sol = await H.solve(p4);
      assert.ok(sol, 'hedef ' + s0.targetIndex + ' için çözüm yok');
      await H.shoot(p4, sol);
      shots++;
      const s = await H.snap(p4);
      assert.ok(s.score > last, 'puan artmalı (' + last + ' -> ' + s.score + ')');
      last = s.score;
      assert.strictEqual(s.balls, 2, 'doğru vuruş top hakkı götürmemeli');
      assert.ok(s.targetIndex > s0.targetIndex, 'hedef ilerlemeli (' + s0.targetIndex + ' -> ' + s.targetIndex + ')');
    }
    assert.ok(shots >= 1 && shots <= 6, 'atış sayısı: ' + shots);
    console.log('       6 hedef ' + shots + ' atışta vuruldu (seri vuruşlar dahil)');
    const s = await H.snap(p4);
    assert.strictEqual(s.status, 'levelComplete');
    await p4.waitForFunction(() => SV.App.scene.panel, null, { timeout: 8000 });
    await p4.waitForTimeout(1800);
    const p = await panelInfo(p4);
    assert.ok(p.texts.includes('BÖLÜM TAMAMLANDI!'), p.texts.join(' | '));
    ['KAZANILAN PUAN', 'KALAN TOP', 'TOPLAM PUAN'].forEach((t) => assert.ok(p.texts.includes(t), t + ' yok'));
    assert.ok(p.texts.includes('2 / 2'), 'kalan top 2/2 olmalı: ' + p.texts.join(' | '));
    await shot(p4, 'k6_bolum_tamamlandi');
    const total = s.score;
    await H.clickButton(p4, 'SONRAKİ BÖLÜM');
    await p4.waitForFunction(() => SV.App.scene.constructor.name === 'GameScene' && SV.App.state.level === 2 && SV.App.scene.phase === 'ready', null, { timeout: 15000 });
    const n = await H.snap(p4);
    assert.strictEqual(n.level, 2);
    assert.strictEqual(n.balls, 2);
    assert.strictEqual(n.score, total, 'puan bölümler arasında taşınmalı');
    assert.strictEqual(n.status, 'playing');
    await p4.waitForTimeout(1500);
    await shot(p4, 'k6_bolum2');
    } finally { await closePage(p4); }
  });

  await test('K6b Doğru şişeyi vuran atış, aynı uçuşta komşu şişeye değse de top götürmüyor', async () => {
    const p5 = await open({ query: '?adms=800' });
    try {
    await startGame(p5);
    const out = await p5.evaluate(() => {
      const sc = SV.App.scene, st = sc.state;
      sc.phase = 'flying'; sc.shot = { t: 0, rest: 0, touched: false, penalized: false, correct: 0, last: {} };
      sc.ball.flying = true;
      const t = sc.targetBottleIndex();
      const w = sc.layout.bottles.findIndex((b, i) => i !== t && b.colorId !== st.targets[st.targetIndex + 1]);
      sc.onContact({ type: 'bottle', bottleIndex: t });          // doğru vuruş
      const wrongId = (t + 1) % 6;
      sc.onContact({ type: 'bottle', bottleIndex: wrongId });     // aynı uçuşta komşuya değdi
      return { balls: st.balls, score: st.score };
    });
    assert.strictEqual(out.balls, 2);
    assert.ok(out.score > 0);
    } finally { await closePage(p5); }
  });

  /* ===== K7: görünüm ===== */
  await test('K7  Şişeler şeffaf, sıvılar 6 farklı renk (piksel analizi)', async () => {
    const p6 = await open({ query: '?adms=800' });
    try {
    await startGame(p6);
    await p6.waitForTimeout(1500);
    // Sahneyi dondur: iki görüntü arasında yalnızca şişeler farklı olsun
    await p6.evaluate(() => { SV.App.scene.scene.pause(); });
    await p6.waitForTimeout(300);
    const A = (await p6.screenshot()).toString('base64');
    await p6.evaluate(() => { SV.App.scene.bottles.forEach((b) => b.view.root.setVisible(false)); });
    await p6.waitForTimeout(300);
    const B = (await p6.screenshot()).toString('base64');
    await p6.evaluate(() => { SV.App.scene.bottles.forEach((b) => b.view.root.setVisible(true)); SV.App.scene.scene.resume(); });
    fs.writeFileSync(path.join(SHOTS, 'k7_sisler.png'), Buffer.from(A, 'base64'));

    const res = await p6.evaluate(async ([a64, b64]) => {
      const load = async (b) => {
        const blob = await (await fetch('data:image/png;base64,' + b)).blob();
        const bmp = await createImageBitmap(blob);
        const c = document.createElement('canvas'); c.width = bmp.width; c.height = bmp.height;
        const x = c.getContext('2d'); x.drawImage(bmp, 0, 0);
        return x.getImageData(0, 0, c.width, c.height);
      };
      const IA = await load(a64), IB = await load(b64);
      const px = (I, x, y) => { x = Math.round(x); y = Math.round(y); const k = (y * I.width + x) * 4; return [I.data[k], I.data[k + 1], I.data[k + 2]]; };
      const hue = ([r, g, b]) => { r /= 255; g /= 255; b /= 255; const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn; if (!d) return 0; let h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h *= 60; return h < 0 ? h + 360 : h; };
      const sat = ([r, g, b]) => { const mx = Math.max(r, g, b), mn = Math.min(r, g, b); return mx ? (mx - mn) / mx : 0; };
      const hexRgb = (h) => [1, 3, 5].map((i) => parseInt(h.substr(i, 2), 16));
      const sc = SV.App.scene;
      const out = [];
      sc.bottles.forEach((b, i) => {
        const v = b.view, bx = v.x, by = v.y, H = v.H, bw = v.bw;
        // Sıvı: gövdenin alt yarısında, kenar parlamasından uzak
        const liq = px(IA, bx + bw * 0.12, by - H * 0.2);
        // Boş cam: boyun/omuz bölgesi (sıvı yüzeyinin üstü), solda/sağda cam kenarından uzak
        const glassPts = [[bx + bw * 0.04, by - H * 0.86], [bx - bw * 0.04, by - H * 0.80], [bx + bw * 0.10, by - H * 0.93],
          [bx + bw * 0.28, by - H * 0.52], [bx + bw * 0.20, by - H * 0.57]];   // omuz + boyun: sıvının üstündeki boş cam
        let maxDiff = 0;
        glassPts.forEach(([gx, gy]) => { const a = px(IA, gx, gy), c = px(IB, gx, gy); maxDiff = Math.max(maxDiff, Math.abs(a[0] - c[0]) + Math.abs(a[1] - c[1]) + Math.abs(a[2] - c[2])); });
        const col = SV.Levels.BY_ID[b.def.colorId];
        out.push({ i, id: b.def.colorId, liq, liqHue: Math.round(hue(liq)), liqSat: +sat(liq).toFixed(2), wantHue: Math.round(hue(hexRgb(col.hex))), glassDiff: maxDiff });
      });
      return out;
    }, [A, B]);
    console.log('       şişe analizi: ' + res.map((r) => `${r.id}[renk ${r.liqHue}°/${r.wantHue}°, cam farkı ${r.glassDiff}]`).join('  '));
    const ids = res.map((r) => r.id);
    assert.strictEqual(new Set(ids).size, 6, '6 farklı renk olmalı: ' + ids.join(','));
    assert.deepStrictEqual([...ids].sort(), ['blue', 'green', 'orange', 'purple', 'red', 'yellow']);
    res.forEach((r) => {
      const dh = Math.min(Math.abs(r.liqHue - r.wantHue), 360 - Math.abs(r.liqHue - r.wantHue));
      assert.ok(r.liqSat > 0.45, r.id + ' sıvısı yeterince doygun değil: ' + r.liqSat);
      assert.ok(dh <= 24, r.id + ' sıvı tonu yanlış: ' + r.liqHue + '° (beklenen ' + r.wantHue + '°)');
      assert.ok(r.glassDiff <= 60, r.id + ' camı arka planı belirgin değiştiriyor (şeffaf değil): fark ' + r.glassDiff);
    });
    // sıvı renkleri birbirinden gerçekten ayrı (ton farkı en az 15°)
    for (let a = 0; a < res.length; a++) for (let b = a + 1; b < res.length; b++) {
      const d = Math.abs(res[a].liqHue - res[b].liqHue); assert.ok(Math.min(d, 360 - d) >= 15, res[a].id + ' ve ' + res[b].id + ' çok benzer');
    }
    } finally { await closePage(p6); }
  });

  /* ===== K8: dokunmatik telefon ===== */
  await test('K8  Telefon (dokunmatik, 915x412 yatay): dokunarak başlat, parmakla çek-bırak, doğru vuruş', async () => {
    const m = await open({ viewport: { width: 915, height: 412 }, touch: true, dpr: 2, query: '?adms=800' });
    try {
    const meta = await m.evaluate(() => ({
      viewport: document.querySelector('meta[name=viewport]').content,
      touchAction: getComputedStyle(document.querySelector('#game canvas')).touchAction,
      scrollW: document.documentElement.scrollWidth, innerW: innerWidth, scrollH: document.documentElement.scrollHeight, innerH: innerHeight,
      rect: document.querySelector('#game canvas').getBoundingClientRect().toJSON(),
      portraitOverlay: getComputedStyle(document.getElementById('rotate')).display
    }));
    assert.ok(/user-scalable=no/.test(meta.viewport));
    assert.strictEqual(meta.touchAction, 'none');
    assert.ok(meta.scrollW <= meta.innerW && meta.scrollH <= meta.innerH, 'sayfa kaydırılabiliyor: ' + JSON.stringify(meta));
    assert.ok(meta.rect.left >= -1 && meta.rect.right <= meta.innerW + 1 && meta.rect.top >= -1 && meta.rect.bottom <= meta.innerH + 1, 'tuval ekrana sığmıyor');
    assert.strictEqual(meta.portraitOverlay, 'none', 'yatayda "çevir" uyarısı görünmemeli');
    // OYNA'ya parmakla dokun
    const b = await H.findButton(m, 'OYNA');
    const sp = await H.toScreen(m, b.x, b.y);
    await m.touchscreen.tap(sp.x, sp.y);
    await m.waitForFunction(() => SV.App.scene && SV.App.scene.constructor.name === 'GameScene' && SV.App.scene.phase === 'ready', null, { timeout: 20000 });
    await m.waitForTimeout(800);
    assert.strictEqual((await H.snap(m)).hud, '2/2');
    // parmakla yanlış atış: top 2 -> 1
    await H.shoot(m, await wrongPull(m, 0), 'touch');
    assert.strictEqual((await H.snap(m)).balls, 1, 'dokunmatik atış top azaltmalı');
    // parmakla doğru atış: puan
    const sol = await H.solve(m);
    await H.shoot(m, sol, 'touch');
    const s = await H.snap(m);
    assert.ok(s.score >= 100, 'dokunmatik doğru atış puan vermeli: ' + JSON.stringify(s));
    assert.strictEqual(s.targetIndex, 1);
    await shot(m, 'k8_telefon_yatay');
    // Alt çubuk düğmesine parmakla dokun (ses): durum değişmeli
    const before = await m.evaluate(() => SV.Audio.muted);
    const sb = await H.findButton(m, 'icon:sound');
    const sbp = await H.toScreen(m, sb.x, sb.y);
    await m.touchscreen.tap(sbp.x, sbp.y);
    await m.waitForTimeout(200);
    assert.notStrictEqual(await m.evaluate(() => SV.Audio.muted), before, 'ses düğmesi çalışmadı');
    // Dik tutulursa "yatay çevir" uyarısı
    await m.setViewportSize({ width: 412, height: 915 });
    await m.waitForTimeout(500);
    assert.strictEqual(await m.evaluate(() => getComputedStyle(document.getElementById('rotate')).display), 'flex', 'dikeyde uyarı çıkmalı');
    await shot(m, 'k8_telefon_dikey_uyari');
    } finally { await closePage(m); }
  });

  await test('K9  Konsolda hiç JavaScript hatası yok', async () => {
    assert.deepStrictEqual(allErrors, [], allErrors.join('\n'));
  });

  await browser.close();
  srv.close();
  console.log('\n' + passed + ' geçti, ' + failed + ' kaldı');
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.error('TEST ÇALIŞTIRICI HATASI', e); process.exit(2); });
