/*
 * Tarayıcı (uçtan uca) test yardımcıları. Gerçek Chromium + Playwright kullanır.
 * Kurulum: npm i -D playwright && npx playwright install chromium
 */
const http = require('http');
const fs = require('fs');
const path = require('path');

function loadPlaywright() {
  const tries = ['playwright', '/opt/npm-tools/node_modules/playwright'];
  for (const t of tries) { try { return require(t); } catch (e) { /* sıradakini dene */ } }
  throw new Error('playwright bulunamadı. Kur: npm i -D playwright && npx playwright install chromium');
}

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json',
  '.woff': 'font/woff', '.woff2': 'font/woff2', '.png': 'image/png', '.md': 'text/plain; charset=utf-8', '.webmanifest': 'application/manifest+json' };

/** Proje klasörünü rastgele bir portta sunan küçük sunucu. */
function startServer(root) {
  return new Promise((resolve) => {
    const srv = http.createServer((req, res) => {
      let p = decodeURIComponent(req.url.split('?')[0]);
      if (p.endsWith('/')) p += 'index.html';
      const file = path.join(root, path.normalize(p));
      if (!file.startsWith(root)) { res.writeHead(403); return res.end(); }
      fs.readFile(file, (err, data) => {
        if (err) { res.writeHead(404); return res.end('404'); }
        res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
        res.end(data);
      });
    });
    srv.listen(0, '127.0.0.1', () => resolve({ srv, url: 'http://127.0.0.1:' + srv.address().port }));
  });
}

async function launch() {
  const { chromium } = loadPlaywright();
  return chromium.launch({ args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--autoplay-policy=no-user-gesture-required'] });
}

/** Sayfayı açar; konsol hatalarını toplar. opts: {viewport, touch, query, dpr} */
async function openPage(browser, baseUrl, opts) {
  opts = opts || {};
  const ctx = await browser.newContext({
    viewport: opts.viewport || { width: 1280, height: 720 },
    deviceScaleFactor: opts.dpr || 1,
    hasTouch: !!opts.touch, isMobile: !!opts.touch,
    userAgent: opts.touch ? 'Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Mobile Safari/537.36' : undefined
  });
  const page = await ctx.newPage();
  page.errors = [];
  page.on('pageerror', (e) => page.errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') page.errors.push('console.error: ' + m.text()); });
  await page.goto(baseUrl + '/index.html' + (opts.query || ''), { waitUntil: 'load' });
  await page.waitForFunction(() => window.SV && SV.App && SV.App.game && SV.App.game.scene.isActive('Menu') && SV.App.scene !== undefined, null, { timeout: 20000 })
    .catch(() => {});
  await page.waitForFunction(() => SV.App.game.scene.getScenes(true).some((s) => s.scene.key === 'Menu' && s.playBtn), null, { timeout: 20000 });
  page.ctx = ctx;
  return page;
}

/** Dünya (mantıksal) koordinatını sayfa piksel koordinatına çevirir. */
async function toScreen(page, wx, wy) {
  return page.evaluate(([x, y]) => {
    const r = document.querySelector('#game canvas').getBoundingClientRect();
    return { x: r.left + (x / SV.G.W) * r.width, y: r.top + (y / SV.G.H) * r.height };
  }, [wx, wy]);
}

/** Etkin sahnedeki tıklanabilir düğmeleri (Phaser Container) listeler. */
async function buttons(page) {
  return page.evaluate(() => {
    const sc = SV.App.game.scene.getScenes(true)[0];
    const out = [];
    const walk = (o) => {
      if (o.list) o.list.forEach(walk);
      if (o.type === 'Container' && o.input && o.input.enabled && o.visible && o.alpha > 0.05 && o.name) {
        const m = o.getWorldTransformMatrix();
        out.push({ name: o.name, label: o.btnLabel ? o.btnLabel.text : null, x: m.tx, y: m.ty, enabled: o.isEnabled ? o.isEnabled() : true });
      }
    };
    sc.children.list.forEach(walk);
    return out;
  });
}

async function findButton(page, match) {
  const list = await buttons(page);
  const b = list.find((x) => (typeof match === 'string' ? (x.label || x.name).includes(match) : match(x)));
  if (!b) throw new Error('Düğme bulunamadı: ' + match + ' (var olanlar: ' + list.map((x) => x.name).join(' | ') + ')');
  return b;
}

/** Düğmeye gerçek fare tıklaması gönderir (Phaser pointerdown/up). */
async function clickButton(page, match) {
  const b = await findButton(page, match);
  const p = await toScreen(page, b.x, b.y);
  await page.mouse.move(p.x, p.y);
  await page.mouse.down();
  await page.waitForTimeout(60);
  await page.mouse.up();
  return b;
}

/** Düğme görünene kadar bekler. */
async function waitButton(page, match, timeout) {
  const t0 = Date.now();
  for (;;) {
    try { return await findButton(page, match); }
    catch (e) { if (Date.now() - t0 > (timeout || 8000)) throw e; await page.waitForTimeout(100); }
  }
}

/** Sapanla çekiş (sanal çekiş vektörü) yapıp bırakır. Fare ile. */
async function dragShot(page, pull, origin) {
  const o = origin || { x: 420, y: 330 };
  const a = await toScreen(page, o.x, o.y);
  const b = await toScreen(page, o.x + pull.x, o.y + pull.y);
  await page.mouse.move(a.x, a.y);
  await page.mouse.down();
  const N = 8;
  for (let i = 1; i <= N; i++) await page.mouse.move(a.x + ((b.x - a.x) * i) / N, a.y + ((b.y - a.y) * i) / N);
  await page.waitForTimeout(40);
  await page.mouse.up();
}

/** Parmakla (CDP touch olayları) aynı çekişi yapar. */
async function touchShot(page, pull, origin) {
  const o = origin || { x: 420, y: 330 };
  const a = await toScreen(page, o.x, o.y);
  const b = await toScreen(page, o.x + pull.x, o.y + pull.y);
  const cdp = await page.ctx.newCDPSession(page);
  const send = (type, pt) => cdp.send('Input.dispatchTouchEvent', { type, touchPoints: pt ? [{ x: pt.x, y: pt.y, id: 1 }] : [] });
  await send('touchStart', a);
  const N = 8;
  for (let i = 1; i <= N; i++) await send('touchMove', { x: a.x + ((b.x - a.x) * i) / N, y: a.y + ((b.y - a.y) * i) / N });
  await page.waitForTimeout(40);
  await send('touchEnd', null);
  await cdp.detach();
}

/** Sahnedeki çözücü ile hedef (ya da herhangi bir) şişe için çekiş bulur. */
async function solve(page, bottleIndex) {
  return page.evaluate((i) => {
    const sc = SV.App.scene;
    const dead = sc.bottles.map((b, k) => (b.dead ? k : -1)).filter((k) => k >= 0);
    const idx = i == null ? sc.targetBottleIndex() : i;
    return SV.Physics.solveShot(sc.layout, idx, sc.tPhys, { dead });
  }, bottleIndex == null ? null : bottleIndex);
}

const snap = (page) => page.evaluate(() => {
  const s = SV.App.state, sc = SV.App.scene;
  const texts = sc && sc.children ? sc.children.list.filter((o) => o.type === 'Container' || o.type === 'Text') : [];
  return { status: s.status, level: s.level, score: s.score, balls: s.balls, maxBalls: s.maxBalls, targetIndex: s.targetIndex, target: s.target,
    phase: sc && sc.phase, shotNo: sc && sc.shotNo, hasPanel: !!(sc && sc.panel), hud: sc && sc.hud ? sc.hud.countText.text : null };
});

async function waitReady(page, timeout) {
  await page.waitForFunction(() => { const sc = SV.App.scene; return sc && (sc.phase === 'ready' || sc.panel); }, null, { timeout: timeout || 60000 });
}

module.exports = { loadPlaywright, startServer, launch, openPage, toScreen, buttons, findButton, clickButton, waitButton, dragShot, touchShot, solve, snap, waitReady };

/**
 * Fizik adımlarını hızlandırır (yazılım GL'de kare hızı düşük olduğundan test süresini kısaltır).
 * Oyunun kendi adım fonksiyonunu çağırır; kural/çarpışma mantığı gerçektir.
 */
async function fastForward(page, seconds) {
  await page.evaluate((sec) => {
    const sc = SV.App.scene, P = SV.Physics;
    const n = Math.round(sec / P.STEP);
    for (let i = 0; i < n && sc.phase === 'flying'; i++) {
      sc.tPhys += P.STEP;
      sc.set.update(sc.tPhys);
      if (sc.ball && sc.ball.flying) sc.stepFlight();
    }
  }, seconds || 9);
}

/** Bir atış yap: fareyle çek-bırak, fiziği hızlandır, sonuçlanmasını bekle. */
async function shoot(page, pull, how) {
  const before = await page.evaluate(() => SV.App.scene.shotNo);
  await (how === 'touch' ? touchShot : dragShot)(page, pull);
  await page.waitForFunction((n) => SV.App.scene.shotNo > n, before, { timeout: 15000 });
  await fastForward(page, 9);
  await waitReady(page, 30000);
}

module.exports.fastForward = fastForward;
module.exports.shoot = shoot;
