#!/usr/bin/env node
/*
 * Capacitor'un oluşturduğu android/ projesine şunları ekler:
 *   1) AdMob UYGULAMA kimliği  (AndroidManifest.xml meta-data + strings.xml)
 *      -> kimlik config/ads.config.js içinden okunur; kodun içinde kimlik yoktur.
 *   2) Yatay ekran kilidi (sensorLandscape) -> telefon dik tutulsa bile oyun yatay açılır.
 *
 *   node tools/android-patch.js
 *
 * Tekrar çalıştırmak güvenlidir: zaten eklenmiş olan şeye dokunmaz.
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.join(__dirname, '..');
const APP_ID_RE = /^ca-app-pub-\d{16}~\d{10}$/;

/** config/ads.config.js dosyasını tarayıcı olmadan okur. */
function readAdsConfig(file) {
  const sandbox = { window: {} };
  vm.runInNewContext(fs.readFileSync(file || path.join(ROOT, 'config', 'ads.config.js'), 'utf8'), sandbox);
  return sandbox.window.SV_ADS_CONFIG;
}

/** Test modunda Google'ın örnek uygulama kimliğini, değilse gerçek kimliği döndürür. */
function pickAppId(cfg) {
  const a = (cfg && cfg.admob) || {};
  const map = a.useTestAds ? a.testAppId : a.appId;
  const id = ((map && map.android) || '').trim();
  if (!id) {
    throw new Error('AdMob uygulama kimliği yok. config/ads.config.js içinde admob.appId.android alanını doldurun '
      + '(ya da test için useTestAds: true yapın).');
  }
  if (!APP_ID_RE.test(id)) {
    throw new Error('AdMob uygulama kimliği biçimi yanlış: "' + id + '". Beklenen: ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY '
      + '(reklam BİRİMİ kimliği "/" içerir, UYGULAMA kimliği "~" içerir).');
  }
  return id;
}

const META = '<meta-data\n            android:name="com.google.android.gms.ads.APPLICATION_ID"\n            android:value="@string/admob_app_id" />';

function patchManifest(xml) {
  let out = xml;
  if (!out.includes('com.google.android.gms.ads.APPLICATION_ID')) {
    const m = out.match(/<application\b[^>]*>/);
    if (!m) throw new Error('AndroidManifest.xml içinde <application> bulunamadı.');
    const at = m.index + m[0].length;
    out = out.slice(0, at) + '\n\n        ' + META + out.slice(at);
  }
  const act = out.match(/<activity\b[^>]*MainActivity[^>]*>/);
  if (!act) throw new Error('AndroidManifest.xml içinde MainActivity bulunamadı.');
  if (!/android:screenOrientation\s*=/.test(act[0])) {
    const patched = act[0].replace(/<activity\b/, '<activity\n            android:screenOrientation="sensorLandscape"');
    out = out.replace(act[0], () => patched);
  }
  return out;
}

function patchStrings(xml, appId) {
  const re = /(<string\s+name="admob_app_id"[^>]*>)[^<]*(<\/string>)/;
  if (re.test(xml)) return xml.replace(re, (m, a, b) => a + appId + b);
  if (!xml.includes('</resources>')) throw new Error('strings.xml içinde </resources> bulunamadı.');
  return xml.replace('</resources>', () => '    <string name="admob_app_id">' + appId + '</string>\n</resources>');
}

function main() {
  const base = path.join(ROOT, 'android', 'app', 'src', 'main');
  const manifestFile = path.join(base, 'AndroidManifest.xml');
  const stringsFile = path.join(base, 'res', 'values', 'strings.xml');
  if (!fs.existsSync(manifestFile) || !fs.existsSync(stringsFile)) {
    console.error('android/ projesi bulunamadı. Önce şunu çalıştırın:  npx cap add android');
    process.exit(1);
  }
  let appId;
  try { appId = pickAppId(readAdsConfig()); } catch (e) { console.error(e.message); process.exit(1); }
  fs.writeFileSync(manifestFile, patchManifest(fs.readFileSync(manifestFile, 'utf8')));
  fs.writeFileSync(stringsFile, patchStrings(fs.readFileSync(stringsFile, 'utf8'), appId));
  console.log('Android projesi yamalandı: AdMob uygulama kimliği = ' + appId + ', ekran = yatay.');
}

if (require.main === module) main();
module.exports = { readAdsConfig, pickAppId, patchManifest, patchStrings, APP_ID_RE };
