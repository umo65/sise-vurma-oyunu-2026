#!/usr/bin/env node
/*
 * Tek komutla Android APK (debug) üretir:   npm run apk
 *
 *   1. web dosyalarını www/ içine kopyalar          (tools/prepare-www.js)
 *   2. android/ projesi yoksa oluşturur             (npx cap add android)
 *   3. AdMob uygulama kimliği + yatay kilit ekler    (tools/android-patch.js)
 *   4. web dosyalarını ve eklentileri aktarır       (npx cap sync android)
 *   5. APK'yı derler                                (gradlew assembleDebug)
 *   6. sonucu dist/sise-vurma-debug.apk olarak kopyalar
 *
 * Gerekenler: Node 22+, JDK 21, Android SDK (Android Studio ile gelir; ANDROID_HOME tanımlı olmalı).
 * GitHub Actions bunların hepsini hazır sunar (.github/workflows/android-apk.yml).
 */
const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const WIN = process.platform === 'win32';

function run(cmd, args, cwd) {
  console.log('\n> ' + [cmd].concat(args).join(' '));
  const r = spawnSync(cmd, args, { cwd: cwd || ROOT, stdio: 'inherit', shell: WIN });
  if (r.error) { console.error('Komut çalıştırılamadı: ' + cmd + ' (' + r.error.message + ')'); process.exit(1); }
  if (r.status !== 0) { console.error('\nHATA: "' + cmd + ' ' + args.join(' ') + '" başarısız oldu (kod ' + r.status + ').'); process.exit(r.status || 1); }
}

function check() {
  const major = +process.versions.node.split('.')[0];
  if (major < 22) console.warn('UYARI: Capacitor 8 için Node 22 veya üstü gerekir (sizde ' + process.versions.node + ').');
  const j = spawnSync('java', ['-version'], { shell: WIN, encoding: 'utf8' });
  if (j.error || j.status !== 0) console.warn('UYARI: Java (JDK 21) bulunamadı. Gradle derlemesi için gereklidir.');
  const sdk = process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT;
  const localProps = path.join(ROOT, 'android', 'local.properties');
  if (!sdk && !fs.existsSync(localProps)) {
    console.warn('UYARI: Android SDK bulunamadı. Android Studio\'yu kurun ve ANDROID_HOME değişkenini SDK klasörüne ayarlayın.');
  }
}

function main() {
  check();
  if (!fs.existsSync(path.join(ROOT, 'node_modules', '@capacitor', 'core'))) run('npm', ['install']);

  run('node', ['tools/prepare-www.js']);
  if (!fs.existsSync(path.join(ROOT, 'android'))) run('npx', ['cap', 'add', 'android']);
  run('node', ['tools/android-patch.js']);
  run('npx', ['cap', 'sync', 'android']);

  const dir = path.join(ROOT, 'android');
  if (!WIN) { try { fs.chmodSync(path.join(dir, 'gradlew'), 0o755); } catch (e) { /* yoksay */ } }
  run(WIN ? 'gradlew.bat' : './gradlew', ['assembleDebug'], dir);

  const apk = path.join(dir, 'app', 'build', 'outputs', 'apk', 'debug', 'app-debug.apk');
  if (!fs.existsSync(apk)) { console.error('APK beklenen yerde bulunamadı: ' + apk); process.exit(1); }
  const out = path.join(ROOT, 'dist', 'sise-vurma-debug.apk');
  fs.mkdirSync(path.dirname(out), { recursive: true });
  fs.copyFileSync(apk, out);
  console.log('\nAPK HAZIR: ' + out + '  (' + (fs.statSync(out).size / 1048576).toFixed(1) + ' MB)');
  console.log('Telefona aktarıp açın; Android "bilinmeyen kaynaklardan yükleme" izni isteyebilir.');
}

main();
