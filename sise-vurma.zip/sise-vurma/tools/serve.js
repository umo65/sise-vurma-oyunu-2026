#!/usr/bin/env node
/*
 * Bağımlılıksız küçük sunucu: proje klasörünü http://localhost:8080 adresinde sunar
 * ve aynı Wi-Fi'deki telefon için yerel ağ adresini yazar.
 *   node tools/serve.js [port]
 */
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const PORT = +process.argv[2] || +process.env.PORT || 8080;
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json',
  '.woff': 'font/woff', '.woff2': 'font/woff2', '.png': 'image/png', '.svg': 'image/svg+xml', '.txt': 'text/plain; charset=utf-8', '.md': 'text/plain; charset=utf-8' };

http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0]);
  if (p.endsWith('/')) p += 'index.html';
  const file = path.join(ROOT, path.normalize(p));
  if (!file.startsWith(ROOT)) { res.writeHead(403); return res.end('403'); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('404'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(data);
  });
}).listen(PORT, '0.0.0.0', () => {
  console.log('\n  Şişe Vurma çalışıyor\n');
  console.log('  Bilgisayarda : http://localhost:' + PORT);
  Object.values(os.networkInterfaces()).flat().filter((i) => i && i.family === 'IPv4' && !i.internal)
    .forEach((i) => console.log('  Telefonda    : http://' + i.address + ':' + PORT + '   (aynı Wi-Fi ağında)'));
  console.log('\n  Durdurmak için Ctrl+C\n');
});
