#!/usr/bin/env node
/*
 * Capacitor (Android uygulaması) için web dosyalarını www/ klasörüne kopyalar.
 *   node tools/prepare-www.js
 * Testler, araçlar ve belgeler uygulamaya dahil edilmez.
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const OUT = path.join(ROOT, 'www');
const ITEMS = ['index.html', 'config', 'lib', 'src', 'assets'];

fs.rmSync(OUT, { recursive: true, force: true });
fs.mkdirSync(OUT, { recursive: true });
for (const it of ITEMS) fs.cpSync(path.join(ROOT, it), path.join(OUT, it), { recursive: true });
console.log('www/ hazır (' + ITEMS.join(', ') + '). Sıradaki: npx cap sync android');
