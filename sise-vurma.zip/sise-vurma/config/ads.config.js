/*
 * REKLAM YAPILANDIRMASI
 * ---------------------------------------------------------------
 * Gerçek AdMob kimliklerini YALNIZCA bu dosyaya yaz. Kodun içinde
 * (src/core/ads.js) hiçbir reklam kimliği bulunmaz.
 *
 * Çalışma modları (provider):
 *   'auto'  -> Android/Capacitor içinde AdMob eklentisi varsa AdMob,
 *              aksi halde (tarayıcı, geliştirme) SAHTE test reklamı.
 *   'mock'  -> Her zaman sahte test reklamı (geliştirme).
 *   'admob' -> Sadece AdMob. Eklenti/kimlik yoksa "reklam yüklenemedi"
 *              hatası gösterilir, sahte reklama düşülmez.
 */
(function (root) {
  root.SV_ADS_CONFIG = {
    provider: 'auto',

    // true iken adres çubuğundan ?ad=ok|early|loadfail|showfail ve ?adms=400
    // ile test senaryoları zorlanabilir. YAYINA ÇIKARKEN false YAP.
    allowQueryOverrides: true,

    // Reklam başarıyla tamamlanınca verilecek top sayısı
    rewardBalls: 3,

    // Sahte (test) reklam sağlayıcısı ayarları
    mock: {
      loadDelayMs: 500,   // "reklam yükleniyor" süresi
      durationMs: 5000,   // sahte reklamın süresi
      forceResult: null   // null | 'ok' | 'early' | 'loadfail' | 'showfail'
    },

    // AdMob (Capacitor + @capacitor-community/admob ile yerel Android)
    admob: {
      // Geliştirirken true. Yayına çıkarken false yap.
      useTestAds: true,

      // Google'ın herkese açık ÖRNEK test reklam birimi (gelir getirmez).
      // Doğrulamak için: AdMob dokümanındaki "test ads" sayfasına bak.
      testRewardedAdUnitId: {
        android: 'ca-app-pub-3940256099942544/5224354917'
      },

      // GERÇEK ödüllü reklam birimi kimliğin: AdMob panelinden alıp buraya yaz.
      // Örnek biçim: 'ca-app-pub-XXXXXXXXXXXXXXXX/YYYYYYYYYY'
      rewardedAdUnitId: {
        android: ''
      },

      // AdMob UYGULAMA kimliği (reklam birimi kimliğinden farklıdır, "~" içerir).
      // APK oluşturulurken (tools/android-patch.js) AndroidManifest.xml'e buradan yazılır;
      // eksikse Android uygulaması açılışta çöker.
      // useTestAds: true iken Google'ın herkese açık ÖRNEK uygulama kimliği kullanılır
      // (https://developers.google.com/admob/android/quick-start), gelir getirmez.
      testAppId: {
        android: 'ca-app-pub-3940256099942544~3347511713'
      },
      // GERÇEK AdMob uygulama kimliğin. Örnek biçim: 'ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY'
      appId: {
        android: ''
      }
    }
  };
})(typeof window !== 'undefined' ? window : globalThis);
