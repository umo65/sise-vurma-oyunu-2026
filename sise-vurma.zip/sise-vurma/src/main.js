/*
 * GİRİŞ NOKTASI: ekran ölçüleri, Phaser kurulumu, yeniden boyutlandırma, dönüş uyarısı.
 *
 * MANTIKSAL EKRAN: yükseklik her zaman 720; genişlik (SV.G.W) cihazın en-boy oranına
 * göre 1152–1584 arasında seçilir (telefonlarda kenar boşluğu kalmaz). Gerçek tuval
 * R kat büyüktür (R = ekran yoğunluğu, 1–2): her şey R ile keskin çizilir, kamera zoom=R
 * ile mantıksal koordinatları tuvale oturtur. Phaser FIT modu tuvali pencereye sığdırır.
 */
(function (root) {
  'use strict';
  const SV = (root.SV = root.SV || {});
  const U = SV.U;
  const doc = root.document;

  const H = 720;
  const G = (SV.G = { W: 1280, H, R: 1, sling: null });
  const App = (SV.App = { game: null, state: null, ads: null, presenter: null, scene: null, resume: null });

  /** Pencereye göre mantıksal genişlik (W) ve çözünürlük katsayısı (R). */
  function measure() {
    const w = root.innerWidth || 1280, h = root.innerHeight || 720;
    const long = Math.max(w, h), short = Math.min(w, h); // dik tutulsa bile yatay düzen kur
    const aspect = U.clamp(long / short, 1.6, 2.2);
    const W = Math.round((H * aspect) / 8) * 8;
    const cssH = Math.min(short, long / (W / H));          // tuvalin ekrandaki yüksekliği (CSS px)
    const dpr = root.devicePixelRatio || 1;
    const R = Math.round(U.clamp((cssH / H) * dpr, 1, 2) * 4) / 4;
    return { W, R };
  }

  function createGame() {
    const m = measure();
    G.W = m.W; G.R = m.R;
    SV.Tex.resetCaches();
    App.game = new Phaser.Game({
      type: Phaser.AUTO,
      parent: 'game',
      width: Math.round(G.W * G.R),
      height: Math.round(G.H * G.R),
      backgroundColor: '#7fd0ff',
      scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH },
      render: { antialias: true, roundPixels: false, powerPreference: 'high-performance' },
      input: { activePointers: 3, touch: { capture: true } },
      fps: { target: 60 },
      banner: false,
      disableContextMenu: true,
      scene: [SV.BootScene, SV.MenuScene, SV.GameScene]
    });
  }

  /** Pencere/yön değişince: düzen çok değiştiyse oyunu yeni ölçülerle yeniden kur. */
  function rebuildIfNeeded() {
    const m = measure();
    if (Math.abs(m.W - G.W) < 96 && Math.abs(m.R - G.R) < 0.5) return;
    const scenes = App.game.scene.getScenes(true);
    const cur = scenes.length ? scenes[0].scene.key : 'Menu';
    // Oyun sırasında yeniden kurulursa aynı bölüm baştan başlar (puan korunur).
    App.resume = cur === 'Game' ? { scene: 'Game', level: App.state.level, mode: 'restart' } : null;
    App.game.destroy(true);
    createGame();
  }

  /* ----- Dikey tutulursa "yatay çevir" uyarısı (kapatılabilir) ----- */
  let rotateDismissed = false;
  function updateOrientation() {
    const portrait = (root.innerHeight || 0) > (root.innerWidth || 0) * 1.05;
    doc.body.classList.toggle('portrait', portrait && !rotateDismissed);
  }

  let timer = 0;
  function onResize() {
    updateOrientation();
    clearTimeout(timer);
    timer = setTimeout(rebuildIfNeeded, 350);
  }

  function start() {
    SV.Audio.init();
    App.state = new SV.GameState({ rewardBalls: root.SV_ADS_CONFIG.rewardBalls });
    App.presenter = new SV.MockAdPresenter(doc.getElementById('mockad'));
    App.ads = new SV.Ads.AdManager(root.SV_ADS_CONFIG, App.presenter);

    const dismiss = doc.getElementById('rotate-skip');
    if (dismiss) dismiss.addEventListener('click', () => { rotateDismissed = true; updateOrientation(); });
    root.addEventListener('resize', onResize);
    root.addEventListener('orientationchange', onResize);
    // Tarayıcı ilk dokunuşta sesi açar
    const unlock = () => SV.Audio.unlock();
    doc.addEventListener('pointerdown', unlock, { passive: true });
    doc.addEventListener('pointerup', unlock, { passive: true });   // dokunmatikte etkinleştirme pointerup/touchend ile olur
    doc.addEventListener('touchend', unlock, { passive: true });
    doc.addEventListener('keydown', unlock);

    updateOrientation();
    createGame();
  }

  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', start);
  else start();
})(typeof window !== 'undefined' ? window : globalThis);
