/*
 * OYUN İÇİ ARAYÜZ (HUD)
 *   Üst sıra : BÖLÜM n   |   PUAN   |   TOP 2/2 (top simgeleri)
 *   İkinci sıra: HEDEF rengi + ilerleme noktaları (6 hedef sırayla vurulur)
 * Her şey mantıksal koordinatta (yükseklik 720) ve ekran genişliğine göre hizalanır.
 */
(function (root) {
  'use strict';
  const SV = (root.SV = root.SV || {});
  const UI = SV.UI;
  const hexInt = (h) => parseInt(String(h).replace('#', ''), 16);
  const BALL_ORDER = ['red', 'blue', 'green', 'yellow', 'purple', 'orange'];

  function pillImage(scene, cx, cy, w, h, tone) {
    // pillTexture: kart (w+12) x (h+16); hap, kartın (6,4) noktasında -> merkez 4 px yukarıda
    return scene.add.image(cx, cy + 4, UI.pillTexture(scene, w, h, tone)).setScale(1 / SV.G.R);
  }

  class Hud {
    constructor(scene, state) {
      const W = SV.G.W;
      this.scene = scene;
      this.state = state;
      this.root = scene.add.container(0, 0).setDepth(100);
      const add = (o) => { this.root.add(o); return o; };

      // Bölüm
      const lx = 24 + 110;
      add(pillImage(scene, lx, 50, 220, 64, 'dark'));
      this.levelText = add(UI.text(scene, lx, 49, 'BÖLÜM 1', { size: 32 }));

      // Puan
      add(pillImage(scene, W / 2, 50, 320, 64, 'dark'));
      this.scoreText = add(UI.text(scene, W / 2, 49, 'PUAN  0', { size: 34 }));
      this.scoreShown = 0;

      // Top sayısı
      const bx = W - 24 - 150;
      this.ballsX = bx;
      add(pillImage(scene, bx, 50, 300, 64, 'dark'));
      add(UI.text(scene, bx - 104, 49, 'TOP', { size: 30 }));
      this.countText = add(UI.text(scene, bx + 96, 49, '2/2', { size: 38, color: '#ffe566' }));
      this.ballIcons = [];
      for (let i = 0; i < 3; i++) {
        const ic = scene.add.image(bx - 40 + i * 38, 50, 'ball_red').setScale(0.62 / SV.G.R);
        this.ballIcons.push(add(ic));
      }

      // Hedef bandı
      const ty = 126;
      this.targetY = ty;
      add(pillImage(scene, W / 2, ty, 640, 68, 'dark'));
      add(UI.text(scene, W / 2 - 262, ty - 1, 'HEDEF', { size: 28, color: '#bfe3ff' }));
      this.chip = add(scene.add.graphics());
      this.chipPos = { x: W / 2 - 170, y: ty };
      this.nameText = add(UI.text(scene, W / 2 - 138, ty - 1, 'KIRMIZI', { size: 38, ox: 0 }));
      this.dots = add(scene.add.graphics());
      this.dotsX = W / 2 + 76;

      this.refresh(false);
    }

    /** Tüm göstergeleri durumdan yeniler. */
    refresh(animate) {
      this.setLevel();
      this.setScore(this.state.score, animate);
      this.setBalls();
      this.setTarget(animate);
    }

    setLevel() { this.levelText.setText('BÖLÜM ' + this.state.level); }

    setScore(v, animate) {
      const s = this.scene;
      if (this.scoreTween) { this.scoreTween.stop(); this.scoreTween = null; }
      if (!animate || v === this.scoreShown) {
        this.scoreShown = v; this.scoreText.setText('PUAN  ' + v); return;
      }
      const from = this.scoreShown;
      this.scoreTween = s.tweens.addCounter({
        from, to: v, duration: 550, ease: 'Sine.easeOut',
        onUpdate: (tw) => { this.scoreShown = Math.round(tw.getValue()); this.scoreText.setText('PUAN  ' + this.scoreShown); },
        onComplete: () => { this.scoreShown = v; this.scoreText.setText('PUAN  ' + v); }
      });
      s.tweens.add({ targets: this.scoreText, scale: 1.18, duration: 110, yoyo: true, ease: 'Quad.easeOut' });
    }

    setBalls() {
      const st = this.state;
      const max = Math.max(st.maxBalls, 1);
      this.countText.setText(st.balls + '/' + st.maxBalls);
      const total = Math.max(2, max);
      const x0 = this.ballsX - 40 - (total === 2 ? -19 : 0);
      for (let i = 0; i < 3; i++) {
        const ic = this.ballIcons[i];
        ic.setVisible(i < total);
        ic.x = x0 + i * 38;
        const have = i < st.balls;
        ic.setTexture('ball_' + BALL_ORDER[i % BALL_ORDER.length]);
        ic.setAlpha(have ? 1 : 0.28);
        ic.setTint(have ? 0xffffff : 0x667788);
      }
    }

    /** Top kaybı: sayaç sarsılır. */
    shakeBalls() {
      const s = this.scene, t = this.countText;
      s.tweens.add({ targets: t, scale: 1.5, duration: 120, yoyo: true, ease: 'Quad.easeOut' });
      this.ballIcons.forEach((ic) => s.tweens.add({ targets: ic, angle: { from: -14, to: 14 }, duration: 60, yoyo: true, repeat: 2, onComplete: () => ic.setAngle(0) }));
    }

    /** Ödül sonrası: sayaç parlar. */
    pulseBalls() {
      this.scene.tweens.add({ targets: [this.countText, ...this.ballIcons], scale: '*=1.35', duration: 150, yoyo: true, ease: 'Back.easeOut' });
    }

    setTarget(animate) {
      const st = this.state;
      const L = SV.Levels;
      const idx = Math.min(st.targetIndex, st.targets.length - 1);
      const col = L.BY_ID[st.targets[idx]] || L.COLORS[0];
      const g = this.chip, c = this.chipPos;
      g.clear();
      g.fillStyle(0x000000, 0.25); g.fillCircle(c.x, c.y + 3, 24);
      g.fillStyle(hexInt(col.hex), 1); g.fillCircle(c.x, c.y, 23);
      g.fillStyle(hexInt(col.light), 0.85); g.fillCircle(c.x - 7, c.y - 8, 8);
      g.lineStyle(4, 0xffffff, 1); g.strokeCircle(c.x, c.y, 23);
      this.nameText.setText(col.name);
      this.nameText.setStroke(col.dark, 8);

      const d = this.dots;
      d.clear();
      const n = st.targets.length;
      for (let i = 0; i < n; i++) {
        const cc = L.BY_ID[st.targets[i]];
        const x = this.dotsX + i * 36, y = this.targetY;
        const done = i < st.targetIndex, cur = i === st.targetIndex;
        d.fillStyle(hexInt(cc.hex), done ? 0.4 : 1);
        d.fillCircle(x, y, cur ? 14 : 10);
        d.lineStyle(cur ? 4 : 2.5, 0xffffff, done ? 0.55 : 1);
        d.strokeCircle(x, y, cur ? 14 : 10);
        if (done) {
          d.lineStyle(3.5, 0xffffff, 1);
          d.beginPath(); d.moveTo(x - 5, y); d.lineTo(x - 1, y + 5); d.lineTo(x + 6, y - 5); d.strokePath();
        }
      }
      if (animate) {
        this.scene.tweens.add({ targets: this.nameText, scale: { from: 1.5, to: 1 }, duration: 320, ease: 'Back.easeOut' });
      }
    }

    destroy() { this.root.destroy(); }
  }

  SV.Hud = Hud;
})(typeof window !== 'undefined' ? window : globalThis);
