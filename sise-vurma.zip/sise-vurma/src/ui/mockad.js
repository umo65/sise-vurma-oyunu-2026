/*
 * SAHTE (TEST) REKLAM EKRANI — yalnızca geliştirme sırasında kullanılır.
 *
 * MockProvider reklamı göstermek için bu sunucuyu (presenter) çağırır:
 *   showMockAd({ durationMs, autoCloseAfterMs }) -> Promise<'completed' | 'closed'>
 *
 *  - Geri sayım bitmeden "Kapat" -> 'closed'    (ödül YOK)
 *  - Geri sayım bitince "Ödülü al" -> 'completed' (ödül VAR)
 *  - autoCloseAfterMs > 0 ise (test: ?ad=early) kullanıcı erken kapatmış gibi davranır.
 *
 * Gerçek AdMob reklamı bu ekranı kullanmaz; reklam yerel Android penceresinde açılır.
 */
(function (root) {
  'use strict';
  const SV = (root.SV = root.SV || {});

  class MockAdPresenter {
    /** @param el  #mockad DOM öğesi (index.html) */
    constructor(el) {
      this.el = el;
      this.open = false;
    }

    showMockAd(opts) {
      const el = this.el;
      const dur = Math.max(300, (opts && opts.durationMs) || 5000);
      const autoClose = (opts && opts.autoCloseAfterMs) || 0;
      if (!el) return Promise.resolve('completed'); // DOM yoksa (Node testleri) anında tamamla

      return new Promise((resolve) => {
        this.open = true;
        el.innerHTML =
          '<div class="ad-box" role="dialog" aria-label="Test reklamı">' +
          '  <div class="ad-badge">TEST REKLAMI</div>' +
          '  <div class="ad-art" aria-hidden="true"><i></i><i></i><i></i></div>' +
          '  <div class="ad-title">Örnek ödüllü reklam</div>' +
          '  <div class="ad-note">Gerçek reklam yalnızca AdMob ile Android uygulamasında gösterilir.</div>' +
          '  <div class="ad-count">Ödüle kalan süre: <b></b> sn</div>' +
          '  <div class="ad-bar"><span></span></div>' +
          '  <button type="button" class="ad-close">✕ KAPAT (ödül yok)</button>' +
          '  <button type="button" class="ad-claim" hidden>KAPAT VE ÖDÜLÜ AL</button>' +
          '</div>';
        el.hidden = false;

        const $ = (s) => el.querySelector(s);
        const count = $('.ad-count'), secs = $('.ad-count b'), bar = $('.ad-bar span');
        const closeBtn = $('.ad-close'), claimBtn = $('.ad-claim');
        const t0 = Date.now();
        let finished = false, earned = false;

        const finish = (result) => {
          if (finished) return;
          finished = true;
          clearInterval(tick);
          clearTimeout(auto);
          el.hidden = true;
          el.innerHTML = '';
          this.open = false;
          resolve(result);
        };

        const tick = setInterval(() => {
          const left = Math.max(0, dur - (Date.now() - t0));
          secs.textContent = String(Math.ceil(left / 1000));
          bar.style.width = (100 * (1 - left / dur)).toFixed(1) + '%';
          if (left <= 0 && !earned) {
            earned = true;
            clearInterval(tick);
            count.textContent = 'Tebrikler! Ödül kazandın.';
            closeBtn.hidden = true;
            claimBtn.hidden = false;
          }
        }, 80);
        secs.textContent = String(Math.ceil(dur / 1000));

        closeBtn.addEventListener('click', () => finish('closed'));
        claimBtn.addEventListener('click', () => finish('completed'));
        const auto = autoClose ? setTimeout(() => finish(earned ? 'completed' : 'closed'), autoClose) : 0;
      });
    }
  }

  SV.MockAdPresenter = MockAdPresenter;
})(typeof window !== 'undefined' ? window : globalThis);
