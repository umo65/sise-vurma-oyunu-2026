/*
 * ARAYÜZ YARDIMCILARI: metin, düğme, panel, modal.
 * Her şey canvas ile çizilen dokulardan oluşur (dosya gerekmez) ve R (çözünürlük)
 * ile keskin görünür. Düğmeler mobilde parmakla kolay basılacak kadar büyüktür.
 */
(function (root) {
  'use strict';
  const SV = (root.SV = root.SV || {});
  const { mk, put, lin } = SV.TexUtil;
  const roundRect = SV.BottleArt.roundRect;

  const FONT = 'Baloo2, "Arial Rounded MT Bold", "Trebuchet MS", Arial, sans-serif';

  const PALETTE = {
    green:  { top: '#b4ff6e', mid: '#52d63c', bot: '#2a9a2e', edge: '#15601b', text: '#12501a' },
    blue:   { top: '#a0dcff', mid: '#3d9eff', bot: '#1f5fd6', edge: '#12388a', text: '#10306e' },
    orange: { top: '#ffe08a', mid: '#ffa030', bot: '#e66a0c', edge: '#8a3a06', text: '#6e2d05' },
    red:    { top: '#ffa89c', mid: '#ff4d4d', bot: '#c8181f', edge: '#70101a', text: '#6a0f14' },
    purple: { top: '#d9b8ff', mid: '#9b5cff', bot: '#6128d0', edge: '#341478', text: '#2c1068' },
    gray:   { top: '#e3ebf5', mid: '#b9c6d8', bot: '#8798b0', edge: '#46566e', text: '#2b384c' }
  };

  /** Metin: kalın yuvarlak font + koyu kontur; R kadar yüksek çözünürlükte çizilir. */
  function text(scene, x, y, str, o) {
    o = o || {};
    const t = scene.add.text(x, y, str, {
      fontFamily: FONT,
      fontSize: (o.size || 32) + 'px',
      fontStyle: '800',
      color: o.color || '#ffffff',
      stroke: o.stroke || '#1b3b6b',
      strokeThickness: o.sw == null ? Math.max(3, Math.round((o.size || 32) / 6)) : o.sw,
      align: o.align || 'center',
      lineSpacing: o.lineSpacing || 0,
      wordWrap: o.wrap ? { width: o.wrap, useAdvancedWrap: true } : undefined,
      shadow: o.shadow === false ? undefined : { offsetX: 0, offsetY: o.shadowY == null ? 3 : o.shadowY, color: 'rgba(10,30,70,0.35)', blur: 0, stroke: true, fill: true },
      resolution: SV.G.R
    });
    t.setOrigin(o.ox == null ? 0.5 : o.ox, o.oy == null ? 0.5 : o.oy);
    if (o.depth != null) t.setDepth(o.depth);
    return t;
  }

  /* ------------------------------ Dokular ------------------------------ */
  const PAD = 12;

  function buttonTexture(scene, w, h, pal, radius) {
    const key = 'ui_btn_' + w + 'x' + h + '_' + pal + '_' + radius;
    if (scene.textures.exists(key)) return key;
    const P = PALETTE[pal] || PALETTE.green;
    const c = mk(w + PAD * 2, h + PAD * 2 + 6);
    const ctx = c.ctx, x = PAD, y = PAD, lip = 7;
    // zemin gölgesi
    ctx.fillStyle = 'rgba(10,40,20,0.30)';
    roundRect(ctx, x, y + 8, w, h, radius); ctx.fill();
    // kenar (koyu) + alt dudak
    ctx.fillStyle = P.edge;
    roundRect(ctx, x, y, w, h, radius); ctx.fill();
    ctx.fillStyle = lin(ctx, 0, y, 0, y + h, [[0, P.mid], [1, P.bot]]);
    roundRect(ctx, x + 3, y + 3, w - 6, h - 3 - lip + 3, radius - 2); ctx.fill();
    // gövde
    ctx.fillStyle = lin(ctx, 0, y + 3, 0, y + h - lip, [[0, P.top], [0.5, P.mid], [1, P.bot]]);
    roundRect(ctx, x + 4, y + 4, w - 8, h - lip - 6, radius - 3); ctx.fill();
    // parlama
    ctx.save();
    roundRect(ctx, x + 4, y + 4, w - 8, h - lip - 6, radius - 3); ctx.clip();
    ctx.fillStyle = 'rgba(255,255,255,0.30)';
    ctx.beginPath(); ctx.ellipse(x + w / 2, y - h * 0.16, w * 0.62, h * 0.58, 0, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(x + radius, y + 6); ctx.lineTo(x + w - radius, y + 6); ctx.stroke();
    put(scene, key, c);
    return key;
  }

  function circleButtonTexture(scene, d, pal) {
    const key = 'ui_cbtn_' + d + '_' + pal;
    if (scene.textures.exists(key)) return key;
    const P = PALETTE[pal] || PALETTE.green;
    const c = mk(d + PAD * 2, d + PAD * 2 + 6);
    const ctx = c.ctx, cx = PAD + d / 2, cy = PAD + d / 2, r = d / 2;
    ctx.fillStyle = 'rgba(10,40,20,0.30)';
    ctx.beginPath(); ctx.arc(cx, cy + 8, r, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = P.edge;
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = P.bot;
    ctx.beginPath(); ctx.arc(cx, cy, r - 3, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = lin(ctx, 0, cy - r, 0, cy + r, [[0, P.top], [0.55, P.mid], [1, P.bot]]);
    ctx.beginPath(); ctx.arc(cx, cy - 2, r - 5, 0, Math.PI * 2); ctx.fill();
    ctx.save(); ctx.beginPath(); ctx.arc(cx, cy - 2, r - 5, 0, Math.PI * 2); ctx.clip();
    ctx.fillStyle = 'rgba(255,255,255,0.30)';
    ctx.beginPath(); ctx.ellipse(cx, cy - r * 0.62, r * 0.9, r * 0.55, 0, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    put(scene, key, c);
    return key;
  }

  function pillTexture(scene, w, h, tone) {
    const key = 'ui_pill_' + w + 'x' + h + '_' + tone;
    if (scene.textures.exists(key)) return key;
    const tones = {
      dark:  ['rgba(20,50,100,0.78)', 'rgba(10,30,70,0.88)', 'rgba(255,255,255,0.9)'],
      light: ['rgba(255,255,255,0.92)', 'rgba(220,238,255,0.92)', 'rgba(40,90,170,0.95)']
    };
    const t = tones[tone] || tones.dark;
    const c = mk(w + 12, h + 16);
    const ctx = c.ctx;
    ctx.fillStyle = 'rgba(10,40,70,0.25)'; roundRect(ctx, 6, 10, w, h, h / 2); ctx.fill();
    ctx.fillStyle = lin(ctx, 0, 4, 0, h, [[0, t[0]], [1, t[1]]]);
    roundRect(ctx, 6, 4, w, h, h / 2); ctx.fill();
    ctx.strokeStyle = t[2]; ctx.lineWidth = 3.5;
    roundRect(ctx, 7.5, 5.5, w - 3, h - 3, (h - 3) / 2); ctx.stroke();
    put(scene, key, c);
    return key;
  }

  function panelTexture(scene, w, h) {
    const key = 'ui_panel_' + w + 'x' + h;
    if (scene.textures.exists(key)) return key;
    const c = mk(w + 24, h + 32);
    const ctx = c.ctx, r = 36;
    ctx.fillStyle = 'rgba(5,25,60,0.35)'; roundRect(ctx, 12, 22, w, h, r); ctx.fill();
    ctx.fillStyle = '#16407f'; roundRect(ctx, 12, 12, w, h, r); ctx.fill();
    ctx.fillStyle = lin(ctx, 0, 12, 0, 12 + h, [[0, '#fffdf2'], [1, '#ffeec4']]);
    roundRect(ctx, 18, 18, w - 12, h - 12, r - 6); ctx.fill();
    ctx.strokeStyle = 'rgba(255,170,60,0.55)'; ctx.lineWidth = 4;
    roundRect(ctx, 26, 26, w - 28, h - 28, r - 14); ctx.stroke();
    put(scene, key, c);
    return key;
  }

  /* ------------------------------ Düğme ------------------------------ */
  /**
   * o: { x, y, w, h, label, palette, size, icon, iconScale, round (çap), onClick, depth, sw }
   * Dönen nesne: Phaser Container + setEnabled/setLabel/setPalette/setIcon
   */
  function button(scene, o) {
    const R = SV.G.R;
    const c = scene.add.container(o.x, o.y);
    const isRound = !!o.round;
    const w = isRound ? o.round : o.w, h = isRound ? o.round : o.h;
    let pal = o.palette || 'green';
    const mkKey = () => (isRound ? circleButtonTexture(scene, o.round, pal) : buttonTexture(scene, w, h, pal, o.radius || Math.round(h * 0.34)));
    const img = scene.add.image(0, 3, mkKey()).setScale(1 / R);
    c.add(img);
    let label = null, icon = null;
    if (o.label) {
      label = text(scene, o.icon ? Math.round(w * 0.1) : 0, -3, o.label, {
        size: o.size || 34, stroke: PALETTE[pal].text, sw: o.sw == null ? Math.max(4, Math.round((o.size || 34) / 7)) : o.sw,
        wrap: o.wrap || (w - 40), lineSpacing: -6
      });
      c.add(label);
    }
    if (o.icon) {
      icon = scene.add.image(o.label ? -Math.round(w / 2) + Math.round(h * 0.62) : 0, -3, 'icon_' + o.icon)
        .setScale((o.iconScale || (isRound ? 0.9 : 0.85)) / R * (isRound ? w / 76 : h / 84));
      c.add(icon);
    }
    c.setSize(w + 8, h + 8);
    c.setName(o.name || o.label || ('icon:' + (o.icon || '')));   // testler ve hata ayıklama için
    c.setInteractive({ useHandCursor: true });
    if (o.depth != null) c.setDepth(o.depth);

    let enabled = true, pressed = false;
    const press = (v) => {
      scene.tweens.killTweensOf(c);
      scene.tweens.add({ targets: c, scale: v ? 0.93 : 1, duration: v ? 70 : 140, ease: v ? 'Quad.easeOut' : 'Back.easeOut' });
    };
    c.on('pointerdown', (p, lx, ly, ev) => {
      if (!enabled) return;
      if (ev && ev.stopPropagation) ev.stopPropagation();
      pressed = true; press(true);
      SV.Audio.unlock();
    });
    c.on('pointerout', () => { if (pressed) { pressed = false; press(false); } });
    c.on('pointerup', () => {
      if (!enabled || !pressed) return;
      pressed = false; press(false);
      SV.Audio.play('click');
      if (o.onClick) o.onClick(c);
    });

    c.setEnabled = function (v) {
      enabled = !!v;
      c.setAlpha(v ? 1 : 0.55);
      if (!v) { pressed = false; c.setScale(1); }
      return c;
    };
    c.isEnabled = () => enabled;
    c.setLabel = function (s, size) {
      if (label) { label.setText(s); if (size) label.setFontSize(size); }
      return c;
    };
    c.setPalette = function (p) {
      pal = p; img.setTexture(mkKey());
      if (label) label.setStroke(PALETTE[pal].text, label.style.strokeThickness);
      return c;
    };
    c.setIcon = function (name) { if (icon) icon.setTexture('icon_' + name); return c; };
    c.btnLabel = label;
    return c;
  }

  /* ------------------------------ Modal ------------------------------ */
  /**
   * Tam ekran karartma + panel. o: { w, h, title, titleColor, depth }
   * Dönüş: { root, body (içerik konteyneri, panel merkezi (0,0)), panel, close(), ... }
   */
  function modal(scene, o) {
    const W = SV.G.W, H = SV.G.H, R = SV.G.R;
    const depth = o.depth || 200;
    const root = scene.add.container(0, 0).setDepth(depth);
    const dim = scene.add.rectangle(W / 2, H / 2, W + 4, H + 4, 0x06203f, 0.62).setInteractive();
    dim.on('pointerdown', (p, lx, ly, ev) => { if (ev && ev.stopPropagation) ev.stopPropagation(); });
    root.add(dim);
    const panel = scene.add.container(W / 2, H / 2);
    const pimg = scene.add.image(0, 0, panelTexture(scene, o.w, o.h)).setScale(1 / R);
    panel.add(pimg);
    const body = scene.add.container(0, 0);
    panel.add(body);
    if (o.title) {
      const tw = Math.min(o.w - 40, Math.max(360, o.title.length * 30 + 120));
      const ribbon = scene.add.image(0, -o.h / 2 + 6, buttonTexture(scene, tw, 84, o.titleColor || 'orange', 42)).setScale(1 / R);
      const title = text(scene, 0, -o.h / 2 + 2, o.title, { size: o.titleSize || 46, stroke: PALETTE[o.titleColor || 'orange'].text, sw: 7 });
      panel.add([ribbon, title]);
      panel.titleText = title;
    }
    root.add(panel);

    root.setAlpha(0);
    panel.setScale(0.78);
    scene.tweens.add({ targets: root, alpha: 1, duration: 160 });
    scene.tweens.add({ targets: panel, scale: 1, duration: 360, ease: 'Back.easeOut' });

    const api = {
      root, body, panel, dim,
      close(done) {
        scene.tweens.add({
          targets: root, alpha: 0, duration: 150,
          onComplete: () => { root.destroy(); if (done) done(); }
        });
      },
      destroy() { root.destroy(); }
    };
    return api;
  }

  /** Yüzen puan/uyarı yazısı. */
  function popup(scene, x, y, str, o) {
    o = o || {};
    const t = text(scene, x, y, str, { size: o.size || 44, color: o.color || '#fff', stroke: o.stroke || '#1b3b6b', sw: 7, depth: 150 });
    t.setScale(0.4).setAlpha(0);
    scene.tweens.add({ targets: t, scale: 1, alpha: 1, duration: 200, ease: 'Back.easeOut' });
    scene.tweens.add({ targets: t, y: y - (o.rise || 70), duration: o.life || 1100, ease: 'Sine.easeOut' });
    scene.tweens.add({ targets: t, alpha: 0, delay: (o.life || 1100) - 350, duration: 350, onComplete: () => t.destroy() });
    return t;
  }

  SV.UI = { FONT, PALETTE, text, button, modal, popup, buttonTexture, pillTexture, panelTexture, circleButtonTexture };
})(typeof window !== 'undefined' ? window : globalThis);
