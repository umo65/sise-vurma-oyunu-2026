/*
 * OYUN PENCERELERİ
 *   outOfBalls    : "Topların bitti!"  -> REKLAM İZLE (3 EKSTRA TOP) / BÖLÜMÜ YENİDEN BAŞLAT
 *   levelComplete : "BÖLÜM TAMAMLANDI!" -> yıldızlar, puan, kalan top, SONRAKİ BÖLÜM
 * Pencereler yalnızca görünümdür; oyun kuralları GameState ve GameScene'dedir.
 */
(function (root) {
  'use strict';
  const SV = (root.SV = root.SV || {});
  const UI = SV.UI;
  const INK = '#16407f';   // krem panel üstünde koyu mavi yazı

  const dark = (scene, x, y, str, o) =>
    UI.text(scene, x, y, str, Object.assign({ size: 28, color: INK, stroke: '#ffffff', sw: 0, shadow: false }, o));

  /* ---------------------------------------------------------------- */
  function outOfBalls(scene, o) {
    const R = SV.G.R;
    const m = UI.modal(scene, { w: 820, h: 560, title: 'Topların bitti!', titleColor: 'red', titleSize: 52, depth: 200 });
    const b = m.body;
    b.add(dark(scene, 0, -150, 'Reklam izleyip ' + o.rewardBalls + ' ekstra top kazan\nya da bölümü baştan başlat.', { size: 29, wrap: 700, lineSpacing: 4 }));

    // ödül gösterimi: 3 top
    const row = [];
    const ids = ['red', 'blue', 'yellow'];
    for (let i = 0; i < o.rewardBalls; i++) {
      const im = scene.add.image((i - (o.rewardBalls - 1) / 2) * 62, -66, 'ball_' + ids[i % ids.length]).setScale(0.95 / R);
      scene.tweens.add({ targets: im, y: -74, duration: 520 + i * 90, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
      row.push(im); b.add(im);
    }

    const watch = UI.button(scene, {
      x: 0, y: 36, w: 740, h: 104, label: 'REKLAM İZLE — ' + o.rewardBalls + ' EKSTRA TOP KAZAN',
      palette: 'orange', size: 31, icon: 'video', onClick: () => api.busy || o.onWatch(api)
    });
    const status = dark(scene, 0, 112, '', { size: 25, wrap: 720, lineSpacing: 2 });
    status.setVisible(false);
    const restart = UI.button(scene, {
      x: 0, y: 198, w: 740, h: 90, label: 'BÖLÜMÜ YENİDEN BAŞLAT',
      palette: 'blue', size: 33, icon: 'restart', onClick: () => api.busy || o.onRestart(api)
    });
    b.add([watch, status, restart]);

    const api = {
      modal: m, busy: false, watch, restart,
      /** Reklam isteği sürerken düğmeleri kilitle ve durum yaz. */
      setBusy(v, label) {
        api.busy = !!v;
        watch.setEnabled(!v); restart.setEnabled(!v);
        if (v) { watch.setLabel(label || 'REKLAM YÜKLENİYOR…', 30); api.setStatus('', ''); }
      },
      /** kind: 'error' | 'warn' | 'info' | '' */
      setStatus(text, kind) {
        status.setVisible(!!text);
        status.setText(text || '');
        status.setColor(kind === 'error' ? '#c21f2a' : kind === 'warn' ? '#b4560a' : INK);
      },
      setWatchLabel(text, size) { watch.setLabel(text, size || 31); },
      close() { m.close(); }
    };
    api.watchLabel = watch.btnLabel.text;
    return api;
  }

  /* ---------------------------------------------------------------- */
  function levelComplete(scene, o) {
    const R = SV.G.R;
    const m = UI.modal(scene, { w: 760, h: 600, title: 'BÖLÜM TAMAMLANDI!', titleColor: 'green', titleSize: 46, depth: 200 });
    const b = m.body;

    // yıldızlar
    const stars = [];
    for (let i = 0; i < 3; i++) {
      const on = i < o.stars;
      const im = scene.add.image((i - 1) * 132, -158 + (i === 1 ? -14 : 0), on ? 'star_on' : 'star_off').setScale(0.001);
      stars.push({ im, on, i });
      b.add(im);
    }
    stars.forEach((s) => {
      const target = (s.i === 1 ? 2.2 : 1.8) / R;
      scene.tweens.add({
        targets: s.im, scale: target, angle: { from: -25, to: s.i === 0 ? -8 : s.i === 2 ? 8 : 0 },
        delay: 350 + s.i * 260, duration: 420, ease: 'Back.easeOut',
        onStart: () => { if (s.on) SV.Audio.play('coin'); }
      });
    });

    const rowY = [-26, 34, 104];
    const label = (y, str) => dark(scene, -300, y, str, { ox: 0, size: 30 });
    const value = (y, str, o2) => dark(scene, 300, y, str, Object.assign({ ox: 1, size: 38 }, o2));
    b.add(label(rowY[0], 'KAZANILAN PUAN'));
    b.add(value(rowY[0], '+' + o.earned, { color: '#1a8f2e' }));
    b.add(label(rowY[1], 'KALAN TOP'));
    b.add(value(rowY[1], o.ballsLeft + ' / ' + o.maxBalls, { color: '#d96a0a' }));
    b.add(label(rowY[2], 'TOPLAM PUAN'));
    b.add(value(rowY[2], String(o.total)));
    const line = scene.add.rectangle(0, 69, 600, 4, 0xe0b25a, 0.6); b.add(line);

    const next = UI.button(scene, {
      x: 0, y: 214, w: 560, h: 108, label: 'SONRAKİ BÖLÜM',
      palette: 'green', size: 42, icon: 'arrow', onClick: () => o.onNext()
    });
    b.add(next);
    scene.tweens.add({ targets: next, scale: { from: 1, to: 1.045 }, duration: 620, yoyo: true, repeat: -1, ease: 'Sine.easeInOut', delay: 1400 });
    return { modal: m, next, close() { m.close(); } };
  }

  SV.Panels = { outOfBalls, levelComplete };
})(typeof window !== 'undefined' ? window : globalThis);
