/*
 * OYUN SAHNESİ
 *
 * Akış:  hazır (nişan) -> uçuş -> (isabet / ıska değerlendirmesi) -> hazır ...
 *   - Bölümde 6 şişe vardır; hedef renkler sırayla vurulur (HUD'da gösterilir).
 *   - Doğru şişe vurulursa: top hakkı HARCANMAZ, şişe kırılır, puan kazanılır.
 *   - Yanlış şişe ya da ıska: atış başına en çok 1 top hakkı gider.
 *   - Top hakkı 0 olunca "Topların bitti!" penceresi: reklam izle (+3 top) / yeniden başlat.
 *   - 6 hedef de vurulunca "BÖLÜM TAMAMLANDI!" ve sonraki bölüm hazır beklenir.
 *
 * Kurallar GameState'te (core/state.js), fizik physics.js'te, görünüm bottle.js/ui'dadır;
 * bu sahne hepsini birbirine bağlar.
 */
(function (root) {
  'use strict';
  const SV = (root.SV = root.SV || {});
  const P = SV.Physics, L = SV.Levels, U = SV.U;
  const hexInt = (h) => parseInt(String(h).replace('#', ''), 16);

  const BALL_COLORS = ['red', 'blue', 'green', 'yellow', 'purple', 'orange'];
  const MAX_FLIGHT = 7;                 // sn: bir atış en fazla bu kadar sürer
  const assistRadius = (n) => (n <= 3 ? 14 : n <= 6 ? 10 : 6); // sanal çekiş px: küçük "mıknatıs"

  class GameScene extends Phaser.Scene {
    constructor() { super('Game'); }

    init(data) {
      const st = SV.App.state;
      this.levelNo = (data && data.level) || st.level || 1;
      this.mode = (data && data.mode) || 'new';
    }

    /* ------------------------------ Kurulum ------------------------------ */
    create() {
      const App = SV.App, G = SV.G;
      App.scene = this;
      this.state = App.state;
      SV.Scene.setupCamera(this);
      SV.Scene.ensureTextures(this);
      this.bg = SV.Scene.background(this);

      this.layout = L.build(this.levelNo, G.W);
      if (this.mode === 'restart') this.state.restartLevel();
      else this.state.startLevel(this.levelNo, this.layout.order);

      this.clock = 0; this.acc = 0; this.tPhys = 0;
      this.set = new P.ColliderSet(this.layout);   // canlı çarpışma şekilleri
      this.sim = new P.ColliderSet(this.layout);   // nişan çizgisi / nişan yardımı simülasyonu
      this.phase = 'ready';                        // ready | flying | locked
      this.shotNo = 0;
      this.ball = null; this.shot = null; this.panel = null; this.hintObjs = null;

      this.buildWorld();
      this.sling = new SV.Sling(this);
      this.guideG = this.add.graphics().setDepth(24);
      this.hud = new SV.Hud(this, this.state);
      this.buildButtons();

      this.world = {
        colliders: this.set.list, groundY: L.GROUND_Y,
        onContact: (c, impact, n) => this.onContact(c, impact, n),
        afterResolve: (c, imp, n) => this.afterResolve(c, imp, n),
        onGround: (imp) => this.onGround(imp)
      };

      this.aim = new SV.AimController(this, {
        canStart: () => this.phase === 'ready' && this.state.status === 'playing',
        onStart: () => this.onAimStart(),
        onMove: (pull) => this.onAimMove(pull),
        onRelease: (pull) => this.onAimRelease(pull),
        onCancel: () => this.onAimCancel()
      });

      this.spawnBall(true);
      this.showHint();
      SV.Fx.banner(this, 'BÖLÜM ' + this.levelNo, { y: 330, size: 84, hold: 1000 });
      SV.Audio.play('pop');
      SV.App.ads.preload();               // reklamı arka planda hazırla (GÖSTERMEZ)
    }

    buildWorld() {
      const G = SV.G, R = G.R;
      this.platViews = this.layout.plats.map((p) => {
        const t = SV.Tex.platform(this, p.w);
        const img = this.add.image(p.cx, p.top, t.key).setOrigin(t.ox / t.w, t.oy / t.h).setScale(1 / R).setDepth(10);
        return img;
      });
      this.bottles = this.layout.bottles.map((def, i) => {
        const pose = this.set.poses[def.platIndex];
        const x = pose.x + def.ox, y = pose.y;
        const shadowW = SV.Shapes.width(def.shape, def.scale) * 1.55;
        const shadow = this.add.image(x, y + 3, 'shadow').setScale(shadowW / 256 / R).setAlpha(0.9).setDepth(12);
        const view = new SV.BottleView(this, def, i);
        view.setBase(x, y).setDepth(15);
        view.pop(250 + i * 90);
        return { def, view, shadow, dead: false };
      });
    }

    buildButtons() {
      const W = SV.G.W, y = SV.G.H - 56;
      const mk = (x, icon, pal, fn) => SV.UI.button(this, { x, y, round: 84, palette: pal, icon, onClick: fn, depth: 100 });
      this.btnHome = mk(W - 62 - 200, 'home', 'purple', () => this.goMenu());
      this.btnRestart = mk(W - 62 - 100, 'restart', 'orange', () => this.restartLevel());
      this.btnSound = mk(W - 62, SV.Audio.muted ? 'sound_off' : 'sound_on', 'blue', () => {
        const muted = SV.Audio.toggle();
        this.btnSound.setIcon(muted ? 'sound_off' : 'sound_on');
        if (!muted) SV.Audio.play('click');
      });
    }

    /* ------------------------------ Top ------------------------------ */
    targetBottleIndex() {
      const id = this.state.target;
      return this.layout.bottles.findIndex((b) => b.colorId === id);
    }

    spawnBall(first) {
      const G = SV.G, S = L.SLING;
      const id = BALL_COLORS[this.shotNo % BALL_COLORS.length];
      const img = this.add.image(S.x, S.y, 'ball_' + id).setScale(0.001).setDepth(25);
      this.ball = { x: S.x, y: S.y, vx: 0, vy: 0, r: P.BALL_R, angle: 0, flying: false, img, id, trail: null };
      this.tweens.add({ targets: img, scale: 1 / G.R, duration: 320, ease: 'Back.easeOut', delay: first ? 450 : 0 });
      this.sling.holdBall({ x: S.x, y: S.y }, 0);
      this.phase = 'ready';
    }

    /* ------------------------------ Nişan ------------------------------ */
    onAimStart() {
      SV.Audio.unlock();
      this.hideHint(true);
      this.lastStretchSfx = 0;
    }

    onAimMove(pull) {
      const b = this.ball;
      if (!b || b.flying) return;
      const pos = P.restPosition(pull);
      b.x = pos.x; b.y = pos.y;
      b.img.setPosition(pos.x, pos.y);
      this.sling.holdBall(pos, U.clamp(pull.len / P.MAX_PULL, 0, 1));
      this.drawGuide(pull);
      if (pull.len > P.MIN_PULL && this.time.now - this.lastStretchSfx > 90) {
        this.lastStretchSfx = this.time.now;
        SV.Audio.play('stretch');
      }
    }

    drawGuide(pull) {
      const g = this.guideG;
      g.clear();
      if (pull.len < P.MIN_PULL) return;
      const tr = P.trajectory(this.sim, this.tPhys, pull, L.GROUND_Y, { dt: 0.045, count: this.layout.guide });
      const n = tr.pts.length;
      for (let k = 0; k < n; k++) {
        const f = 1 - k / Math.max(1, n);
        const r = 3 + 4.2 * f;
        g.fillStyle(0x1b3b6b, 0.35 * (0.4 + f));
        g.fillCircle(tr.pts[k].x, tr.pts[k].y + 1, r + 1.6);
        g.fillStyle(0xffffff, 0.45 + 0.5 * f);
        g.fillCircle(tr.pts[k].x, tr.pts[k].y, r);
      }
    }

    onAimCancel() {
      this.guideG.clear();
      const b = this.ball, S = L.SLING;
      if (!b || b.flying) return;
      // top yaylı biçimde sapana döner
      this.tweens.add({
        targets: b, x: S.x, y: S.y, duration: 140, ease: 'Back.easeOut',
        onUpdate: () => { b.img.setPosition(b.x, b.y); this.sling.holdBall({ x: b.x, y: b.y }, 0.1); },
        onComplete: () => this.sling.holdBall({ x: S.x, y: S.y }, 0)
      });
    }

    onAimRelease(pull) {
      if (this.phase !== 'ready' || !this.ball) return;
      const tgt = this.targetBottleIndex();
      const a = P.assistPull(this.sim, this.tPhys, pull, tgt < 0 ? null : tgt, assistRadius(this.levelNo), L.GROUND_Y);
      this.launch(a.pull);
    }

    launch(pull) {
      const b = this.ball, ls = P.launchState(pull);
      const from = { x: b.x, y: b.y };
      Object.assign(b, { x: ls.x, y: ls.y, vx: ls.vx, vy: ls.vy, angle: 0, flying: true });
      this.phase = 'flying';
      this.shot = { t: 0, rest: 0, touched: false, penalized: false, correct: 0, last: {} };
      this.guideG.clear();
      this.sling.release(from);
      const col = L.BY_ID[b.id];
      b.trail = SV.Fx.trail(this, b.img, hexInt(col.hex));
      this.shotNo++;
      SV.Audio.play('launch');
      SV.Storage.set('tutorialDone', true);
    }

    /* ------------------------------ Fizik döngüsü ------------------------------ */
    update(time, delta) {
      const dt = Math.min(delta / 1000, 0.05);
      this.clock += dt;
      this.bg.update(dt, this.clock);
      this.sling.update(dt);

      this.acc += dt;
      let steps = 0;
      while (this.acc >= P.STEP && steps < 24) {
        this.acc -= P.STEP; steps++;
        this.tPhys += P.STEP;
        this.set.update(this.tPhys);
        if (this.phase === 'flying' && this.ball && this.ball.flying) this.stepFlight();
      }
      if (steps === 24) this.acc = 0;

      // görünümü senkronla
      for (let i = 0; i < this.platViews.length; i++) {
        const pose = this.set.poses[i];
        this.platViews[i].setPosition(pose.x, pose.y);
      }
      for (let i = 0; i < this.bottles.length; i++) {
        const e = this.bottles[i];
        if (e.dead) continue;
        const pose = this.set.poses[e.def.platIndex];
        const x = pose.x + e.def.ox;
        e.view.setBase(x, pose.y);
        e.view.update(dt, this.clock);
        e.shadow.setPosition(x, pose.y + 3);
      }
      const b = this.ball;
      if (b && b.flying) { b.img.setPosition(b.x, b.y); b.img.setRotation(b.angle); }
    }

    stepFlight() {
      const b = this.ball, sh = this.shot, G = SV.G;
      P.stepBall(b, P.STEP, this.world);
      sh.t += P.STEP;
      sh.rest = Math.hypot(b.vx, b.vy) < 28 ? sh.rest + P.STEP : 0;
      if (b.x > G.W + 140 || b.x < -160 || b.y > G.H + 160 || sh.rest > 0.4 || sh.t > MAX_FLIGHT) this.endShot();
    }

    /* ------------------------------ Çarpışmalar ------------------------------ */
    /** Her temas adımında çağrılır. 'pass' dönerse top şişenin içinden geçer (kırılan şişe). */
    onContact(c) {
      if (c.type !== 'bottle' || this.phase !== 'flying' || !this.shot) return undefined;
      const st = this.state;
      if (st.status === 'playing' && this.layout.bottles[c.bottleIndex].colorId === st.target) {
        this.hitCorrect(c.bottleIndex);
        return 'pass';
      }
      this.shot.touched = true;
      // Bu atışta zaten doğru şişe vurulduysa (top kırılan şişeden geçip komşuya değebilir)
      // oyuncu cezalandırılmaz: puan kazanan atış top hakkı götürmez.
      if (!this.shot.penalized && this.shot.correct === 0 && st.status === 'playing') this.penalty('bottle', c.bottleIndex);
      return undefined;
    }

    /** Sekme gerçekleştikten sonra: ses, parıltı, şişe sallanması. */
    afterResolve(c, imp, n) {
      const b = this.ball;
      if (!b || !this.shot) return;
      if (c.type === 'bottle') {
        const i = c.bottleIndex, e = this.bottles[i], last = this.shot.last;
        if (e.dead || (last[i] != null && this.clock - last[i] < 0.12)) return;
        last[i] = this.clock;
        const dir = n.nx < -0.2 ? 1 : n.nx > 0.2 ? -1 : (b.vx >= 0 ? 1 : -1);
        e.view.hit(dir, U.clamp(imp / 900, 0.15, 1));
        SV.Fx.tinyHit(this, b.x - n.nx * b.r, b.y - n.ny * b.r, e.view.col);
        SV.Audio.play('glass', { speed: imp });
      } else if (c.type === 'platform' && imp > 120) {
        SV.Audio.play('thud', { speed: imp });
        SV.Fx.dust(this, b.x, b.y + b.r, U.clamp(imp / 700, 0.3, 1.2));
      }
    }

    onGround(imp) {
      if (imp > 120 && this.ball) {
        SV.Audio.play('thud', { speed: imp });
        SV.Fx.dust(this, this.ball.x, L.GROUND_Y, U.clamp(imp / 700, 0.3, 1.2));
      }
    }

    hitCorrect(i) {
      const e = this.bottles[i], view = e.view, col = view.col;
      const res = this.state.registerCorrect();
      if (!res) return;
      this.shot.correct++; this.shot.touched = true;
      this.killBottle(i);
      const c = view.center();
      SV.Fx.shatter(this, c.x, c.y, col, view.s);
      SV.Audio.play('shatter');
      SV.Audio.play('success', { streak: res.streak - 1 });
      SV.UI.popup(this, c.x, c.y - 30, '+' + res.points, { size: 58, color: '#fff27a', stroke: '#8a4a00' });
      if (res.streak >= 2) SV.UI.popup(this, c.x, c.y + 36, 'x' + res.streak + ' SERİ!', { size: 36, color: '#ffffff', stroke: '#c0392b', life: 1000 });
      view.destroy();
      e.shadow.destroy();
      this.hud.setScore(this.state.score, true);
      this.hud.setTarget(true);
      if (res.complete) this.onLevelComplete();
    }

    killBottle(i) {
      this.bottles[i].dead = true;
      this.set.killBottle(i);
      this.sim.killBottle(i);
    }

    /** Yanlış şişe ya da ıska: 1 top hakkı gider. */
    penalty(kind, bottleIndex) {
      const r = this.state.registerWrong();
      if (!r) return;
      this.shot.penalized = true;
      this.hud.setBalls();
      this.hud.shakeBalls();
      SV.Audio.play(kind === 'miss' ? 'miss' : 'wrong');
      if (kind === 'bottle' && bottleIndex != null) {
        const c = this.bottles[bottleIndex].view.center();
        const m = this.add.image(c.x, c.y - 70, 'mark_x').setDepth(150).setScale(0.001);
        this.tweens.add({ targets: m, scale: 1.1 / SV.G.R, duration: 220, ease: 'Back.easeOut' });
        this.tweens.add({ targets: m, y: m.y - 40, alpha: 0, delay: 650, duration: 400, onComplete: () => m.destroy() });
      }
      if (!r.outOfBalls) {
        SV.Fx.banner(this, kind === 'miss' ? 'ISKA!' : 'YANLIŞ ŞİŞE!', { y: 300, size: 60, color: '#ffe0e0', stroke: '#8a1018', hold: 700 });
      }
    }

    /* ------------------------------ Atış sonu ------------------------------ */
    endShot() {
      if (this.phase !== 'flying') return;
      const b = this.ball, sh = this.shot;
      b.flying = false;
      this.removeBall();
      if (this.state.status === 'playing' && !sh.touched && !sh.penalized) this.penalty('miss');
      this.phase = 'locked';
      this.time.delayedCall(380, () => this.afterShot());
    }

    removeBall() {
      const b = this.ball;
      if (!b) return;
      if (b.trail) {
        const tr = b.trail;
        tr.stop();
        this.time.delayedCall(450, () => tr.destroy());
        b.trail = null;
      }
      const img = b.img;
      this.tweens.add({ targets: img, scale: 0, alpha: 0, duration: 220, onComplete: () => img.destroy() });
    }

    afterShot() {
      const s = this.state.status;
      if (s === 'playing') this.spawnBall(false);
      else if (s === 'outOfBalls') this.showOutOfBalls();
    }

    /* ------------------------------ Top bitti: reklam ------------------------------ */
    showOutOfBalls() {
      if (this.panel) return;
      this.phase = 'locked';
      SV.Audio.play('lose');
      this.panel = SV.Panels.outOfBalls(this, {
        rewardBalls: this.state.rewardBalls,
        onWatch: (api) => this.watchAd(api),
        onRestart: () => this.restartLevel()
      });
      this.panel.originalLabel = 'REKLAM İZLE — ' + this.state.rewardBalls + ' EKSTRA TOP KAZAN';
      SV.App.ads.preload();
    }

    /** Yalnızca "REKLAM İZLE" düğmesine basılınca çağrılır. */
    async watchAd(api) {
      if (api.busy || this.panel !== api) return;
      api.setBusy(true, 'REKLAM YÜKLENİYOR…');
      let r;
      try { r = await SV.App.ads.showRewarded(); }
      catch (e) { r = { status: 'failed', error: 'Reklam gösterilemedi. Lütfen tekrar dene.' }; }
      if (this.panel !== api || !this.sys.isActive()) return; // bu arada sahne değişti

      if (r.status === 'rewarded') {
        if (this.state.grantReward()) {
          this.panel = null;
          api.close();
          SV.Audio.play('reward');
          this.hud.setBalls();
          this.hud.pulseBalls();
          SV.Fx.banner(this, '+' + this.state.rewardBalls + ' TOP!', { y: 300, size: 76, color: '#fff27a', stroke: '#8a4a00', hold: 900 });
          this.time.delayedCall(260, () => this.spawnBall(false));
        } else {
          api.setBusy(false); api.setWatchLabel(api.originalLabel, 31);
        }
      } else if (r.status === 'dismissed') {
        api.setBusy(false);
        api.setWatchLabel(api.originalLabel, 31);
        api.setStatus('Reklam sonuna kadar izlenmedi, bu yüzden ekstra top verilmedi.', 'warn');
      } else if (r.status === 'failed') {
        api.setBusy(false);
        api.setWatchLabel('TEKRAR DENE', 38);
        api.setStatus(r.error || 'Reklam yüklenemedi. Lütfen tekrar dene.', 'error');
      } else {
        api.setBusy(false); api.setWatchLabel(api.originalLabel, 31);
      }
    }

    /* ------------------------------ Bölüm bitti ------------------------------ */
    onLevelComplete() {
      this.phase = 'locked';
      this.aim.cancel();
      this.guideG.clear();
      if (this.ball) { this.ball.flying = false; this.removeBall(); }
      this.prepareNext();
      this.time.delayedCall(1100, () => this.showLevelComplete());
    }

    /** Sonraki bölümün düzenini ve dokularını arka planda hazırla (anında geçiş için). */
    prepareNext() {
      try {
        const next = L.build(this.levelNo + 1, SV.G.W);
        next.bottles.forEach((b) => SV.BottleArt.glassFor(this, b.shape, b.scale));
        next.plats.forEach((p) => SV.Tex.platform(this, p.w));
        this.nextLayout = next;
      } catch (e) { this.nextLayout = null; }
    }

    showLevelComplete() {
      const st = this.state;
      SV.Fx.winBurst(this);
      SV.Audio.play('win');
      this.hud.setScore(st.score, true);
      this.panel = SV.Panels.levelComplete(this, {
        stars: st.stars, earned: st.levelEarned, ballsLeft: st.balls, maxBalls: st.maxBalls, total: st.score,
        onNext: () => this.nextLevel()
      });
    }

    nextLevel() { this.scene.start('Game', { level: this.levelNo + 1, mode: 'new' }); }
    restartLevel() { this.scene.restart({ level: this.levelNo, mode: 'restart' }); }
    goMenu() { this.scene.start('Menu'); }

    /* ------------------------------ İpucu (yalnızca ilk kez) ------------------------------ */
    showHint() {
      if (this.levelNo !== 1 || SV.Storage.get('tutorialDone', false)) return;
      const S = L.SLING;
      const t = SV.UI.text(this, S.x + 40, S.y - 190, 'Ekrana bas, geriye çek\nve bırak!', { size: 32, depth: 90, lineSpacing: -6 });
      const finger = this.add.graphics().setDepth(90);
      finger.fillStyle(0xffffff, 0.85); finger.fillCircle(0, 0, 24);
      finger.lineStyle(5, 0x1b3b6b, 0.8); finger.strokeCircle(0, 0, 24);
      finger.setPosition(S.x + 330, S.y - 40);
      this.tweens.add({ targets: finger, x: S.x + 190, y: S.y + 30, alpha: { from: 1, to: 0.15 }, duration: 1100, repeat: -1, ease: 'Sine.easeInOut', hold: 350, repeatDelay: 250 });
      this.hintObjs = [t, finger];
    }

    hideHint() {
      if (!this.hintObjs) return;
      this.hintObjs.forEach((o) => { this.tweens.killTweensOf(o); o.destroy(); });
      this.hintObjs = null;
    }
  }

  SV.GameScene = GameScene;
})(typeof window !== 'undefined' ? window : globalThis);
