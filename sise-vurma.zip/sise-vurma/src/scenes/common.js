/*
 * SAHNE ORTAK İŞLER: kamera/çözünürlük, dokuların hazırlanması, canlı arka plan.
 *
 * Mantıksal ekran: yükseklik 720, genişlik SV.G.W. Gerçek tuval R kat büyüktür
 * (keskin görüntü için); kamera zoom=R ile mantıksal koordinatları tuvale oturtur.
 */
(function (root) {
  'use strict';
  const SV = (root.SV = root.SV || {});

  const Scene = {
    setupCamera(scene) {
      const G = SV.G, cam = scene.cameras.main;
      cam.setZoom(G.R);
      cam.centerOn(G.W / 2, G.H / 2);
      cam.setBackgroundColor('#7fd0ff');
    },

    /** Tüm ortak dokular (bir kez üretilir; çözünürlük değişirse Tex.purge sonrası yeniden). */
    ensureTextures(scene) {
      SV.Tex.common(scene);
      SV.Tex.items.build(scene);
    },

    /**
     * Gökyüzü, güneş, hareketli bulutlar. Dönüş: { update(dt, t) }.
     * Güneş ışığı arka plan dokusunda (sağ üst) zaten var; burada dönen ışınlar eklenir.
     */
    background(scene) {
      const G = SV.G, R = G.R, W = G.W;
      const bgKey = SV.Tex.background(scene, W, G.H);
      scene.add.image(0, 0, bgKey).setOrigin(0, 0).setScale(1 / R).setDepth(0);
      const sx = W - 150, sy = 140;
      const rays = scene.add.image(sx, sy, 'sunrays').setScale(1 / R).setDepth(1).setAlpha(0.9);
      scene.add.image(sx, sy, 'sun').setScale(1 / R).setDepth(2);
      const clouds = [];
      const defs = [[0, 0.11, 0.34, 84, 8], [1, 0.46, 0.46, 140, 12], [2, 0.78, 0.28, 58, 6], [0, 0.93, 0.5, 200, 9], [1, 0.25, 0.3, 36, 10]];
      defs.forEach((d, i) => {
        const c = scene.add.image(W * d[1], d[3] + (i % 2) * 14, 'cloud' + d[0]).setScale(1 / R * (0.8 + 0.4 * ((i * 37) % 10) / 10)).setDepth(1).setAlpha(0.95);
        c.sv = { speed: d[4] * (0.7 + 0.1 * i), baseY: c.y, ph: i * 1.3 };
        clouds.push(c);
      });
      return {
        update(dt, t) {
          rays.rotation += dt * 0.1;
          for (let i = 0; i < clouds.length; i++) {
            const c = clouds[i];
            c.x += c.sv.speed * dt;
            c.y = c.sv.baseY + Math.sin(t * 0.5 + c.sv.ph) * 4;
            if (c.x > W + 160) c.x = -160;
          }
        }
      };
    },

    /** Tam ekran + yatay kilit (yalnızca dokunmatik cihazlarda, kullanıcı hareketinden sonra). */
    tryImmersive() {
      try {
        const coarse = root.matchMedia && root.matchMedia('(pointer: coarse)').matches;
        if (!coarse) return;
        const el = root.document.documentElement;
        const req = el.requestFullscreen || el.webkitRequestFullscreen;
        if (req && !root.document.fullscreenElement) {
          const p = req.call(el, { navigationUI: 'hide' });
          const lock = () => { try { root.screen.orientation.lock('landscape').catch(() => {}); } catch (e) { /* yoksay */ } };
          if (p && p.then) p.then(lock).catch(() => {}); else lock();
        }
      } catch (e) { /* yoksay */ }
    }
  };

  SV.Scene = Scene;
})(typeof window !== 'undefined' ? window : globalThis);
