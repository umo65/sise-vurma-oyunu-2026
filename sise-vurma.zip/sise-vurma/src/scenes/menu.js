/*
 * BAŞLANGIÇ EKRANI: başlık, 6 renkli şişe, OYNA / DEVAM ET düğmeleri.
 */
(function (root) {
  'use strict';
  const SV = (root.SV = root.SV || {});
  const L = SV.Levels;

  class MenuScene extends Phaser.Scene {
    constructor() { super('Menu'); }

    create() {
      const G = SV.G, W = G.W, H = G.H, R = G.R, App = SV.App;
      SV.Scene.setupCamera(this);
      SV.Scene.ensureTextures(this);
      this.bg = SV.Scene.background(this);
      this.clock = 0;

      // Sapan + top (süs)
      this.sling = new SV.Sling(this);
      const S = L.SLING;
      this.ballImg = this.add.image(S.x, S.y, 'ball_red').setScale(1 / R).setDepth(25);
      this.sling.holdBall({ x: S.x, y: S.y }, 0);
      this.tweens.add({ targets: this.ballImg, y: S.y - 8, duration: 700, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });

      // Platform + 6 şişe
      const platW = 720, top = 440;
      const pt = SV.Tex.platform(this, platW);
      this.add.image(W / 2 + 40, top, pt.key).setOrigin(pt.ox / pt.w, pt.oy / pt.h).setScale(1 / R).setDepth(10);
      this.views = [];
      const ids = ['red', 'blue', 'green', 'yellow', 'purple', 'orange'];
      ids.forEach((id, i) => {
        const x = W / 2 + 40 + (i - 2.5) * 114;
        const def = { colorId: id, shape: 'classic', scale: 0.9, fill: 0.6 };
        this.add.image(x, top + 3, 'shadow').setScale((SV.Shapes.width('classic', 0.9) * 1.55) / 256 / R).setDepth(12);
        const v = new SV.BottleView(this, def, i + 1);
        v.setBase(x, top).setDepth(15);
        v.pop(150 + i * 110);
        this.views.push(v);
        // şişeler sırayla hafifçe sallansın
        this.time.addEvent({ delay: 2600, loop: true, startAt: i * 380, callback: () => v.hit(i % 2 ? 1 : -1, 0.28) });
      });

      // Başlık
      const title = SV.UI.text(this, W / 2, 112, 'ŞİŞE VURMA', { size: 124, stroke: '#1b3b6b', sw: 18, shadowY: 8 });
      title.setScale(0.4).setAlpha(0);
      this.tweens.add({ targets: title, scale: 1, alpha: 1, duration: 520, ease: 'Back.easeOut' });
      this.tweens.add({ targets: title, y: 118, duration: 1500, yoyo: true, repeat: -1, ease: 'Sine.easeInOut', delay: 600 });
      SV.UI.text(this, W / 2, 206, 'Sapanla doğru renkli şişeyi vur!', { size: 36, color: '#fffbe0', stroke: '#2a5d9f', sw: 7 });

      // Düğmeler
      const savedLevel = Math.max(1, SV.Storage.get('level', 1) | 0);
      const y0 = 596;
      const begin = (level, fresh) => {
        SV.Audio.unlock();
        SV.Scene.tryImmersive();
        const st = App.state;
        st.reset();
        if (fresh) { SV.Storage.set('level', 1); SV.Storage.set('score', 0); st.score = 0; }
        else st.score = SV.Storage.get('score', 0) | 0;
        this.scene.start('Game', { level, mode: 'new' });
      };
      if (savedLevel > 1) {
        const cont = SV.UI.button(this, { x: W / 2 - 215, y: y0, w: 420, h: 100, label: 'DEVAM ET\nBÖLÜM ' + savedLevel, palette: 'green', size: 34, icon: 'play', onClick: () => begin(savedLevel, false) });
        const fresh = SV.UI.button(this, { x: W / 2 + 215, y: y0, w: 400, h: 100, label: 'BAŞTAN\nBAŞLA', palette: 'orange', size: 34, icon: 'restart', onClick: () => begin(1, true) });
        this.playBtn = cont;
        [cont, fresh].forEach((b) => (b.alpha = 0));
        this.tweens.add({ targets: [cont, fresh], alpha: 1, duration: 300, delay: 500 });
      } else {
        const play = SV.UI.button(this, { x: W / 2, y: y0, w: 460, h: 112, label: 'OYNA', palette: 'green', size: 62, icon: 'play', onClick: () => begin(1, true) });
        play.setAlpha(0);
        this.tweens.add({ targets: play, alpha: 1, duration: 300, delay: 500 });
        this.tweens.add({ targets: play, scale: { from: 1, to: 1.05 }, duration: 700, yoyo: true, repeat: -1, ease: 'Sine.easeInOut', delay: 900 });
        this.playBtn = play;
      }

      // Ses düğmesi + rekor
      const snd = SV.UI.button(this, {
        x: W - 62, y: H - 56, round: 84, palette: 'blue', icon: SV.Audio.muted ? 'sound_off' : 'sound_on',
        onClick: () => { const m = SV.Audio.toggle(); snd.setIcon(m ? 'sound_off' : 'sound_on'); if (!m) SV.Audio.play('click'); }
      });
      const best = SV.Storage.get('best', 0) | 0;
      const pill = this.add.image(24 + 170, H - 56 + 4, SV.UI.pillTexture(this, 340, 64, 'dark')).setScale(1 / R);
      SV.UI.text(this, 24 + 170, H - 57, 'REKOR  ' + best, { size: 32 });
      this.pill = pill;
    }

    update(time, delta) {
      const dt = Math.min(delta / 1000, 0.05);
      this.clock += dt;
      this.bg.update(dt, this.clock);
      this.sling.update(dt);
      for (let i = 0; i < this.views.length; i++) this.views[i].update(dt, this.clock);
    }
  }

  SV.MenuScene = MenuScene;
})(typeof window !== 'undefined' ? window : globalThis);
