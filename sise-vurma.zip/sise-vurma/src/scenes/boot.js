/*
 * AÇILIŞ SAHNESİ: yazı tipini bekler, ortak dokuları üretir, menüye (ya da
 * pencere yeniden boyutlanınca kaldığı oyuna) geçer.
 */
(function (root) {
  'use strict';
  const SV = (root.SV = root.SV || {});

  class BootScene extends Phaser.Scene {
    constructor() { super('Boot'); }

    create() {
      SV.Scene.setupCamera(this);
      let done = false;
      const go = () => {
        if (done) return;
        done = true;
        SV.Scene.ensureTextures(this);
        const r = SV.App.resume;
        SV.App.resume = null;
        this.scene.start(r ? r.scene : 'Menu', r || undefined);
      };
      // Yazı tipi yüklenmeden metin çizilirse yedek font görünür: önce yüklenmesini bekle.
      const fonts = root.document && root.document.fonts;
      if (fonts && fonts.load) {
        Promise.race([
          fonts.load('800 40px Baloo2', 'ŞİĞÜÖÇı'),
          new Promise((res) => setTimeout(res, 2500))
        ]).catch(() => {}).then(go);
      } else go();
    }
  }

  SV.BootScene = BootScene;
})(typeof window !== 'undefined' ? window : globalThis);
