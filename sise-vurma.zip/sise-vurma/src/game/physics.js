/*
 * FİZİK VE ÇARPIŞMA (DOM'dan bağımsız; Node'da da test edilir)
 *
 *  - Top: daire, yerçekimi + sekme (restitution) + sürtünme
 *  - Şişeler/platformlar: yuvarlak köşeli dikdörtgenler (hareketli olabilir;
 *    çarpışma göreli hıza göre çözülür)
 *  - Sabit adım (1/240 sn): hızlı top duvarlardan geçmez (tunneling yok)
 *  - ColliderSet: bir bölüm düzeninden çarpışma şekillerini üretir ve zamanla günceller
 *  - simulateShot / trajectory / solveShot: aynı fiziği DOM'suz çalıştırır
 *    (nişan çizgisi ve testler; oyundaki gerçek uçuşla birebir aynı sonuç)
 *
 * SAPAN MODELİ: Parmak, topu tuttuğu noktadan "sanal çekiş" (pull) kadar
 * sürükler. Güç = sanal çekiş * LAUNCH_K. Top ekranda çekişin PULL_VIS
 * (0.65) katı kadar geriye gider; böylece topu sapanın yanında tutarken bile
 * parmak hareketi daha ince ayarlanabilir (mobilde nişan almak kolaylaşır).
 */
(function (root) {
  'use strict';
  const SV = (root.SV = root.SV || {});

  const STEP = 1 / 240;
  const GRAVITY = 1400;               // px/sn²
  const BALL_R = 22;
  const MAX_PULL = 288;               // en fazla sanal çekiş (px)
  const MIN_PULL = 40;                // bundan kısa çekiş = vazgeç
  const PULL_VIS = 0.5;               // topun ekrandaki geri gidişi / sanal çekiş
  const LAUNCH_K = 5.2;               // sanal çekiş (px) -> hız (px/sn) katsayısı
  const REST = { platform: 0.4, bottle: 0.5, ground: 0.35 };
  const FRICTION = { platform: 0.12, bottle: 0.05, ground: 0.25 };
  const ROLL_DRAG = 1.7;              // yerde yuvarlanırken yavaşlama (1/sn)

  /** Daire ile yuvarlak köşeli dikdörtgen temas testi. */
  function contact(ball, c) {
    const ihw = c.hw - c.rad, ihh = c.hh - c.rad;
    const ix = Math.max(c.cx - ihw, Math.min(ball.x, c.cx + ihw));
    const iy = Math.max(c.cy - ihh, Math.min(ball.y, c.cy + ihh));
    const dx = ball.x - ix, dy = ball.y - iy;
    const R = ball.r + c.rad;
    const d2 = dx * dx + dy * dy;
    if (d2 >= R * R) return null;
    const d = Math.sqrt(d2);
    if (d > 1e-6) return { nx: dx / d, ny: dy / d, pen: R - d };
    // Merkez iç dikdörtgenin içinde: en yakın kenardan dışarı it
    const l = ball.x - (c.cx - c.hw), r = c.cx + c.hw - ball.x;
    const t = ball.y - (c.cy - c.hh), b = c.cy + c.hh - ball.y;
    const m = Math.min(l, r, t, b);
    if (m === t) return { nx: 0, ny: -1, pen: t + ball.r };
    if (m === b) return { nx: 0, ny: 1, pen: b + ball.r };
    if (m === l) return { nx: -1, ny: 0, pen: l + ball.r };
    return { nx: 1, ny: 0, pen: r + ball.r };
  }

  /** Çarpışmayı çözer; çarpma hızını (px/sn) döndürür. */
  function resolve(ball, c, n, e, mu) {
    const cvx = c.vx || 0, cvy = c.vy || 0;
    const rvx = ball.vx - cvx, rvy = ball.vy - cvy;
    const vn = rvx * n.nx + rvy * n.ny;
    ball.x += n.nx * n.pen;
    ball.y += n.ny * n.pen;
    if (vn >= 0) return 0;
    const impact = -vn;
    const ee = impact < 40 ? 0 : e; // çok yavaş temasta titreme olmasın
    const j = -(1 + ee) * vn;
    let nvx = rvx + j * n.nx, nvy = rvy + j * n.ny;
    const tx = -n.ny, ty = n.nx;
    const vt = nvx * tx + nvy * ty;
    nvx -= tx * vt * mu; nvy -= ty * vt * mu;
    ball.vx = nvx + cvx; ball.vy = nvy + cvy;
    return impact;
  }

  /**
   * Topu bir adım ilerletir.
   * world: { colliders, groundY, onContact(c, impact, n) -> 'pass'|undefined, onGround(impact) }
   * onContact 'pass' dönerse top sekmez, yalnızca %22 yavaşlar (kırılan şişe).
   */
  function stepBall(ball, h, world) {
    ball.vy += GRAVITY * h;
    ball.x += ball.vx * h;
    ball.y += ball.vy * h;
    ball.angle += (ball.vx / ball.r) * h * 0.5;

    const cols = world.colliders;
    for (let i = 0; i < cols.length; i++) {
      const c = cols[i];
      if (c.dead) continue;
      const n = contact(ball, c);
      if (!n) continue;
      const rvn = -((ball.vx - (c.vx || 0)) * n.nx + (ball.vy - (c.vy || 0)) * n.ny);
      const action = world.onContact ? world.onContact(c, rvn > 0 ? rvn : 0, n) : undefined;
      if (action === 'pass') { ball.vx *= 0.78; ball.vy *= 0.78; continue; }
      const imp = resolve(ball, c, n, REST[c.type], FRICTION[c.type]);
      if (imp > 0 && world.afterResolve) world.afterResolve(c, imp, n);
    }

    if (ball.y + ball.r > world.groundY) {
      ball.y = world.groundY - ball.r;
      if (ball.vy > 0) {
        const imp = ball.vy;
        if (imp < 40) {
          // Yerde durma/yuvarlanma: her adımda değil, saniye başına sürtünme (top doğal yuvarlanır)
          ball.vy = 0;
          ball.vx *= Math.exp(-ROLL_DRAG * h);
        } else {
          // Gerçek yere çarpma: sekme + yatay hız kaybı
          ball.vy = -imp * REST.ground;
          ball.vx *= 1 - FRICTION.ground;
        }
        if (world.onGround) world.onGround(imp);
      }
    }
  }

  /* ------------------------------------------------------------------ */
  /** Bir bölüm düzeninden çarpışma şekillerini üretir ve zamanla günceller. */
  class ColliderSet {
    constructor(layout) {
      this.layout = layout;
      this.list = [];
      this.poses = layout.plats.map((p) => SV.Levels.platformPose(p, 0));
      this.dead = layout.bottles.map(() => false);
      layout.plats.forEach((p, i) => {
        this.list.push({ type: 'platform', platIndex: i, cx: 0, cy: 0, hw: p.w / 2, hh: p.h / 2, rad: 14, vx: 0, vy: 0, dead: false });
      });
      layout.bottles.forEach((b, i) => {
        SV.Shapes.colliders(b.shape, b.scale).forEach((l) => {
          this.list.push({
            type: 'bottle', bottleIndex: i, platIndex: b.platIndex, ox: b.ox, local: l,
            cx: 0, cy: 0, hw: l.hw, hh: l.hh, rad: l.rad, vx: 0, vy: 0, dead: false
          });
        });
      });
      this.update(0);
    }
    /** t anındaki konum ve hızlara göre şekilleri günceller. */
    update(t) {
      const L = this.layout;
      for (let i = 0; i < L.plats.length; i++) this.poses[i] = SV.Levels.platformPose(L.plats[i], t);
      for (let i = 0; i < this.list.length; i++) {
        const c = this.list[i], pose = this.poses[c.platIndex];
        if (c.type === 'platform') {
          c.cx = pose.x; c.cy = pose.y + c.hh;
        } else {
          c.cx = pose.x + c.ox + c.local.cx; c.cy = pose.y + c.local.cy;
        }
        c.vx = pose.vx; c.vy = pose.vy;
      }
    }
    killBottle(i) {
      this.dead[i] = true;
      for (const c of this.list) if (c.type === 'bottle' && c.bottleIndex === i) c.dead = true;
    }
  }

  /** Sanal çekişten topun başlangıç durumunu üretir (gerçek uçuş ve simülasyon ortak kullanır). */
  function launchState(pull) {
    const A = SV.Levels.SLING;
    return {
      x: A.x + pull.x * PULL_VIS, y: A.y + pull.y * PULL_VIS,
      vx: -pull.x * LAUNCH_K, vy: -pull.y * LAUNCH_K,
      r: BALL_R, angle: 0
    };
  }

  /** Ekranda topun duracağı nokta (sapan gerilirken). */
  function restPosition(pull) {
    const A = SV.Levels.SLING;
    return { x: A.x + pull.x * PULL_VIS, y: A.y + pull.y * PULL_VIS };
  }

  /** Verilen sanal çekiş vektörünü izin verilen bölgeye sıkıştırır. */
  function clampPull(px, py, groundY) {
    const A = SV.Levels.SLING;
    let x = Math.min(px, 0);                       // yalnızca geriye (sola) çekilir
    let y = py;
    const maxY = (groundY - BALL_R - 8 - A.y) / PULL_VIS;
    if (y > maxY) y = maxY;
    const len = Math.hypot(x, y);
    if (len > MAX_PULL) { x = (x / len) * MAX_PULL; y = (y / len) * MAX_PULL; }
    return { x, y, len: Math.hypot(x, y) };
  }

  /** Topu sapandan fırlatır, ilk şişe temasına / yere kadar simüle eder. */
  function simulateShot(set, startT, pull, groundY, maxT, stopAfterX) {
    const ball = launchState(pull);
    const out = { hit: null, ground: false, time: 0 };
    let t = startT;
    const world = {
      colliders: set.list, groundY,
      onContact(c) { if (c.type === 'bottle' && out.hit === null) out.hit = c.bottleIndex; }
    };
    const limit = Math.round((maxT || 6) / STEP);
    for (let k = 0; k < limit; k++) {
      t += STEP;
      set.update(t);
      stepBall(ball, STEP, world);
      if (out.hit !== null) { out.time = t - startT; return out; }
      if (ball.y + ball.r >= groundY - 0.5 || ball.x > 4000 || ball.x < -500) { out.ground = true; out.time = t - startT; return out; }
      if (stopAfterX && ball.x > stopAfterX && ball.vx > 0) { out.time = t - startT; return out; }
    }
    return out;
  }

  /**
   * Nişan çizgisi için yörünge örnekleri: her `dt` saniyede bir top konumu.
   * İlk şişe temasında ya da yere değince durur. Dönüş: { pts, end }.
   */
  function trajectory(set, startT, pull, groundY, opts) {
    opts = opts || {};
    const dt = opts.dt || 0.04, maxPts = opts.count || 20;
    const ball = launchState(pull);
    const pts = [];
    let t = startT, endKind = 'none', hitIndex = null;
    const world = {
      colliders: set.list, groundY,
      onContact(c) { if (c.type === 'bottle' && hitIndex === null) hitIndex = c.bottleIndex; }
    };
    const every = Math.max(1, Math.round(dt / STEP));
    const limit = every * maxPts;
    for (let k = 1; k <= limit; k++) {
      t += STEP;
      set.update(t);
      stepBall(ball, STEP, world);
      if (hitIndex !== null) { endKind = 'bottle'; break; }
      if (ball.y + ball.r >= groundY - 0.5) { endKind = 'ground'; break; }
      if (k % every === 0) pts.push({ x: ball.x, y: ball.y });
    }
    return { pts, end: { x: ball.x, y: ball.y, kind: endKind, bottle: hitIndex } };
  }


  /* ------------------------------------------------------------------ */
  // Nişan yardımı için taranacak sapmalar (yakından uzağa sıralı), yarıçap başına önbellek.
  const _offsets = {};
  function offsetsFor(radius, step) {
    const key = radius + ':' + step;
    if (_offsets[key]) return _offsets[key];
    const list = [];
    for (let dy = -radius; dy <= radius; dy += step) {
      for (let dx = -radius; dx <= radius; dx += step) {
        const d = Math.hypot(dx, dy);
        if (d <= radius + 1e-6 && d > 0) list.push({ dx, dy, d });
      }
    }
    list.sort((a, b) => a.d - b.d);
    return (_offsets[key] = list);
  }

  /**
   * NİŞAN YARDIMI: oyuncunun çekişi hedef şişeyi ıskalıyorsa ama `radius` px
   * içinde hedefi vuran bir çekiş varsa, en yakın olanı seçer. Çekiş hâlâ
   * oyuncunun elindedir; yardım yalnızca küçük bir "mıknatıs" etkisidir ve
   * yalnızca HEDEF şişe için çalışır (yanlış şişeye yönlendirmez).
   * Dönüş: { pull, assisted, hits }  (hits: düzeltilmiş çekiş hedefi vuruyor mu)
   */
  function assistPull(set, tLaunch, pull, targetIndex, radius, groundY) {
    const stopX = targetX(set, targetIndex) + 160;
    const base = simulateShot(set, tLaunch, pull, groundY, 4, stopX);
    if (base.hit === targetIndex) return { pull, assisted: false, hits: true };
    if (!radius || targetIndex == null) return { pull, assisted: false, hits: false };
    const maxY = (groundY - BALL_R - 8 - SV.Levels.SLING.y) / PULL_VIS;
    const list = offsetsFor(radius, 2);
    for (let i = 0; i < list.length; i++) {
      const o = list[i];
      const q = { x: Math.min(0, pull.x + o.dx), y: Math.min(maxY, pull.y + o.dy) };
      const len = Math.hypot(q.x, q.y);
      if (len < MIN_PULL || len > MAX_PULL) continue;
      if (simulateShot(set, tLaunch, q, groundY, 4, stopX).hit === targetIndex) {
        return { pull: q, assisted: true, hits: true };
      }
    }
    return { pull, assisted: false, hits: false };
  }

  /** Hedef şişenin (gövde) yaklaşık x konumu: simülasyonu erken kesmek için. */
  function targetX(set, bottleIndex) {
    if (bottleIndex == null) return 4000;
    for (let i = 0; i < set.list.length; i++) {
      const c = set.list[i];
      if (c.type === 'bottle' && c.bottleIndex === bottleIndex) return c.cx;
    }
    return 4000;
  }

  /**
   * Hedef şişeyi ilk vuran sanal çekiş vektörlerini arar ve her çözüm için
   * "nişan toleransını" ölçer: o noktadan her yöne kaç px sapılsa bile aynı
   * şişe hâlâ ilk vurulan oluyor (satranç mesafesi). En geniş toleranslı
   * noktayı döndürür: { x, y, margin, robust, count } ya da null.
   *   opts.dead      : zaten kırılmış şişe indeksleri
   *   opts.grid      : tarama adımı (px, varsayılan 4)
   *   opts.minMargin : "robust" sayılma eşiği (px, varsayılan = grid)
   */
  function solveShot(layout, targetIndex, tLaunch, opts) {
    opts = opts || {};
    const groundY = SV.Levels.GROUND_Y;
    const set = new ColliderSet(layout);
    (opts.dead || []).forEach((i) => set.killBottle(i));
    const g = opts.grid || 4;
    const maxY = (groundY - BALL_R - 8 - SV.Levels.SLING.y) / PULL_VIS;
    // Izgara: x in [-MAX_PULL, 0], y in [-MAX_PULL, maxY]; çevresine 1 hücre sahte kenar
    const nx = Math.floor(MAX_PULL / g) + 1, ny = Math.floor((MAX_PULL + maxY) / g) + 1;
    const W = nx + 2, H = ny + 2;
    const dist = new Int16Array(W * H);          // 0 = vurmuyor / sınır dışı
    const INF = 30000;
    let count = 0;
    for (let j = 0; j < ny; j++) {
      for (let i = 0; i < nx; i++) {
        const x = -MAX_PULL + i * g, y = -MAX_PULL + j * g;
        const len = Math.hypot(x, y);
        let ok = false;
        if (len >= MIN_PULL + g && len <= MAX_PULL && x <= 0 && y <= maxY) {
          ok = simulateShot(set, tLaunch, { x, y }, groundY).hit === targetIndex;
        }
        if (ok) { dist[(j + 1) * W + (i + 1)] = INF; count++; }
      }
    }
    if (!count) return null;
    // Satranç mesafesi dönüşümü (iki geçiş)
    for (let j = 1; j < H - 1; j++) for (let i = 1; i < W - 1; i++) {
      const k = j * W + i; if (!dist[k]) continue;
      dist[k] = Math.min(dist[k], dist[k - 1] + 1, dist[k - W] + 1, dist[k - W - 1] + 1, dist[k - W + 1] + 1);
    }
    for (let j = H - 2; j >= 1; j--) for (let i = W - 2; i >= 1; i--) {
      const k = j * W + i; if (!dist[k]) continue;
      dist[k] = Math.min(dist[k], dist[k + 1] + 1, dist[k + W] + 1, dist[k + W - 1] + 1, dist[k + W + 1] + 1);
    }
    let best = 0;
    for (let k = 0; k < dist.length; k++) if (dist[k] > best) best = dist[k];
    // En geniş toleranslı hücreler arasında merkeze en yakını seç
    const pool = [];
    for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) {
      if (dist[(j + 1) * W + (i + 1)] === best) pool.push({ x: -MAX_PULL + i * g, y: -MAX_PULL + j * g });
    }
    const cx = pool.reduce((a, q) => a + q.x, 0) / pool.length;
    const cy = pool.reduce((a, q) => a + q.y, 0) / pool.length;
    pool.sort((a, q) => Math.hypot(a.x - cx, a.y - cy) - Math.hypot(q.x - cx, q.y - cy));
    const margin = (best - 1) * g;               // hücre merkezinden en yakın başarısız hücreye (best) mesafe - 1 hücre
    return { x: pool[0].x, y: pool[0].y, margin, robust: margin >= (opts.minMargin == null ? g : opts.minMargin), count };
  }

  SV.Physics = {
    STEP, GRAVITY, BALL_R, MAX_PULL, MIN_PULL, PULL_VIS, LAUNCH_K, REST, FRICTION,
    contact, resolve, stepBall, ColliderSet, launchState, restPosition, clampPull,
    simulateShot, trajectory, assistPull, solveShot
  };
})(typeof window !== 'undefined' ? window : globalThis);
