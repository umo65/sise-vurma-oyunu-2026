/*
 * EFEKTLER: cam kırılması, sıvı sıçraması, konfeti, parlamalar, yazılar.
 * Hepsi Phaser parçacık yayıcılarıyla yapılır ve işi bitince kendini siler.
 * Dokular R kat büyük üretildiği için ölçekler 1/R ile verilir.
 */
(function (root) {
  'use strict';
  const SV = (root.SV = root.SV || {});
  const hexInt = (h) => parseInt(String(h).replace('#', ''), 16);

  function emit(scene, x, y, key, cfg, count, life) {
    const e = scene.add.particles(x, y, key, Object.assign({ emitting: false }, cfg));
    e.setDepth(cfg.depth || 60);
    e.explode(count);
    scene.time.delayedCall(life || 2200, () => e.destroy());
    return e;
  }

  const Fx = {
    /** Doğru şişe kırıldı: cam parçaları + renkli sıvı sıçraması + halka + yıldızlar. */
    shatter(scene, x, y, col, size) {
      const R = SV.G.R, sc = (size || 1);
      const hex = hexInt(col.hex), light = hexInt(col.light);
      // parlama
      const glow = scene.add.image(x, y, 'glow').setBlendMode(Phaser.BlendModes.ADD).setDepth(59).setTint(light);
      glow.setScale(0.5 / R * sc);
      scene.tweens.add({ targets: glow, scale: 3.6 / R * sc, alpha: 0, duration: 420, ease: 'Cubic.easeOut', onComplete: () => glow.destroy() });
      // halka
      const ring = scene.add.image(x, y, 'ring').setDepth(58).setTint(hex).setAlpha(0.95);
      ring.setScale(0.15 / R);
      scene.tweens.add({ targets: ring, scale: 1.7 / R * sc, alpha: 0, duration: 520, ease: 'Cubic.easeOut', onComplete: () => ring.destroy() });
      // cam parçaları
      emit(scene, x, y, 'shard', {
        speed: { min: 220, max: 700 }, angle: { min: 0, max: 360 }, gravityY: 1500,
        lifespan: { min: 700, max: 1200 }, scale: { start: (0.55 * sc) / R, end: (0.2 * sc) / R },
        rotate: { start: 0, end: 540 }, alpha: { start: 1, end: 0 }
      }, 26, 1500);
      // sıvı damlaları
      emit(scene, x, y, 'drop', {
        speed: { min: 150, max: 560 }, angle: { min: 195, max: 345 }, gravityY: 1300,
        lifespan: { min: 600, max: 1100 }, scale: { start: (0.95 * sc) / R, end: (0.35 * sc) / R },
        tint: [hex, hex, light], alpha: { start: 1, end: 0.1 }
      }, 34, 1500);
      // yıldız ışıltıları
      emit(scene, x, y, 'spark', {
        speed: { min: 90, max: 380 }, angle: { min: 0, max: 360 }, gravityY: 200,
        lifespan: { min: 500, max: 900 }, scale: { start: 0.9 / R, end: 0 }, rotate: { start: 0, end: 200 },
        blendMode: 'ADD', tint: [0xffffff, light, 0xfff2a0]
      }, 14, 1200);
      scene.cameras.main.shake(150, 0.0045);
    },

    /** Yanlış şişe: küçük cam "tıngg" kıvılcımları. */
    tinyHit(scene, x, y, col) {
      const R = SV.G.R;
      emit(scene, x, y, 'spark', {
        speed: { min: 60, max: 260 }, angle: { min: 0, max: 360 },
        lifespan: { min: 280, max: 520 }, scale: { start: 0.8 / R, end: 0 }, blendMode: 'ADD',
        tint: [0xffffff, 0xcfeaff]
      }, 7, 800);
      if (col) {
        emit(scene, x, y, 'drop', {
          speed: { min: 80, max: 260 }, angle: { min: 200, max: 340 }, gravityY: 1200,
          lifespan: { min: 350, max: 650 }, scale: { start: 0.55 / R, end: 0.2 / R }, tint: hexInt(col.hex), alpha: { start: 1, end: 0 }
        }, 5, 900);
      }
    },

    /** Konfeti yağmuru. */
    confetti(scene, x, y, count, o) {
      o = o || {};
      const R = SV.G.R;
      emit(scene, x, y, 'confetti', {
        speed: { min: o.minSpeed || 260, max: o.maxSpeed || 780 },
        angle: { min: o.a0 == null ? 215 : o.a0, max: o.a1 == null ? 325 : o.a1 },
        gravityY: 900, lifespan: { min: 1300, max: 2300 },
        scale: { start: 1.2 / R, end: 0.8 / R }, rotate: { start: 0, end: 720 },
        tint: [0xff3b3b, 0x2f7bff, 0x2fcf4a, 0xffd21f, 0x9b4dff, 0xff8a1f, 0xff5fb0],
        alpha: { start: 1, end: 0.2 }, depth: 150
      }, count || 40, 2800);
    },

    /** Bölüm sonu şenliği: yıldızlar + yanlardan konfeti. */
    winBurst(scene) {
      const W = SV.G.W, H = SV.G.H;
      Fx.confetti(scene, W * 0.18, H * 0.9, 50, { a0: 250, a1: 300, minSpeed: 600, maxSpeed: 1100 });
      Fx.confetti(scene, W * 0.82, H * 0.9, 50, { a0: 240, a1: 290, minSpeed: 600, maxSpeed: 1100 });
      Fx.confetti(scene, W * 0.5, H * 0.35, 36, { a0: 180, a1: 360, minSpeed: 200, maxSpeed: 560 });
    },

    /** Topun arkasında renkli iz. */
    trail(scene, follow, tint) {
      const R = SV.G.R;
      const e = scene.add.particles(0, 0, 'dot', {
        follow, lifespan: 380, frequency: 22, quantity: 1,
        scale: { start: 1.4 / R, end: 0 }, alpha: { start: 0.55, end: 0 },
        tint, blendMode: 'ADD'
      });
      e.setDepth(29);
      return e;
    },

    /** Yere/platforma çarpma tozu. */
    dust(scene, x, y, power) {
      const R = SV.G.R;
      emit(scene, x, y, 'dot', {
        speed: { min: 40, max: 160 * power }, angle: { min: 200, max: 340 }, gravityY: 300,
        lifespan: { min: 250, max: 520 }, scale: { start: 1.6 / R, end: 0 },
        tint: [0xdff7c0, 0xb9e88f], alpha: { start: 0.8, end: 0 }
      }, 6, 800);
    },

    /** Ekranın ortasında büyük, kısa süren uyarı. */
    banner(scene, str, o) {
      o = o || {};
      const W = SV.G.W;
      const t = SV.UI.text(scene, W / 2, o.y || 250, str, {
        size: o.size || 64, color: o.color || '#ffffff', stroke: o.stroke || '#1b3b6b', sw: 10, depth: 160
      });
      t.setScale(0.3).setAlpha(0);
      scene.tweens.add({ targets: t, scale: 1, alpha: 1, duration: 260, ease: 'Back.easeOut' });
      scene.tweens.add({ targets: t, alpha: 0, y: (o.y || 250) - 30, delay: o.hold || 900, duration: 320, onComplete: () => t.destroy() });
      return t;
    }
  };

  SV.Fx = Fx;
})(typeof window !== 'undefined' ? window : globalThis);
