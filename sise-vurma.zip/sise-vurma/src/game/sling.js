/*
 * SAPAN: gövde görseli + iki lastik şerit.
 *  - Arka şerit topun ARKASINDA, ön şerit topun ÖNÜNDE çizilir (derinlik hissi).
 *  - Top çekilirken şeritler gerilir ve incelir.
 *  - Bırakınca şeritler öne doğru yaylanıp gevşer (snap animasyonu).
 */
(function (root) {
  'use strict';
  const SV = (root.SV = root.SV || {});
  const U = SV.U;

  const DARK = 0x3b1d0b, MID = 0xa8512a, LITE = 0xe39a62;

  class Sling {
    constructor(scene) {
      const G = SV.G, R = G.R, S = SV.Levels.SLING, g = G.sling;
      this.scene = scene;
      this.anchor = { x: S.x, y: S.y };
      this.tipBack = g.tipBack;
      this.tipFront = g.tipFront;
      this.img = scene.add.image(S.x, g.baseY, 'sling').setOrigin(0.5, (g.h - 6) / g.h).setScale(1 / R).setDepth(20);
      this.back = scene.add.graphics().setDepth(19);
      this.front = scene.add.graphics().setDepth(23);
      this.snapT = -1;
      this.snapFrom = null;
      this.ball = null;      // {x, y} ya da null
      this.stretch = 0;
      this.draw();
    }

    /** Top sapandayken (çekilirken) konumunu bildir; null = top yok. */
    holdBall(pos, stretch) {
      this.ball = pos ? { x: pos.x, y: pos.y } : null;
      this.stretch = stretch || 0;
      this.snapT = -1;
      this.draw();
    }

    /** Top fırlatıldı: şeritler öne doğru yaylansın. */
    release(fromPos) {
      this.ball = null;
      this.snapFrom = { x: fromPos.x, y: fromPos.y };
      this.snapT = 0;
    }

    update(dt) {
      if (this.snapT >= 0) {
        this.snapT += dt;
        if (this.snapT > 0.5) { this.snapT = -1; this.snapFrom = null; }
        this.draw();
      }
    }

    band(g, tip, to, width) {
      g.lineStyle(width + 5, DARK, 1); g.lineBetween(tip.x, tip.y, to.x, to.y);
      g.lineStyle(width, MID, 1); g.lineBetween(tip.x, tip.y, to.x, to.y);
      g.lineStyle(Math.max(2, width * 0.3), LITE, 0.9); g.lineBetween(tip.x - 1, tip.y - 1.5, to.x - 1, to.y - 1.5);
      g.fillStyle(DARK, 1); g.fillCircle(tip.x, tip.y, width * 0.65);
    }

    draw() {
      const b = this.back, f = this.front;
      b.clear(); f.clear();
      const A = this.tipBack, B = this.tipFront;
      if (this.ball) {
        const w = 11 - 5 * this.stretch;
        const p = this.ball;
        this.band(b, A, { x: p.x - 7, y: p.y - 1 }, w);
        this.band(f, B, { x: p.x + 7, y: p.y + 1 }, w);
        return;
      }
      if (this.snapT >= 0 && this.snapFrom) {
        // yaylı geri dönüş: dinlenme noktası etrafında sönümlü salınım
        const t = this.snapT, k = Math.exp(-9 * t) * Math.cos(26 * t);
        const c = this.anchor, s = this.snapFrom;
        const p = { x: c.x + (s.x - c.x) * k, y: c.y + (s.y - c.y) * k };
        this.band(b, A, { x: p.x - 3, y: p.y }, 9);
        this.band(f, B, { x: p.x + 3, y: p.y }, 9);
        return;
      }
      // gevşek: iki uç arasında hafif sarkan şerit
      const sag = 9;
      const mid = { x: (A.x + B.x) / 2, y: (A.y + B.y) / 2 + sag };
      this.band(b, A, mid, 9);
      this.band(f, B, mid, 9);
    }

    destroy() { this.img.destroy(); this.back.destroy(); this.front.destroy(); }
  }

  SV.Sling = Sling;
})(typeof window !== 'undefined' ? window : globalThis);
