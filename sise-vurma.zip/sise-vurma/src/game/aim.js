/*
 * NİŞAN ALMA GİRDİSİ (dokunmatik + fare)
 *
 * Parmak (ya da fare) ekranın herhangi bir yerine basılır ve GERİYE (sola) /
 * aşağıya sürüklenir; bırakınca top fırlatılır. Çekiş, basılan noktaya göre
 * ölçülür ("sanal çekiş"), böylece küçük topu tam parmakla yakalamak gerekmez.
 *
 * cfg:
 *   canStart(pointer)  -> bool   nişan alınabilir mi?
 *   onStart()          -> void
 *   onMove(pull)       -> void   pull = {x, y, len} (fizik.js clampPull)
 *   onRelease(pull)    -> void   (vazgeçildiyse onCancel)
 *   onCancel()         -> void
 */
(function (root) {
  'use strict';
  const SV = (root.SV = root.SV || {});

  class AimController {
    constructor(scene, cfg) {
      this.scene = scene;
      this.cfg = cfg;
      this.active = false;
      this.pid = null;
      this.origin = null;
      this.pull = { x: 0, y: 0, len: 0 };
      const inp = scene.input;
      this._down = (p, over) => this.down(p, over);
      this._move = (p) => this.move(p);
      this._up = (p) => this.up(p);
      inp.on('pointerdown', this._down);
      inp.on('pointermove', this._move);
      inp.on('pointerup', this._up);
      inp.on('pointerupoutside', this._up);
      scene.events.once('shutdown', () => this.destroy());
    }

    world(p) {
      const v = this.scene.cameras.main.getWorldPoint(p.x, p.y);
      return { x: v.x, y: v.y };
    }

    down(p, over) {
      if (this.active || (over && over.length) || !this.cfg.canStart(p)) return;
      this.active = true;
      this.pid = p.id;
      this.origin = this.world(p);
      this.pull = { x: 0, y: 0, len: 0 };
      if (this.cfg.onStart) this.cfg.onStart();
    }

    move(p) {
      if (!this.active || p.id !== this.pid) return;
      const w = this.world(p);
      this.pull = SV.Physics.clampPull(w.x - this.origin.x, w.y - this.origin.y, SV.Levels.GROUND_Y);
      this.cfg.onMove(this.pull);
    }

    up(p) {
      if (!this.active || p.id !== this.pid) return;
      this.active = false;
      const pull = this.pull;
      if (pull.len >= SV.Physics.MIN_PULL) this.cfg.onRelease(pull);
      else if (this.cfg.onCancel) this.cfg.onCancel();
    }

    /** Dışarıdan iptal (ör. pencere açıldı). */
    cancel() {
      if (!this.active) return;
      this.active = false;
      if (this.cfg.onCancel) this.cfg.onCancel();
    }

    destroy() {
      const inp = this.scene.input;
      if (!inp) return;
      inp.off('pointerdown', this._down);
      inp.off('pointermove', this._move);
      inp.off('pointerup', this._up);
      inp.off('pointerupoutside', this._up);
    }
  }

  SV.AimController = AimController;
})(typeof window !== 'undefined' ? window : globalThis);
