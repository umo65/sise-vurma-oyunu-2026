/*
 * ŞİŞE GÖRÜNÜMÜ (Phaser nesnesi)
 *
 * Katmanlar (aşağıdan yukarıya):
 *   arka cam  ->  sıvı (her karede hesaplanır)  ->  baloncuklar  ->  ön cam  ->  ışıltı / parlama
 * Cam dokusu rengisizdir; yalnızca sıvı renklidir. Sıvı hacmi sabittir: şişe sallansa
 * da yüzeyi yatay kalır ve çarpınca yaylanarak çalkalanır (spring).
 *
 * Fizik çarpışması burada DEĞİL, physics.js içindedir; bu sınıf yalnızca görünümdür.
 */
(function (root) {
  'use strict';
  const SV = (root.SV = root.SV || {});
  const BA = SV.BottleArt;
  const U = SV.U;

  const hexInt = (h) => parseInt(h.replace('#', ''), 16);

  function fillPoly(g, buf, n, color, alpha) {
    if (n < 3) return;
    g.fillStyle(color, alpha);
    g.beginPath();
    g.moveTo(buf[0], buf[1]);
    for (let i = 1; i < n; i++) g.lineTo(buf[2 * i], buf[2 * i + 1]);
    g.closePath();
    g.fillPath();
  }

  class BottleView {
    /**
     * @param def { colorId, shape, scale, fill }
     * @param seed küçük rastgelelik (faz) için sayı
     */
    constructor(scene, def, seed) {
      this.scene = scene;
      this.def = def;
      this.col = SV.Levels.BY_ID[def.colorId];
      this.hex = hexInt(this.col.hex);
      this.light = hexInt(this.col.light);
      this.dark = hexInt(this.col.dark);
      const s = (this.s = def.scale);
      const g = (this.glass = BA.glassFor(scene, def.shape, s));
      this.H = SV.Shapes.height(def.shape, s);
      this.k = Math.max(0.8, s);

      this.root = scene.add.container(0, 0);
      const org = [g.ox / g.w, g.oy / g.h];
      this.back = scene.add.image(0, 0, g.back).setOrigin(org[0], org[1]).setScale(1 / g.R);
      this.liq = scene.add.graphics();
      this.front = scene.add.image(0, 0, g.front).setOrigin(org[0], org[1]).setScale(1 / g.R);
      this.glint = scene.add.image(0, 0, 'spark').setScale(0).setBlendMode(Phaser.BlendModes.ADD);
      this.glow = scene.add.image(0, -this.H * 0.5, 'glow').setBlendMode(Phaser.BlendModes.ADD).setAlpha(0);
      this.R = g.R;
      const gs = (this.H * 1.5) / 128 / g.R;   // dokular R kat büyük üretildiği için 1/R ile küçült
      this.glow.setScale(gs * 0.9, gs);
      this.root.add([this.back, this.liq, this.front, this.glint, this.glow]);

      this.liquid = new BA.Liquid(def.shape, s, def.fill);

      // yaylı hareketler
      this.wob = 0; this.wobV = 0;     // şişenin tabanı etrafında sallanma (rad)
      this.sl = 0; this.slV = 0;       // sıvı yüzeyi eğimi (rad)
      this.flash = 0;
      this.seed = (seed || 0) * 1.7 + 0.3;
      this.t = 0;
      this.dead = false;

      // baloncuklar (yerel koordinat)
      const bw = SV.Shapes.DEFS[def.shape].bw * s;
      this.bubbles = [];
      const rnd = U.rng(Math.floor(this.seed * 977) + 5);
      for (let i = 0; i < 4; i++) {
        this.bubbles.push({
          x: (rnd() * 2 - 1) * bw * 0.55, y: -rnd() * this.H * 0.4 - 10,
          r: (1.8 + rnd() * 2.2) * this.k, v: 10 + rnd() * 14, ph: rnd() * 6.28
        });
      }
      this.bw = bw;
      this.lastDraw = { ux: 0, uy: -1 };
      this.draw(0, -1);
    }

    setBase(x, y) { this.root.setPosition(x, y); return this; }
    setDepth(d) { this.root.setDepth(d); return this; }
    get x() { return this.root.x; }
    get y() { return this.root.y; }
    /** Şişenin görsel merkezi (efektler için). */
    center() { return { x: this.root.x, y: this.root.y - this.H * 0.5 }; }

    /** Doğma animasyonu: küçükten büyüğe zıplayarak belirir. */
    pop(delay) {
      this.root.setScale(0.05).setAlpha(0);
      this.scene.tweens.add({ targets: this.root, scale: 1, alpha: 1, delay: delay || 0, duration: 420, ease: 'Back.easeOut' });
    }

    /**
     * Topla çarpışma tepkisi: sallanma + sıvı çalkalanması + cam parlaması.
     * @param dir  -1 (soldan sağa vurdu: sağa yatar) .. +1
     * @param power 0..1 çarpma şiddeti
     */
    hit(dir, power) {
      const p = U.clamp(power == null ? 0.6 : power, 0.15, 1);
      this.wobV += dir * (1.4 + 3.2 * p);
      this.slV += dir * (5 + 12 * p);
      this.flash = 1;
    }

    /** Çalkalanmayı yaylarla sürdür ve görünümü yenile. */
    update(dt, t) {
      if (this.dead) return;
      dt = Math.min(dt, 0.05);
      this.t = t;
      // sallanma yayı (tabanda menteşe)
      this.wobV += (-120 * this.wob - 5.2 * this.wobV) * dt;
      this.wob += this.wobV * dt;
      // sıvı yüzeyi yayı (daha yavaş ve daha az sönümlü: "çalkalanma")
      this.slV += (-62 * this.sl - 2.4 * this.slV) * dt;
      this.sl += this.slV * dt;
      const idle = 0.02 * Math.sin(t * 1.8 + this.seed) + 0.008 * Math.sin(t * 3.1 + this.seed * 2);
      this.root.rotation = this.wob;
      // Yüzey normali (yerel koordinat). Dünya "yukarı" = (0,-1); şişe wob kadar dönmüşse yerelde -wob döner.
      const th = this.wob - (this.sl + idle);
      const ux = -Math.sin(th), uy = -Math.cos(th);
      this.draw(ux, uy, dt);

      // cam parlaması
      this.flash = Math.max(0, this.flash - dt * 3.2);
      this.glow.setAlpha(this.flash * 0.75);
      // ışıltı (arada bir parlayan yıldız)
      const ph = (t * 0.55 + this.seed) % 3.4;
      const gl = ph < 0.5 ? Math.sin((ph / 0.5) * Math.PI) : 0;
      this.glint.setPosition(-this.bw * 0.34, -this.H * 0.72).setScale((gl * 0.55 * this.k) / this.R).setRotation(ph * 2).setAlpha(gl);
    }

    draw(ux, uy, dt) {
      const L = this.liquid, g = this.liq;
      const r = L.solve(ux, uy);
      g.clear();
      if (r.n < 3) return;
      const chord = L.chord(r.n, ux, uy, r.c);
      const BUF = BA.BUF, BUF2 = BA.BUF2;
      const depth = r.c - r.lo;
      // 1) gövde
      fillPoly(g, BUF, r.n, this.hex, 0.9);
      // 2) alt gölge (derinlik)
      let m = BA.clipFlat(BUF, r.n, ux, uy, r.c - depth * 0.55, BUF2);
      fillPoly(g, BUF2, m, this.dark, 0.34);
      // 3) yüzeye yakın açık bant
      m = BA.clipFlat(BUF, r.n, -ux, -uy, -(r.c - 13 * this.k), BUF2);
      fillPoly(g, BUF2, m, this.light, 0.34);
      // 4) yan ışık: sol tarafta ince açık şerit (cam yansımasıyla uyumlu)
      m = BA.clipFlat(BUF, r.n, 1, 0, -this.bw * 0.52, BUF2); // x <= -0.52*bw
      fillPoly(g, BUF2, m, this.light, 0.24);

      // 5) yüzey: açık elips + parlak çizgi
      if (chord) {
        const mid = (chord.smin + chord.smax) / 2, len = chord.smax - chord.smin;
        const cx = ux * r.c + chord.tx * mid, cy = uy * r.c + chord.ty * mid;
        const ang = Math.atan2(chord.ty, chord.tx);
        g.save();
        g.translateCanvas(cx, cy); g.rotateCanvas(ang);
        g.fillStyle(this.light, 0.9);
        g.fillEllipse(0, 0, Math.max(2, len - 3), 7.5 * this.k);
        g.fillStyle(0xffffff, 0.4);
        g.fillEllipse(-len * 0.12, -0.8 * this.k, Math.max(2, len * 0.55), 3.2 * this.k);
        g.restore();
      }

      // 6) baloncuklar
      if (dt) {
        const bs = this.bubbles;
        for (let i = 0; i < bs.length; i++) {
          const b = bs[i];
          b.y -= b.v * dt;
          const sy = (r.c - ux * b.x) / uy; // yüzey yüksekliği (b.x'te)
          if (b.y < sy + 8 * this.k) { b.y = -(6 + Math.random() * 6) * this.k; b.x = (Math.random() * 2 - 1) * this.bw * 0.55; }
        }
      }
      g.lineStyle(1.6 * this.k, 0xffffff, 0.7);
      g.fillStyle(0xffffff, 0.22);
      const bs = this.bubbles;
      for (let i = 0; i < bs.length; i++) {
        const b = bs[i];
        const sy = (r.c - ux * b.x) / uy;
        if (b.y > sy + 6 * this.k && r.n > 2) {
          const bx = b.x + Math.sin(this.t * 2.2 + b.ph) * 2.2;
          g.fillCircle(bx, b.y, b.r);
          g.strokeCircle(bx, b.y, b.r);
        }
      }
    }

    destroy() {
      this.dead = true;
      this.scene.tweens.killTweensOf(this.root);
      this.root.destroy();
    }
  }

  SV.BottleView = BottleView;
})(typeof window !== 'undefined' ? window : globalThis);
