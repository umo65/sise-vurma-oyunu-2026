/*
 * OYUN ÖĞELERİ DOKULARI: renkli toplar, ikonlar, parçacıklar.
 * İkonlar beyaz çizilir; düğmeler gerektiğinde renk/gölge verir (Phaser tint).
 */
(function (root) {
  'use strict';
  const SV = (root.SV = root.SV || {});
  const { mk, put, lin, circle } = SV.TexUtil;
  const U = SV.U;

  function paintBall(ctx, S, col) {
    const c = S / 2, r = SV.Physics.BALL_R;
    // gölgeli gövde
    const g = ctx.createRadialGradient(c - 7, c - 9, 2, c, c, r + 2);
    g.addColorStop(0, col.light); g.addColorStop(0.45, col.hex); g.addColorStop(1, col.dark);
    ctx.fillStyle = g; ctx.strokeStyle = U.mix(col.dark, '#000000', 0.45); ctx.lineWidth = 3.4;
    circle(ctx, c, c, r); ctx.fill(); ctx.stroke();
    // alt-sağ yansıma
    ctx.strokeStyle = 'rgba(255,255,255,0.28)'; ctx.lineWidth = 2.2;
    ctx.beginPath(); ctx.arc(c, c, r - 4.5, 0.35, 1.25); ctx.stroke();
    // üst-sol parlama
    ctx.fillStyle = 'rgba(255,255,255,0.88)';
    ctx.beginPath(); ctx.ellipse(c - 8, c - 10, 6.6, 4.2, -0.7, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.7)'; circle(ctx, c - 1, c - 15.5, 1.8); ctx.fill();
    // şerit (top deseni)
    ctx.save(); circle(ctx, c, c, r - 1.5); ctx.clip();
    ctx.strokeStyle = 'rgba(255,255,255,0.22)'; ctx.lineWidth = 5;
    ctx.beginPath(); ctx.moveTo(c - r, c + 5); ctx.quadraticCurveTo(c, c + 14, c + r, c + 2); ctx.stroke();
    ctx.restore();
  }

  function star(ctx, cx, cy, ro, ri) {
    ctx.beginPath();
    for (let i = 0; i < 10; i++) {
      const a = -Math.PI / 2 + (i * Math.PI) / 5, rr = i % 2 ? ri : ro;
      const x = cx + Math.cos(a) * rr, y = cy + Math.sin(a) * rr;
      if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y);
    }
    ctx.closePath();
  }

  const ICONS = {
    restart(ctx, c) {
      ctx.strokeStyle = '#fff'; ctx.fillStyle = '#fff'; ctx.lineWidth = 8; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.arc(c, c, 19, -0.9, Math.PI * 1.55); ctx.stroke();
      const a = -0.9, x = c + Math.cos(a) * 19, y = c + Math.sin(a) * 19;
      ctx.beginPath(); ctx.moveTo(x + 13, y - 12); ctx.lineTo(x - 2, y - 6); ctx.lineTo(x + 8, y + 10); ctx.closePath();
      ctx.lineJoin = 'round'; ctx.lineWidth = 4; ctx.stroke(); ctx.fill();
    },
    sound_on(ctx, c) {
      ctx.fillStyle = '#fff'; ctx.strokeStyle = '#fff'; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(c - 22, c - 9); ctx.lineTo(c - 12, c - 9); ctx.lineTo(c, c - 20); ctx.lineTo(c, c + 20); ctx.lineTo(c - 12, c + 9); ctx.lineTo(c - 22, c + 9); ctx.closePath(); ctx.fill();
      ctx.lineWidth = 5;
      ctx.beginPath(); ctx.arc(c + 3, c, 11, -0.9, 0.9); ctx.stroke();
      ctx.beginPath(); ctx.arc(c + 3, c, 20, -0.95, 0.95); ctx.stroke();
    },
    sound_off(ctx, c) {
      ctx.fillStyle = '#fff'; ctx.strokeStyle = '#fff'; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(c - 24, c - 9); ctx.lineTo(c - 14, c - 9); ctx.lineTo(c - 2, c - 20); ctx.lineTo(c - 2, c + 20); ctx.lineTo(c - 14, c + 9); ctx.lineTo(c - 24, c + 9); ctx.closePath(); ctx.fill();
      ctx.lineWidth = 6;
      ctx.beginPath(); ctx.moveTo(c + 8, c - 10); ctx.lineTo(c + 26, c + 10); ctx.moveTo(c + 26, c - 10); ctx.lineTo(c + 8, c + 10); ctx.stroke();
    },
    home(ctx, c) {
      ctx.fillStyle = '#fff'; ctx.strokeStyle = '#fff'; ctx.lineJoin = 'round'; ctx.lineWidth = 6;
      ctx.beginPath(); ctx.moveTo(c - 25, c - 1); ctx.lineTo(c, c - 24); ctx.lineTo(c + 25, c - 1); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(c - 17, c - 2); ctx.lineTo(c, c - 18); ctx.lineTo(c + 17, c - 2); ctx.lineTo(c + 17, c + 21); ctx.lineTo(c + 5, c + 21); ctx.lineTo(c + 5, c + 7); ctx.lineTo(c - 5, c + 7); ctx.lineTo(c - 5, c + 21); ctx.lineTo(c - 17, c + 21); ctx.closePath(); ctx.fill();
    },
    play(ctx, c) {
      ctx.fillStyle = '#fff'; ctx.strokeStyle = '#fff'; ctx.lineJoin = 'round'; ctx.lineWidth = 7;
      ctx.beginPath(); ctx.moveTo(c - 13, c - 19); ctx.lineTo(c + 19, c); ctx.lineTo(c - 13, c + 19); ctx.closePath(); ctx.stroke(); ctx.fill();
    },
    video(ctx, c) { // reklam ikonu: kamera/oynat
      ctx.fillStyle = '#fff'; ctx.strokeStyle = '#fff'; ctx.lineJoin = 'round';
      SV.BottleArt.roundRect(ctx, c - 24, c - 16, 33, 32, 7); ctx.fill();
      ctx.beginPath(); ctx.moveTo(c + 12, c - 5); ctx.lineTo(c + 26, c - 14); ctx.lineTo(c + 26, c + 14); ctx.lineTo(c + 12, c + 5); ctx.closePath(); ctx.fill();
    },
    check(ctx, c) {
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 9; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      ctx.beginPath(); ctx.moveTo(c - 17, c + 1); ctx.lineTo(c - 5, c + 13); ctx.lineTo(c + 18, c - 13); ctx.stroke();
    },
    cross(ctx, c) {
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 9; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(c - 15, c - 15); ctx.lineTo(c + 15, c + 15); ctx.moveTo(c + 15, c - 15); ctx.lineTo(c - 15, c + 15); ctx.stroke();
    },
    arrow(ctx, c) { // sağ ok (SONRAKİ BÖLÜM)
      ctx.strokeStyle = '#fff'; ctx.fillStyle = '#fff'; ctx.lineWidth = 8; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      ctx.beginPath(); ctx.moveTo(c - 20, c); ctx.lineTo(c + 10, c); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(c + 4, c - 17); ctx.lineTo(c + 22, c); ctx.lineTo(c + 4, c + 17); ctx.stroke();
    },
    spinner(ctx, c) {
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 8; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.arc(c, c, 22, 0, Math.PI * 1.45); ctx.stroke();
    }
  };

  function paintStar(ctx, S, on) {
    const c = S / 2;
    star(ctx, c, c + 3, S * 0.46, S * 0.2);
    ctx.lineJoin = 'round';
    if (on) {
      ctx.fillStyle = lin(ctx, 0, 0, 0, S, [[0, '#fff08a'], [0.5, '#ffd21f'], [1, '#ff9f1a']]);
      ctx.strokeStyle = '#b8620a';
    } else {
      ctx.fillStyle = lin(ctx, 0, 0, 0, S, [[0, '#d7dfe8'], [1, '#aab6c4']]);
      ctx.strokeStyle = '#6f7d90';
    }
    ctx.lineWidth = 4.5; ctx.fill(); ctx.stroke();
    if (on) {
      ctx.fillStyle = 'rgba(255,255,255,0.7)';
      ctx.beginPath(); ctx.ellipse(c - 9, c - 11, 5, 3, -0.7, 0, Math.PI * 2); ctx.fill();
    }
  }

  function paintMark(ctx, S, col1, col2, icon) {
    const c = S / 2;
    const g = ctx.createRadialGradient(c - 6, c - 8, 2, c, c, c);
    g.addColorStop(0, col1); g.addColorStop(1, col2);
    ctx.fillStyle = g; ctx.strokeStyle = 'rgba(255,255,255,0.95)'; ctx.lineWidth = 5;
    circle(ctx, c, c, c - 4); ctx.fill(); ctx.stroke();
    ICONS[icon](ctx, c);
  }

  const Items = {
    build(scene) {
      if (scene.textures.exists('spark')) return;
      let c;
      // renkli toplar
      const S = Math.ceil(SV.Physics.BALL_R * 2 + 10);
      SV.Levels.COLORS.forEach((col) => {
        c = mk(S, S); paintBall(c.ctx, S, col); put(scene, 'ball_' + col.id, c);
      });
      // beyaz ikonlar (64x64)
      Object.keys(ICONS).forEach((k) => { c = mk(64, 64); ICONS[k](c.ctx, 32); put(scene, 'icon_' + k, c); });
      // yıldızlar
      c = mk(72, 72); paintStar(c.ctx, 72, true); put(scene, 'star_on', c);
      c = mk(72, 72); paintStar(c.ctx, 72, false); put(scene, 'star_off', c);
      // rozetler
      c = mk(64, 64); paintMark(c.ctx, 64, '#ff7a7a', '#d81f2a', 'cross'); put(scene, 'mark_x', c);
      c = mk(64, 64); paintMark(c.ctx, 64, '#8cf27a', '#1fae3a', 'check'); put(scene, 'mark_ok', c);
      // parçacıklar
      c = mk(40, 40); SV.BottleArt.sparkle(c.ctx, 20, 20, 18, 1); put(scene, 'spark', c);
      c = mk(28, 28);
      c.ctx.fillStyle = '#fff'; c.ctx.beginPath(); c.ctx.moveTo(2, 24); c.ctx.lineTo(10, 2); c.ctx.lineTo(26, 18); c.ctx.closePath(); c.ctx.fill();
      c.ctx.fillStyle = 'rgba(160,210,255,0.55)'; c.ctx.beginPath(); c.ctx.moveTo(10, 2); c.ctx.lineTo(26, 18); c.ctx.lineTo(15, 14); c.ctx.closePath(); c.ctx.fill();
      put(scene, 'shard', c);
      c = mk(24, 24);
      const g = c.ctx.createRadialGradient(9, 8, 1, 12, 12, 11);
      g.addColorStop(0, '#fff'); g.addColorStop(0.5, '#ddd'); g.addColorStop(1, '#fff');
      c.ctx.fillStyle = g; circle(c.ctx, 12, 12, 10); c.ctx.fill(); put(scene, 'drop', c);
      c = mk(18, 11); c.ctx.fillStyle = '#fff'; SV.BottleArt.roundRect(c.ctx, 1, 1, 16, 9, 2); c.ctx.fill(); put(scene, 'confetti', c);
      c = mk(140, 140); c.ctx.strokeStyle = '#fff'; c.ctx.lineWidth = 8; circle(c.ctx, 70, 70, 60); c.ctx.stroke(); put(scene, 'ring', c);
      c = mk(128, 128);
      const rg = c.ctx.createRadialGradient(64, 64, 2, 64, 64, 64);
      rg.addColorStop(0, 'rgba(255,255,255,1)'); rg.addColorStop(0.4, 'rgba(255,255,255,0.45)'); rg.addColorStop(1, 'rgba(255,255,255,0)');
      c.ctx.fillStyle = rg; c.ctx.fillRect(0, 0, 128, 128); put(scene, 'glow', c);
      c = mk(16, 16); c.ctx.fillStyle = '#fff'; circle(c.ctx, 8, 8, 7); c.ctx.fill(); put(scene, 'dot', c);
    }
  };

  SV.Tex = SV.Tex || {};
  SV.Tex.items = Items;
})(typeof window !== 'undefined' ? window : globalThis);
