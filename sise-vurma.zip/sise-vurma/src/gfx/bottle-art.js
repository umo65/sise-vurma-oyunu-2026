/*
 * ŞİŞE ÇİZİMİ: geometri + şeffaf cam dokusu + sıvı hesabı
 *
 * Yerel koordinat: orijin = şişe tabanının orta noktası, y yukarı doğru EKSİ
 * (shapes.js ile aynı). Şişe iki katmandan oluşur:
 *   - cam (arka + ön): tamamen şeffaf, yalnızca kenar çizgisi, parlama ve yansıma
 *   - sıvı: cam içinde her karede hesaplanır; şişe yatsa da yüzeyi yatay kalır,
 *     hacim korunur (bölme ile alan eşitlenir) ve çarpınca yaylanarak çalkalanır
 * Cam rengi YOKTUR; yalnızca sıvı renklidir.
 */
(function (root) {
  'use strict';
  const SV = (root.SV = root.SV || {});

  /* ----------------------------- Geometri ----------------------------- */

  /** Şişe dış çizgisi (düz dizi [x0,y0,x1,y1,...]). inset: cam kalınlığı kadar içeri. */
  function outline(name, s, inset) {
    const d = SV.Shapes.DEFS[name];
    inset = inset || 0;
    const bw = d.bw * s - inset, nw = d.nw * s - inset, lw = d.lw * s - inset * 0.5;
    const bh = d.bh * s, sh = d.sh * s, nh = d.nh * s, lh = d.lh * s;
    const base = -inset;
    const r = Math.max(2, Math.min(d.r * s - inset * 0.5, bw, (bh + base) / 2));
    const yTop = -(bh + sh + nh + lh);
    const L = [];
    L.push([-lw, yTop], [-lw, yTop + lh], [-nw, yTop + lh + 2 * s], [-nw, -(bh + sh)]);
    const N = 10;
    for (let i = 1; i <= N; i++) {
      const t = i / N, e = 0.5 - 0.5 * Math.cos(Math.PI * t);
      L.push([-(nw + (bw - nw) * e), -(bh + sh) + sh * t]);
    }
    L.push([-bw, base - r]);
    const M = Math.max(6, Math.round(r / 2.5));
    for (let i = 1; i <= M; i++) {
      const th = Math.PI - (Math.PI / 2) * (i / M);
      L.push([-bw + r + r * Math.cos(th), base - r + r * Math.sin(th)]);
    }
    const out = [];
    L.forEach((p) => out.push(p[0], p[1]));
    for (let i = L.length - 1; i >= 0; i--) out.push(-L[i][0], L[i][1]);
    return Float32Array.from(out);
  }

  const BUF = new Float32Array(1024);
  const BUF2 = new Float32Array(1024);

  /** Sutherland-Hodgman: dot(p, up) <= c olan bölgeyi dst'ye yazar; nokta sayısını döndürür. */
  function clipFlat(src, n, ux, uy, c, dst) {
    let m = 0;
    for (let i = 0; i < n; i++) {
      const j = i + 1 === n ? 0 : i + 1;
      const ax = src[2 * i], ay = src[2 * i + 1], bx = src[2 * j], by = src[2 * j + 1];
      const da = ax * ux + ay * uy - c, db = bx * ux + by * uy - c;
      if (da <= 0) { dst[m++] = ax; dst[m++] = ay; }
      if ((da < 0 && db > 0) || (da > 0 && db < 0)) {
        const t = da / (da - db);
        dst[m++] = ax + (bx - ax) * t; dst[m++] = ay + (by - ay) * t;
      }
    }
    return m >> 1;
  }

  function areaFlat(a, n) {
    let s = 0;
    for (let i = 0; i < n; i++) {
      const j = i + 1 === n ? 0 : i + 1;
      s += a[2 * i] * a[2 * j + 1] - a[2 * j] * a[2 * i + 1];
    }
    return Math.abs(s) / 2;
  }

  /** Bir şişenin sıvı modeli: sabit hacim, eğik yüzey. */
  class Liquid {
    constructor(name, s, fill) {
      this.name = name; this.s = s;
      this.inset = 3.6 * Math.max(0.8, s);
      this.poly = outline(name, s, this.inset);
      this.n = this.poly.length / 2;
      const d = SV.Shapes.DEFS[name];
      // Boyun tabanının altındaki iç hacim: doluluk oranı buna göre
      const neckBase = (d.bh + d.sh * 0.9) * s;
      const m = clipFlat(this.poly, this.n, 0, -1, neckBase, BUF);
      this.target = areaFlat(BUF, m) * fill;
      this.hmin = 0;
    }

    /**
     * Yüzey normali (ux,uy) için seviye c'yi bulur ve sıvı çokgenini BUF'a yazar.
     * @returns {{n:number, c:number, depth:number}}
     */
    solve(ux, uy) {
      const P = this.poly, n = this.n;
      let lo = 1e9, hi = -1e9;
      for (let i = 0; i < n; i++) {
        const h = P[2 * i] * ux + P[2 * i + 1] * uy;
        if (h < lo) lo = h;
        if (h > hi) hi = h;
      }
      let a = lo, b = hi;
      for (let k = 0; k < 14; k++) {
        const mid = (a + b) / 2;
        const m = clipFlat(P, n, ux, uy, mid, BUF);
        if (areaFlat(BUF, m) < this.target) a = mid; else b = mid;
      }
      const c = (a + b) / 2;
      return { n: clipFlat(P, n, ux, uy, c, BUF), c, lo };
    }

    /** Yüzey kordu uç noktaları (BUF'taki c düzlemi üzerindeki noktalar). */
    chord(n, ux, uy, c) {
      let smin = 1e9, smax = -1e9, found = 0;
      const tx = -uy, ty = ux;
      for (let i = 0; i < n; i++) {
        const x = BUF[2 * i], y = BUF[2 * i + 1];
        if (Math.abs(x * ux + y * uy - c) < 1e-3) {
          const t = x * tx + y * ty;
          if (t < smin) smin = t;
          if (t > smax) smax = t;
          found++;
        }
      }
      if (found < 2) return null;
      return { smin, smax, tx, ty, ux, uy, c };
    }
  }

  /* ----------------------------- Cam dokusu ----------------------------- */

  function pathFlat(ctx, f) {
    const n = f.length / 2;
    ctx.beginPath();
    ctx.moveTo(f[0], f[1]);
    for (let i = 1; i < n; i++) ctx.lineTo(f[2 * i], f[2 * i + 1]);
    ctx.closePath();
  }

  function roundRect(ctx, x, y, w, h, r) {
    r = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  function sparkle(ctx, x, y, r, alpha) {
    ctx.save();
    ctx.translate(x, y);
    ctx.fillStyle = 'rgba(255,255,255,' + alpha + ')';
    ctx.beginPath();
    ctx.moveTo(0, -r);
    ctx.quadraticCurveTo(r * 0.12, -r * 0.12, r, 0);
    ctx.quadraticCurveTo(r * 0.12, r * 0.12, 0, r);
    ctx.quadraticCurveTo(-r * 0.12, r * 0.12, -r, 0);
    ctx.quadraticCurveTo(-r * 0.12, -r * 0.12, 0, -r);
    ctx.fill();
    ctx.restore();
  }

  /** Arka cam: hafif gölgeli, neredeyse görünmez dolgu + kalın cam taban. */
  function paintBack(ctx, name, s) {
    const d = SV.Shapes.DEFS[name], bw = d.bw * s;
    const o = outline(name, s, 0);
    pathFlat(ctx, o);
    const g = ctx.createLinearGradient(-bw, 0, bw, 0);
    g.addColorStop(0, 'rgba(190,226,255,0.30)');
    g.addColorStop(0.2, 'rgba(235,248,255,0.09)');
    g.addColorStop(0.5, 'rgba(255,255,255,0.03)');
    g.addColorStop(0.8, 'rgba(235,248,255,0.10)');
    g.addColorStop(1, 'rgba(190,226,255,0.30)');
    ctx.fillStyle = g;
    ctx.fill();
    ctx.save();
    pathFlat(ctx, o); ctx.clip();
    const k = Math.max(0.8, s);
    const gb = ctx.createLinearGradient(0, -16 * k, 0, 0);
    gb.addColorStop(0, 'rgba(255,255,255,0)');
    gb.addColorStop(1, 'rgba(180,220,255,0.40)');
    ctx.fillStyle = gb;
    ctx.fillRect(-bw, -16 * k, bw * 2, 16 * k);
    ctx.restore();
  }

  /** Ön cam: kenar çizgileri, cam kalınlığı, parlamalar, ağız halkası, ışıltı. */
  function paintFront(ctx, name, s) {
    const d = SV.Shapes.DEFS[name];
    const bw = d.bw * s, bh = d.bh * s, sh = d.sh * s, nh = d.nh * s, lh = d.lh * s, nw = d.nw * s, lw = d.lw * s;
    const k = Math.max(0.8, s);
    const yTop = -(bh + sh + nh + lh);
    const o = outline(name, s, 0);
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';

    // 1) koyu dış kenar (çizgi film konturu) + parlak iç kenar
    pathFlat(ctx, o);
    ctx.strokeStyle = 'rgba(28,66,118,0.55)'; ctx.lineWidth = 4 * k; ctx.stroke();
    pathFlat(ctx, outline(name, s, 2.4 * k));
    ctx.strokeStyle = 'rgba(255,255,255,0.88)'; ctx.lineWidth = 2.2 * k; ctx.stroke();
    // 2) cam kalınlığı: ikinci iç duvar
    pathFlat(ctx, outline(name, s, 6.5 * k));
    ctx.strokeStyle = 'rgba(255,255,255,0.26)'; ctx.lineWidth = 1.4 * k; ctx.stroke();

    // 3) parlamalar (şişe içine kırpılır)
    ctx.save();
    pathFlat(ctx, outline(name, s, 3 * k)); ctx.clip();
    // uzun sol parlama
    const x0 = -bw + 8 * k, hw = Math.max(5, bw * 0.17);
    const top = -(bh + sh * 0.55), bot = -bh * 0.1;
    const gl = ctx.createLinearGradient(0, top, 0, bot);
    gl.addColorStop(0, 'rgba(255,255,255,0)');
    gl.addColorStop(0.18, 'rgba(255,255,255,0.88)');
    gl.addColorStop(0.8, 'rgba(255,255,255,0.7)');
    gl.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = gl;
    roundRect(ctx, x0, top, hw, bot - top, hw / 2); ctx.fill();
    // ince ikinci çizgi + nokta
    ctx.fillStyle = 'rgba(255,255,255,0.5)';
    roundRect(ctx, x0 + hw + 3 * k, top + (bot - top) * 0.28, Math.max(2.5, hw * 0.34), (bot - top) * 0.34, 3); ctx.fill();
    ctx.beginPath(); ctx.arc(x0 + hw * 0.5, bot + 9 * k, Math.max(2, hw * 0.3), 0, Math.PI * 2); ctx.fill();
    // sağ kenar yansıması
    const gr = ctx.createLinearGradient(0, top, 0, bot);
    gr.addColorStop(0, 'rgba(255,255,255,0)');
    gr.addColorStop(0.5, 'rgba(255,255,255,0.36)');
    gr.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = gr;
    roundRect(ctx, bw - 14 * k, top + (bot - top) * 0.2, 5 * k, (bot - top) * 0.7, 3); ctx.fill();
    // boyun parlaması
    const ny0 = yTop + lh + 6 * k, ny1 = -(bh + sh) + sh * 0.3;
    if (ny1 - ny0 > 8) {
      const gn = ctx.createLinearGradient(0, ny0, 0, ny1);
      gn.addColorStop(0, 'rgba(255,255,255,0.1)'); gn.addColorStop(0.5, 'rgba(255,255,255,0.75)'); gn.addColorStop(1, 'rgba(255,255,255,0.15)');
      ctx.fillStyle = gn;
      roundRect(ctx, -nw + 4.5 * k, ny0, Math.max(2.5, nw * 0.24), ny1 - ny0, 3); ctx.fill();
    }
    // kalın cam taban: parlak yay
    ctx.strokeStyle = 'rgba(255,255,255,0.45)'; ctx.lineWidth = 2 * k;
    ctx.beginPath();
    ctx.moveTo(-bw * 0.62, -9 * k);
    ctx.quadraticCurveTo(0, -4 * k, bw * 0.62, -9 * k);
    ctx.stroke();
    ctx.restore();

    // 4) ağız (dudak) halkası
    ctx.save();
    const mouthY = yTop + lh * 0.45;
    ctx.fillStyle = 'rgba(30,60,100,0.14)';
    ctx.beginPath(); ctx.ellipse(0, mouthY, lw - 3 * k, 3.6 * k, 0, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.92)'; ctx.lineWidth = 2 * k;
    ctx.beginPath(); ctx.ellipse(0, mouthY, lw - 3 * k, 3.6 * k, 0, 0, Math.PI * 2); ctx.stroke();
    ctx.strokeStyle = 'rgba(28,66,118,0.4)'; ctx.lineWidth = 1.5 * k;
    ctx.beginPath(); ctx.moveTo(-lw + 1, yTop + lh); ctx.lineTo(lw - 1, yTop + lh); ctx.stroke();
    ctx.restore();

    // 5) ışıltı
    sparkle(ctx, -bw * 0.38, -(bh + sh * 0.2) - 6 * k, 8.5 * k, 0.95);
    sparkle(ctx, bw * 0.46, -bh * 0.3, 4.5 * k, 0.8);
  }

  const _cache = {};
  /**
   * Şişe şekli + ölçek için cam dokularını üretir (bir kez).
   * @returns {{back:string, front:string, ox:number, oy:number, w:number, h:number, R:number}}
   */
  function glassFor(scene, name, s) {
    const R = SV.G.R;
    const key = name + '_' + Math.round(s * 100);
    if (_cache[key]) return _cache[key];
    const d = SV.Shapes.DEFS[name];
    const hw = Math.max(d.bw, d.lw) * s, H = SV.Shapes.height(name, s), pad = 12;
    const w = Math.ceil(hw * 2 + pad * 2), h = Math.ceil(H + pad * 2);
    const make = (painter) => {
      const cv = document.createElement('canvas');
      cv.width = Math.ceil(w * R); cv.height = Math.ceil(h * R);
      const ctx = cv.getContext('2d');
      ctx.setTransform(R, 0, 0, R, (w / 2) * R, (H + pad) * R);
      painter(ctx, name, s);
      return cv;
    };
    const bk = 'glassB_' + key, fk = 'glassF_' + key;
    if (!scene.textures.exists(bk)) scene.textures.addCanvas(bk, make(paintBack));
    if (!scene.textures.exists(fk)) scene.textures.addCanvas(fk, make(paintFront));
    return (_cache[key] = { back: bk, front: fk, ox: w / 2, oy: H + pad, w, h, R });
  }

  /** Çözünürlük/yerleşim değişince eski dokular geçersizdir: önbelleği boşalt. */
  function purge() { Object.keys(_cache).forEach((k) => delete _cache[k]); }

  SV.BottleArt = { outline, clipFlat, areaFlat, Liquid, glassFor, purge, BUF, BUF2, roundRect, sparkle };
})(typeof window !== 'undefined' ? window : globalThis);
