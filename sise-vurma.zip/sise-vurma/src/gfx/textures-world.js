/*
 * DÜNYA DOKULARI (hepsi canvas ile kodla çizilir; dosya gerekmez)
 * Arka plan, güneş, bulutlar, adalı platform, sapan, zemin gölgesi.
 * Çizgi film stili: kalın koyu kontur + parlak dolgu + yumuşak ışık.
 */
(function (root) {
  'use strict';
  const SV = (root.SV = root.SV || {});
  const U = SV.U;

  function mk(w, h) {
    const R = SV.G.R;
    const cv = document.createElement('canvas');
    cv.width = Math.ceil(w * R); cv.height = Math.ceil(h * R);
    const ctx = cv.getContext('2d');
    ctx.setTransform(R, 0, 0, R, 0, 0);
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    return { cv, ctx, w, h };
  }
  function put(scene, key, c) {
    if (scene.textures.exists(key)) scene.textures.remove(key);
    scene.textures.addCanvas(key, c.cv);
  }
  function lin(ctx, x0, y0, x1, y1, stops) {
    const g = ctx.createLinearGradient(x0, y0, x1, y1);
    stops.forEach((s) => g.addColorStop(s[0], s[1]));
    return g;
  }
  function circle(ctx, x, y, r) { ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); }

  /* ------------------------------ Arka plan ------------------------------ */
  const farHill = (x, GY) => GY - 175 + 26 * Math.sin(x * 0.0045 + 0.5) + 14 * Math.sin(x * 0.011 + 2.0);
  const midHill = (x, GY) => GY - 80 + 24 * Math.sin(x * 0.0058 + 2.3) + 12 * Math.sin(x * 0.013 + 0.4);

  function hillPath(ctx, W, H, fn) {
    ctx.beginPath();
    ctx.moveTo(0, H);
    for (let x = 0; x <= W + 8; x += 8) ctx.lineTo(x, fn(x));
    ctx.lineTo(W, H);
    ctx.closePath();
  }

  function tree(ctx, x, y, sc, kind, tone) {
    ctx.save();
    ctx.translate(x, y); ctx.scale(sc, sc);
    const dark = tone ? '#3f8f4c' : '#1d6b2b', mid = tone ? '#72c47f' : '#3cbc4a', lite = tone ? '#a3e3ab' : '#7bea6a';
    const trunkO = tone ? '#7b6a55' : '#4a2a12';
    // gövde
    ctx.fillStyle = lin(ctx, -10, 0, 10, 0, [[0, '#b27a43'], [1, '#8a5a2e']]);
    ctx.strokeStyle = trunkO; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.moveTo(-9, 4); ctx.lineTo(-6, -46); ctx.lineTo(6, -46); ctx.lineTo(9, 4); ctx.closePath();
    ctx.fill(); ctx.stroke();
    ctx.strokeStyle = dark; ctx.lineWidth = 4;
    if (kind === 'pine') {
      [[-52, 64, 0], [-86, 56, 0], [-118, 46, 0]].forEach((t, i) => {
        const by = -30 + i * -34 + 6, w = 66 - i * 14;
        ctx.fillStyle = lin(ctx, 0, by - 52, 0, by, [[0, lite], [0.5, mid], [1, mid]]);
        ctx.beginPath(); ctx.moveTo(-w, by); ctx.quadraticCurveTo(0, by - 14, w, by); ctx.lineTo(0, by - 62); ctx.closePath();
        ctx.fill(); ctx.stroke();
      });
    } else {
      const blobs = [[-30, -78, 36], [30, -80, 38], [0, -112, 42], [-2, -64, 40]];
      ctx.fillStyle = mid;
      blobs.forEach((b) => { circle(ctx, b[0], b[1], b[2]); ctx.fill(); ctx.stroke(); });
      blobs.forEach((b) => { circle(ctx, b[0], b[1], b[2] - 2); ctx.fillStyle = mid; ctx.fill(); });
      ctx.fillStyle = lite;
      [[-18, -118, 16], [-40, -88, 11], [20, -96, 10]].forEach((b) => { ctx.globalAlpha = 0.75; circle(ctx, b[0], b[1], b[2]); ctx.fill(); });
      ctx.globalAlpha = 1;
      ctx.fillStyle = tone ? 'rgba(40,110,60,0.25)' : 'rgba(20,90,40,0.28)';
      ctx.beginPath(); ctx.ellipse(8, -52, 50, 16, 0, 0, Math.PI); ctx.fill();
    }
    ctx.restore();
  }

  function flower(ctx, x, y, s, petal) {
    ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
    ctx.strokeStyle = '#2f8f2f'; ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -14); ctx.stroke();
    ctx.fillStyle = petal;
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2;
      circle(ctx, Math.cos(a) * 5, -17 + Math.sin(a) * 5, 4.2); ctx.fill();
    }
    ctx.fillStyle = '#ffd53d'; circle(ctx, 0, -17, 3.6); ctx.fill();
    ctx.restore();
  }

  function paintBackground(ctx, W, H, GY) {
    const rnd = U.rng(20241);
    // gökyüzü
    ctx.fillStyle = lin(ctx, 0, 0, 0, GY, [[0, '#46b4ff'], [0.42, '#8dd8ff'], [0.8, '#d4f3ff'], [1, '#f2fdff']]);
    ctx.fillRect(0, 0, W, H);
    // güneş ışıltısı (disk ayrı sprite)
    const sx = W - 150, sy = 140;
    const gl = ctx.createRadialGradient(sx, sy, 20, sx, sy, 330);
    gl.addColorStop(0, 'rgba(255,248,190,0.85)'); gl.addColorStop(0.4, 'rgba(255,240,170,0.28)'); gl.addColorStop(1, 'rgba(255,240,170,0)');
    ctx.fillStyle = gl; ctx.fillRect(0, 0, W, GY);

    // uzak tepeler
    ctx.fillStyle = lin(ctx, 0, GY - 230, 0, GY - 80, [[0, '#a6e7a0'], [1, '#7fd68a']]);
    hillPath(ctx, W, H, (x) => farHill(x, GY)); ctx.fill();
    for (let x = 60; x < W; x += 90 + rnd() * 90) tree(ctx, x, farHill(x, GY) + 14, 0.5 + rnd() * 0.12, rnd() < 0.35 ? 'pine' : 'round', true);

    // orta tepeler
    ctx.fillStyle = lin(ctx, 0, GY - 180, 0, GY, [[0, '#7fe06a'], [1, '#4fc243']]);
    ctx.strokeStyle = '#2c8a2e'; ctx.lineWidth = 4;
    hillPath(ctx, W, H, (x) => midHill(x, GY)); ctx.fill();
    ctx.beginPath();
    for (let x = 0; x <= W + 8; x += 8) { const y = midHill(x, GY); if (x === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y); }
    ctx.stroke();
    // yakın ağaçlar
    for (let x = 30 + rnd() * 60; x < W; x += 150 + rnd() * 130) {
      tree(ctx, x, midHill(x, GY) + 22, 0.78 + rnd() * 0.42, rnd() < 0.3 ? 'pine' : 'round', false);
    }

    // zemin (çimen)
    ctx.fillStyle = lin(ctx, 0, GY - 6, 0, H, [[0, '#8cf04f'], [0.2, '#5fd13a'], [1, '#2f9a2a']]);
    ctx.fillRect(0, GY, W, H - GY);
    // çimen üst kenarı: kabarık kontur
    ctx.fillStyle = '#7de646'; ctx.strokeStyle = '#237a22'; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.moveTo(0, GY + 12);
    for (let x = 0; x < W; x += 26) { ctx.quadraticCurveTo(x + 13, GY - 12, x + 26, GY + 8); }
    ctx.lineTo(W, GY + 40); ctx.lineTo(0, GY + 40); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(0, GY + 8);
    for (let x = 0; x < W; x += 26) { ctx.quadraticCurveTo(x + 13, GY - 12, x + 26, GY + 8); }
    ctx.stroke();
    // şeritler
    ctx.fillStyle = 'rgba(20,110,30,0.18)';
    for (let i = 0; i < 4; i++) ctx.fillRect(0, GY + 34 + i * 26, W, 12 + i * 2);
    // çimen tutamları + çiçekler
    ctx.strokeStyle = '#2f9a2a'; ctx.lineWidth = 3;
    for (let x = 10; x < W; x += 28 + rnd() * 30) {
      const y = GY + 30 + rnd() * (H - GY - 40);
      ctx.beginPath(); ctx.moveTo(x - 6, y); ctx.lineTo(x - 3, y - 11); ctx.moveTo(x, y); ctx.lineTo(x, y - 14); ctx.moveTo(x + 6, y); ctx.lineTo(x + 3, y - 11); ctx.stroke();
    }
    const petals = ['#ffffff', '#ffd2ec', '#fff3a0', '#ffb36b'];
    for (let x = 40; x < W; x += 70 + rnd() * 90) flower(ctx, x, GY + 36 + rnd() * (H - GY - 52), 0.9 + rnd() * 0.4, petals[Math.floor(rnd() * petals.length)]);
  }

  /* ------------------------------ Güneş, bulut ------------------------------ */
  function paintSun(ctx, S) {
    const c = S / 2;
    const g = ctx.createRadialGradient(c - 10, c - 12, 4, c, c, 52);
    g.addColorStop(0, '#fffbd0'); g.addColorStop(0.6, '#ffe45c'); g.addColorStop(1, '#ffc21a');
    ctx.fillStyle = g; ctx.strokeStyle = '#e8921c'; ctx.lineWidth = 4;
    circle(ctx, c, c, 52); ctx.fill(); ctx.stroke();
    // yüz
    ctx.fillStyle = '#7a3d12';
    circle(ctx, c - 17, c - 6, 5.5); ctx.fill(); circle(ctx, c + 17, c - 6, 5.5); ctx.fill();
    ctx.fillStyle = '#fff'; circle(ctx, c - 15, c - 8, 2); ctx.fill(); circle(ctx, c + 19, c - 8, 2); ctx.fill();
    ctx.strokeStyle = '#7a3d12'; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.arc(c, c + 6, 17, 0.25, Math.PI - 0.25); ctx.stroke();
    ctx.fillStyle = 'rgba(255,120,90,0.45)';
    circle(ctx, c - 32, c + 10, 8); ctx.fill(); circle(ctx, c + 32, c + 10, 8); ctx.fill();
  }
  function paintRays(ctx, S) {
    const c = S / 2;
    for (let i = 0; i < 12; i++) {
      ctx.save(); ctx.translate(c, c); ctx.rotate((i / 12) * Math.PI * 2);
      ctx.fillStyle = i % 2 ? 'rgba(255,236,120,0.55)' : 'rgba(255,224,90,0.4)';
      ctx.beginPath(); ctx.moveTo(-14, -62); ctx.lineTo(0, -(S / 2 - 6) + (i % 2 ? 18 : 0)); ctx.lineTo(14, -62); ctx.closePath(); ctx.fill();
      ctx.restore();
    }
  }
  function paintCloud(ctx, w, h, seed) {
    const rnd = U.rng(seed);
    const blobs = [];
    const n = 5;
    for (let i = 0; i < n; i++) blobs.push([w * (0.18 + 0.64 * (i / (n - 1))), h * (0.62 - 0.18 * Math.sin((i / (n - 1)) * Math.PI)) , h * (0.3 + 0.18 * Math.sin((i / (n - 1)) * Math.PI)) + rnd() * 4]);
    ctx.fillStyle = '#e1f1ff';
    blobs.forEach((b) => { circle(ctx, b[0], b[1] + 5, b[2]); ctx.fill(); });
    ctx.fillStyle = '#ffffff';
    blobs.forEach((b) => { circle(ctx, b[0], b[1], b[2]); ctx.fill(); });
    ctx.fillRect(w * 0.18, h * 0.62, w * 0.64, h * 0.22);
  }

  /* ------------------------------ Adalı platform ------------------------------ */
  const PLAT_PAD = 14;
  /** Platform dokusu: üst yüzey y=0; çarpışan kalın dilim 0..48, altında sarkan kaya. */
  function paintPlatform(ctx, w, seed) {
    const rnd = U.rng(seed);
    const L = -w / 2, Rr = w / 2, T = 48;
    ctx.save(); ctx.translate(w / 2 + PLAT_PAD, PLAT_PAD + 10);
    // sarkan kaya
    ctx.fillStyle = lin(ctx, 0, T - 10, 0, T + 62, [[0, '#a9703a'], [1, '#6e4222']]);
    ctx.strokeStyle = '#3d2210'; ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(L + 10, T - 8);
    const pts = [[L + 6, 18], [-w * 0.34, 28], [-w * 0.24, 44], [-w * 0.13, 54], [-w * 0.05, 72], [w * 0.03, 80], [w * 0.1, 58], [w * 0.22, 50], [w * 0.31, 32], [Rr - 6, 18]];
    pts.forEach((p) => ctx.lineTo(p[0], T + p[1] - 8));
    ctx.lineTo(Rr - 10, T - 8);
    ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.fillStyle = 'rgba(255,214,150,0.22)';
    ctx.beginPath(); ctx.moveTo(-w * 0.3, T + 14); ctx.lineTo(-w * 0.18, T + 30); ctx.lineTo(-w * 0.28, T + 36); ctx.closePath(); ctx.fill();
    // toprak gövde
    ctx.fillStyle = lin(ctx, 0, 6, 0, T, [[0, '#c98a4b'], [1, '#9a602f']]);
    ctx.beginPath();
    const r = 14;
    ctx.moveTo(L + r, 0); ctx.lineTo(Rr - r, 0); ctx.quadraticCurveTo(Rr, 0, Rr, r);
    ctx.lineTo(Rr, T - r); ctx.quadraticCurveTo(Rr, T, Rr - r, T);
    ctx.lineTo(L + r, T); ctx.quadraticCurveTo(L, T, L, T - r);
    ctx.lineTo(L, r); ctx.quadraticCurveTo(L, 0, L + r, 0); ctx.closePath();
    ctx.fill(); ctx.stroke();
    // toprak benekleri
    for (let i = 0; i < w / 24; i++) {
      const x = L + 14 + rnd() * (w - 28), y = 24 + rnd() * 18;
      ctx.fillStyle = rnd() < 0.5 ? 'rgba(255,220,170,0.4)' : 'rgba(80,40,15,0.3)';
      ctx.beginPath(); ctx.ellipse(x, y, 4 + rnd() * 4, 3 + rnd() * 2, rnd() * 3, 0, Math.PI * 2); ctx.fill();
    }
    // çimen başlığı (sarkan damlalı)
    ctx.fillStyle = lin(ctx, 0, -6, 0, 24, [[0, '#a6f15e'], [0.5, '#6dd33a'], [1, '#49b52b']]);
    ctx.strokeStyle = '#237a22'; ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(L + 4, 14); ctx.quadraticCurveTo(L - 2, -2, L + 14, -3);
    ctx.lineTo(Rr - 14, -3); ctx.quadraticCurveTo(Rr + 2, -2, Rr - 4, 14);
    let x = Rr - 4;
    while (x > L + 24) {
      const dr = 10 + rnd() * 8, step = 20 + rnd() * 8;
      ctx.quadraticCurveTo(x - step / 2, 14 + dr + 6, x - step, 14 + (rnd() < 0.5 ? 2 : 6));
      x -= step;
    }
    ctx.lineTo(L + 4, 14);
    ctx.closePath(); ctx.fill(); ctx.stroke();
    // üst parlama
    ctx.strokeStyle = 'rgba(255,255,255,0.5)'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(L + 18, 3); ctx.lineTo(Rr - 18, 3); ctx.stroke();
    // çimen tutamları (y=0 üstünde 7 px'e kadar)
    ctx.fillStyle = '#5dc12f'; ctx.strokeStyle = '#237a22'; ctx.lineWidth = 2.5;
    for (let tx = L + 16; tx < Rr - 12; tx += 14 + rnd() * 12) {
      ctx.beginPath(); ctx.moveTo(tx - 5, -2); ctx.lineTo(tx - 2, -8); ctx.lineTo(tx + 1, -3); ctx.lineTo(tx + 4, -8); ctx.lineTo(tx + 6, -2); ctx.closePath(); ctx.fill(); ctx.stroke();
    }
    // küçük çiçekler (kenarlarda)
    const pet = ['#fff', '#ffd2ec', '#fff3a0'];
    [[L + 14, 0.8], [Rr - 14, 0.8]].forEach((f, i) => flower(ctx, f[0], -1, f[1], pet[i % 3]));
    // sarkan sarmaşık
    ctx.strokeStyle = '#2f9a2a'; ctx.lineWidth = 3;
    [[L + 30, 30], [Rr - 40, 24]].forEach((v) => {
      ctx.beginPath(); ctx.moveTo(v[0], 20); ctx.quadraticCurveTo(v[0] + 6, 30 + v[1] / 2, v[0] - 2, T + v[1]); ctx.stroke();
      ctx.fillStyle = '#4ccf3f'; ctx.beginPath(); ctx.ellipse(v[0] - 4, T + v[1] - 2, 5, 3, -0.6, 0, Math.PI * 2); ctx.fill();
    });
    ctx.restore();
  }

  /* ------------------------------ Sapan ------------------------------ */
  /** rel: ağaç kökünün (0,0) olduğu koordinatta çatal uçları ve çatal dibi. */
  function paintSling(ctx, w, h, rel) {
    ctx.save(); ctx.translate(w / 2, h - 6);
    // zemin tümseği
    ctx.fillStyle = '#7a4f2a'; ctx.strokeStyle = '#3d2210'; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.ellipse(0, 0, 40, 12, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#6dd33a'; ctx.strokeStyle = '#237a22';
    ctx.beginPath(); ctx.ellipse(0, -3, 34, 8, 0, Math.PI, Math.PI * 2); ctx.fill();
    const wood = (p, wdt) => {
      ctx.lineWidth = wdt + 8; ctx.strokeStyle = '#4a2a12'; p(); ctx.stroke();
      ctx.lineWidth = wdt; ctx.strokeStyle = '#b97a3a'; p(); ctx.stroke();
      ctx.lineWidth = wdt * 0.32; ctx.strokeStyle = '#e0a15e'; ctx.save(); ctx.translate(-wdt * 0.2, 0); p(); ctx.stroke(); ctx.restore();
    };
    const cy = rel.crotchY;
    wood(() => { ctx.beginPath(); ctx.moveTo(0, -4); ctx.lineTo(0, cy); }, 24);
    wood(() => { ctx.beginPath(); ctx.moveTo(0, cy + 2); ctx.quadraticCurveTo(rel.back.x * 0.2, cy - 20, rel.back.x, rel.back.y); }, 17);
    wood(() => { ctx.beginPath(); ctx.moveTo(0, cy + 2); ctx.quadraticCurveTo(rel.front.x * 0.2, cy - 20, rel.front.x, rel.front.y); }, 17);
    // çatal dibi sargısı
    ctx.fillStyle = '#c0392b'; ctx.strokeStyle = '#6e1a12'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.roundRect ? ctx.roundRect(-17, cy + 6, 34, 16, 6) : ctx.rect(-17, cy + 6, 34, 16); ctx.fill(); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(-12, cy + 11); ctx.lineTo(12, cy + 11); ctx.stroke();
    // budak
    ctx.fillStyle = '#7a4a22'; circle(ctx, 3, cy + 54, 4); ctx.fill();
    ctx.restore();
  }

  /* ------------------------------ Üretim ------------------------------ */
  const platKeys = {};
  const Tex = {
    PLAT_PAD,

    /** Yeni bir Phaser.Game oluşturulunca (yeniden boyutlandırma) eski dokulara bakan önbellekleri sıfırla. */
    resetCaches() {
      Object.keys(platKeys).forEach((k) => delete platKeys[k]);
      SV.BottleArt.purge();
    },

    /** Çözünürlük (R) ya da ekran genişliği değişince tüm üretilmiş dokuları sil. */
    purge(scene) {
      const re = /^(bg_|plat_|glassB_|glassF_|ball_|icon_|star_|mark_|ui_|spark$|shard$|drop$|confetti$|ring$|glow$|dot$|sun$|sunrays$|cloud\d|shadow$|sling$)/;
      scene.textures.getTextureKeys().filter((k) => re.test(k)).forEach((k) => scene.textures.remove(k));
      Object.keys(platKeys).forEach((k) => delete platKeys[k]);
      SV.BottleArt.purge();
    },

    background(scene, W, H) {
      const key = 'bg_' + W;
      if (scene.textures.exists(key)) return key;
      const c = mk(W, H);
      paintBackground(c.ctx, W, H, SV.Levels.GROUND_Y);
      put(scene, key, c);
      return key;
    },

    common(scene) {
      if (scene.textures.exists('sun')) return;
      let c = mk(124, 124); paintSun(c.ctx, 124); put(scene, 'sun', c);
      c = mk(260, 260); paintRays(c.ctx, 260); put(scene, 'sunrays', c);
      [[190, 84, 11], [150, 66, 23], [230, 96, 37]].forEach((d, i) => {
        c = mk(d[0], d[1]); paintCloud(c.ctx, d[0], d[1], d[2]); put(scene, 'cloud' + i, c);
      });
      // zemin gölgesi (yumuşak elips)
      c = mk(256, 48);
      const g = c.ctx.createRadialGradient(128, 24, 4, 128, 24, 124);
      g.addColorStop(0, 'rgba(20,70,20,0.38)'); g.addColorStop(1, 'rgba(20,70,20,0)');
      c.ctx.save(); c.ctx.translate(128, 24); c.ctx.scale(1, 0.19); c.ctx.translate(-128, -128);
      c.ctx.fillStyle = g; c.ctx.fillRect(0, 0, 256, 256); c.ctx.restore();
      put(scene, 'shadow', c);
      // sapan
      const S = SV.Levels.SLING, GY = SV.Levels.GROUND_Y;
      const baseY = GY + 8;
      const rel = {
        back: { x: -30, y: S.y - 20 - baseY },
        front: { x: 30, y: S.y - 16 - baseY },
        crotchY: S.y + 40 - baseY
      };
      const w = 110, h = Math.ceil(baseY - (S.y - 40));
      c = mk(w, h); paintSling(c.ctx, w, h, rel); put(scene, 'sling', c);
      SV.G.sling = { w, h, baseY, tipBack: { x: S.x + rel.back.x, y: S.y - 20 }, tipFront: { x: S.x + rel.front.x, y: S.y - 16 } };
    },

    /** Verilen genişlikte (px) platform dokusu; {key, w, h, topOffset} döner. */
    platform(scene, w) {
      const ww = Math.round(w / 4) * 4;
      const key = 'plat_' + ww;
      if (!platKeys[key] || !scene.textures.exists(key)) {
        const cw = ww + PLAT_PAD * 2, ch = 48 + 96 + PLAT_PAD * 2 + 10;
        const c = mk(cw, ch);
        paintPlatform(c.ctx, ww, ww * 7 + 3);
        put(scene, key, c);
        platKeys[key] = { key, w: cw, h: ch, ox: cw / 2, oy: PLAT_PAD + 10 };
      }
      return platKeys[key];
    }
  };

  SV.Tex = SV.Tex || {};
  Object.assign(SV.Tex, Tex);
  SV.TexUtil = { mk, put, lin, circle };
})(typeof window !== 'undefined' ? window : globalThis);
