/* Küçük yardımcılar: matematik, tohumlu rastgele sayı, renk, olay yayıcı. */
(function (root) {
  'use strict';
  const SV = (root.SV = root.SV || {});

  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const lerp = (a, b, t) => a + (b - a) * t;

  /** Tohumlu rastgele sayı üreteci (mulberry32): aynı tohum -> aynı bölüm. */
  function rng(seed) {
    let a = seed >>> 0;
    return function () {
      a = (a + 0x6d2b79f5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function shuffle(arr, rnd) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(rnd() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  function hexToRgb(hex) {
    const h = hex.replace('#', '');
    const n = parseInt(h.length === 3 ? h.replace(/(.)/g, '$1$1') : h, 16);
    return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
  }
  function rgba(hex, a) {
    const c = hexToRgb(hex);
    return 'rgba(' + c.r + ',' + c.g + ',' + c.b + ',' + a + ')';
  }
  /** İki hex rengi karıştırır (t=0 -> h1, t=1 -> h2). */
  function mix(h1, h2, t) {
    const a = hexToRgb(h1), b = hexToRgb(h2);
    const f = (x, y) => Math.round(lerp(x, y, t));
    return 'rgb(' + f(a.r, b.r) + ',' + f(a.g, b.g) + ',' + f(a.b, b.b) + ')';
  }

  const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);
  const easeOutBack = (t) => {
    const c1 = 1.70158, c3 = c1 + 1;
    return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
  };

  class Emitter {
    constructor() { this._l = {}; }
    on(ev, fn) { (this._l[ev] = this._l[ev] || []).push(fn); return () => this.off(ev, fn); }
    off(ev, fn) { this._l[ev] = (this._l[ev] || []).filter((f) => f !== fn); }
    emit(ev, ...args) { (this._l[ev] || []).slice().forEach((f) => f(...args)); }
  }

  SV.U = { clamp, lerp, rng, shuffle, hexToRgb, rgba, mix, easeOutCubic, easeOutBack };
  SV.Emitter = Emitter;
})(typeof window !== 'undefined' ? window : globalThis);
