/*
 * Ses: tüm sesler Web Audio ile kodla üretilir (dosya gerekmez).
 * Tarayıcılar sesi ilk dokunuştan sonra açtığı için unlock() ilk
 * kullanıcı hareketinde çağrılır.
 */
(function (root) {
  'use strict';
  const SV = (root.SV = root.SV || {});

  const A = {
    ctx: null,
    master: null,
    noise: null,
    muted: false,

    init() { this.muted = SV.Storage.get('muted', false) === true; },

    unlock() {
      if (!this.ctx) {
        const AC = root.AudioContext || root.webkitAudioContext;
        if (!AC) return;
        this.ctx = new AC();
        this.master = this.ctx.createGain();
        this.master.gain.value = this.muted ? 0 : 0.8;
        this.master.connect(this.ctx.destination);
        // 1 saniyelik beyaz gürültü (kırılma / fırlatma sesleri için)
        const len = this.ctx.sampleRate;
        this.noise = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
        const d = this.noise.getChannelData(0);
        for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      }
      if (this.ctx.state === 'suspended') this.ctx.resume();
    },

    setMuted(m) {
      this.muted = !!m;
      SV.Storage.set('muted', this.muted);
      if (this.master) this.master.gain.setTargetAtTime(this.muted ? 0 : 0.8, this.ctx.currentTime, 0.01);
    },
    toggle() { this.setMuted(!this.muted); return this.muted; },

    /** Tek bir ton: freq -> to frekansına kayar, zarf ile söner. */
    tone(o) {
      const c = this.ctx, t0 = c.currentTime + (o.delay || 0);
      const osc = c.createOscillator(), g = c.createGain();
      osc.type = o.type || 'sine';
      osc.frequency.setValueAtTime(o.freq, t0);
      if (o.to) osc.frequency.exponentialRampToValueAtTime(o.to, t0 + o.dur);
      const peak = o.gain == null ? 0.25 : o.gain;
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(peak, t0 + (o.attack || 0.008));
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + o.dur);
      osc.connect(g); g.connect(this.master);
      osc.start(t0); osc.stop(t0 + o.dur + 0.05);
    },

    /** Filtrelenmiş gürültü patlaması. */
    burst(o) {
      const c = this.ctx, t0 = c.currentTime + (o.delay || 0);
      const src = c.createBufferSource(); src.buffer = this.noise;
      const f = c.createBiquadFilter(); f.type = o.filter || 'bandpass';
      f.frequency.setValueAtTime(o.freq || 2000, t0);
      if (o.to) f.frequency.exponentialRampToValueAtTime(o.to, t0 + o.dur);
      f.Q.value = o.q || 0.8;
      const g = c.createGain();
      g.gain.setValueAtTime(o.gain == null ? 0.3 : o.gain, t0);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + o.dur);
      src.connect(f); f.connect(g); g.connect(this.master);
      src.start(t0, Math.random() * 0.5); src.stop(t0 + o.dur + 0.05);
    },

    play(name, arg) {
      if (!this.ctx || this.muted) return;
      const fn = SOUNDS[name];
      if (fn) fn(this, arg || {});
    }
  };

  const NOTE = (n) => 440 * Math.pow(2, (n - 69) / 12); // MIDI -> Hz

  const SOUNDS = {
    click(a) { a.tone({ freq: 620, to: 900, dur: 0.07, type: 'square', gain: 0.08 }); },
    stretch(a) { a.tone({ freq: 180, to: 240, dur: 0.05, type: 'triangle', gain: 0.05 }); },
    launch(a) {
      a.tone({ freq: 520, to: 140, dur: 0.22, type: 'triangle', gain: 0.22 });
      a.burst({ freq: 3000, to: 600, dur: 0.18, gain: 0.12 });
    },
    // Cam "tıngg": uyumsuz üst sesler cam hissi verir. speed ile ton/şiddet değişir.
    glass(a, o) {
      const s = Math.min(1, (o.speed || 600) / 1200);
      const base = 1400 + Math.random() * 500;
      a.tone({ freq: base, dur: 0.45, gain: 0.07 + 0.12 * s });
      a.tone({ freq: base * 2.76, dur: 0.3, gain: 0.04 + 0.06 * s });
      a.tone({ freq: base * 5.4, dur: 0.18, gain: 0.025 + 0.03 * s });
      a.burst({ freq: 5000, dur: 0.05, gain: 0.08 * s });
    },
    shatter(a) {
      a.burst({ filter: 'highpass', freq: 2500, dur: 0.5, gain: 0.35 });
      for (let i = 0; i < 6; i++) {
        a.tone({ freq: 1800 + Math.random() * 3200, dur: 0.12 + Math.random() * 0.2, gain: 0.05, delay: Math.random() * 0.18 });
      }
    },
    wrong(a) {
      a.tone({ freq: 240, to: 90, dur: 0.38, type: 'sawtooth', gain: 0.16 });
      a.tone({ freq: 180, to: 70, dur: 0.38, type: 'square', gain: 0.07, delay: 0.02 });
    },
    miss(a) { a.tone({ freq: 300, to: 150, dur: 0.3, type: 'triangle', gain: 0.14 }); },
    thud(a, o) {
      const s = Math.min(1, (o.speed || 400) / 900);
      a.tone({ freq: 120, to: 60, dur: 0.12, type: 'sine', gain: 0.18 * s });
    },
    success(a, o) {
      const up = Math.min(o.streak || 0, 5) * 2; // seri arttıkça ton yükselir
      [72, 76, 79, 84].forEach((n, i) =>
        a.tone({ freq: NOTE(n + up), dur: 0.22, type: 'triangle', gain: 0.16, delay: i * 0.07 }));
    },
    coin(a) {
      a.tone({ freq: NOTE(88), dur: 0.1, type: 'square', gain: 0.08 });
      a.tone({ freq: NOTE(95), dur: 0.3, type: 'square', gain: 0.08, delay: 0.09 });
    },
    win(a) {
      [72, 76, 79, 84, 79, 84, 88].forEach((n, i) =>
        a.tone({ freq: NOTE(n), dur: i === 6 ? 0.7 : 0.18, type: 'triangle', gain: 0.18, delay: i * 0.12 }));
    },
    lose(a) {
      [67, 64, 60, 55].forEach((n, i) =>
        a.tone({ freq: NOTE(n), dur: 0.25, type: 'triangle', gain: 0.16, delay: i * 0.14 }));
    },
    reward(a) {
      [76, 79, 83, 88].forEach((n, i) =>
        a.tone({ freq: NOTE(n), dur: 0.14, type: 'square', gain: 0.09, delay: i * 0.08 }));
    },
    pop(a) { a.tone({ freq: 300, to: 700, dur: 0.1, type: 'sine', gain: 0.14 }); }
  };

  SV.Audio = A;
})(typeof window !== 'undefined' ? window : globalThis);
