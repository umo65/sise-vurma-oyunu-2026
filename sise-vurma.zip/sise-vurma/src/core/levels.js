/*
 * BÖLÜM TANIMLARI (saf mantık)
 * Levels.build(n, W) belirli bir ekran genişliği (W, mantıksal piksel) için
 * platformları, şişeleri ve hedef sırasını üretir. Aynı n her zaman aynı
 * düzeni verir (tohumlu rastgele).
 *
 *  1. Bölüm : tek sıra, 6 şişe, sabit platform (kolay)
 *  2-3      : basamaklı / üç ayrı ada
 *  4-6      : yatay hareketli, dikey hareketli, karışık hareketli platformlar
 *  7+       : şablonlar döngüyle tekrar eder; hız artar, şişeler sıklaşır,
 *             nişan yardımı (nokta sayısı) azalır.
 */
(function (root) {
  'use strict';
  const SV = (root.SV = root.SV || {});
  const U = SV.U;

  const H = 720;
  const GROUND_Y = 622;          // çimen çizgisi
  const SLING = { x: 200, y: 470 }; // topun sapanda durduğu nokta
  const PLATFORM_H = 48;         // çarpışan platform kalınlığı

  const COLORS = [
    { id: 'red',    name: 'KIRMIZI', hex: '#ff3b3b', light: '#ff9a8f', dark: '#c3141f' },
    { id: 'blue',   name: 'MAVİ',    hex: '#2f7bff', light: '#8dbbff', dark: '#1646b8' },
    { id: 'green',  name: 'YEŞİL',   hex: '#2fcf4a', light: '#9bf0a6', dark: '#128a2a' },
    { id: 'yellow', name: 'SARI',    hex: '#ffd21f', light: '#fff08a', dark: '#d19a00' },
    { id: 'purple', name: 'MOR',     hex: '#9b4dff', light: '#cfa6ff', dark: '#5f1fc2' },
    { id: 'orange', name: 'TURUNCU', hex: '#ff8a1f', light: '#ffc27a', dark: '#c75a00' },
    { id: 'pink',   name: 'PEMBE',   hex: '#ff5fb0', light: '#ffb0d8', dark: '#c4237a' },
    { id: 'cyan',   name: 'TURKUAZ', hex: '#12cfd6', light: '#8ff0f2', dark: '#078a92' }
  ];
  const BY_ID = {};
  COLORS.forEach((c) => (BY_ID[c.id] = c));

  // Şablonlar: u0/u1 = platformun bölgedeki başlangıç/bitiş oranı, y = üst yüzey,
  // n = şişe sayısı, move = hareket {ax, ay: genlik px, period: sn, phase: rad}
  const TEMPLATES = {
    row:    [{ u0: 0, u1: 1, y: 450, n: 6 }],
    steps:  [{ u0: 0, u1: 0.47, y: 490, n: 3 }, { u0: 0.53, u1: 1, y: 390, n: 3 }],
    islands: [
      { u0: 0, u1: 0.31, y: 480, n: 2 },
      { u0: 0.345, u1: 0.655, y: 390, n: 2 },
      { u0: 0.69, u1: 1, y: 460, n: 2 }
    ],
    sway:   [{ u0: 0.05, u1: 0.95, y: 450, n: 6, move: { ax: 55, ay: 0, period: 4.4, phase: 0 } }],
    lift: [
      { u0: 0, u1: 0.47, y: 450, n: 3, move: { ax: 0, ay: 42, period: 3.6, phase: 0 } },
      { u0: 0.53, u1: 1, y: 450, n: 3, move: { ax: 0, ay: 42, period: 3.6, phase: Math.PI } }
    ],
    mixed: [
      { u0: 0, u1: 0.31, y: 490, n: 2 },
      { u0: 0.345, u1: 0.655, y: 420, n: 2, move: { ax: 0, ay: 46, period: 3.8, phase: 0 } },
      { u0: 0.69, u1: 1, y: 460, n: 2, move: { ax: 38, ay: 0, period: 3.2, phase: 1.2 } }
    ],
    stairs: [
      { u0: 0, u1: 0.31, y: 520, n: 2 },
      { u0: 0.345, u1: 0.655, y: 440, n: 2 },
      { u0: 0.69, u1: 1, y: 380, n: 2 }
    ]
  };
  const CYCLE = ['steps', 'islands', 'mixed', 'sway', 'lift', 'stairs'];

  function templateFor(n) {
    if (n === 1) return { key: 'row', speed: 1 };
    if (n === 2) return { key: 'steps', speed: 1 };
    if (n === 3) return { key: 'islands', speed: 1 };
    if (n === 4) return { key: 'sway', speed: 1 };
    if (n === 5) return { key: 'lift', speed: 1 };
    if (n === 6) return { key: 'mixed', speed: 1 };
    const i = n - 7;
    return { key: CYCLE[i % CYCLE.length], speed: 1 + 0.07 * Math.floor(i / CYCLE.length) + 0.03 * (i % CYCLE.length) };
  }

  function shapePool(n) {
    if (n <= 1) return ['classic'];
    if (n === 2) return ['classic', 'round'];
    if (n <= 4) return ['classic', 'round', 'tall'];
    return ['classic', 'round', 'tall', 'jar'];
  }

  /** Nişan yardımı: gösterilecek yörünge noktası sayısı. */
  function guidePoints(n) {
    if (n <= 2) return 30;
    if (n <= 4) return 20;
    if (n <= 6) return 14;
    return Math.max(7, 12 - Math.floor((n - 7) / 3));
  }

  function build(n, W) {
    const rnd = U.rng(n * 7919 + 13);
    const tpl = templateFor(n);
    const region = { x0: W < 1100 ? 300 : 360, x1: Math.min(W - 70, 1290) };
    const RW = region.x1 - region.x0;
    const pool = shapePool(n);

    // Renkler: 1. bölümde sabit 6 renk; sonrakilerde 8 renkten 6'sı
    let colorIds;
    if (n === 1) colorIds = ['red', 'blue', 'green', 'yellow', 'purple', 'orange'];
    else colorIds = U.shuffle(COLORS.map((c) => c.id), rnd).slice(0, 6);

    const plats = [];
    const bottles = [];
    let ci = 0;

    TEMPLATES[tpl.key].forEach((def, pi) => {
      let x0 = region.x0 + def.u0 * RW;
      let x1 = region.x0 + def.u1 * RW;
      // Çok geniş platformları (ör. 1. bölüm) şişe sayısına göre sınırla
      const maxW = def.n * 128 + 70;
      if (x1 - x0 > maxW) {
        const mid = (x0 + x1) / 2;
        x0 = mid - maxW / 2; x1 = mid + maxW / 2;
      }
      const w = x1 - x0;
      const cx = (x0 + x1) / 2;
      const pad = 26;
      const slot = (w - pad * 2) / def.n;

      const list = [];
      let maxH = 0;
      for (let i = 0; i < def.n; i++) {
        const shape = pool[Math.floor(rnd() * pool.length)];
        const bodyW = SV.Shapes.width(shape, 1);
        // Komşu şişeler arasında en az 14 px boşluk kalacak şekilde ölçekle
        const s = U.clamp((slot - 14) / bodyW, 0.5, 1);
        maxH = Math.max(maxH, SV.Shapes.height(shape, s));
        list.push({
          platIndex: pi,
          ox: -w / 2 + pad + slot * (i + 0.5),
          colorId: colorIds[ci++],
          shape,
          scale: s,
          fill: 0.56 + rnd() * 0.1
        });
      }

      // Şişelerin üstü arayüzün (HUD) altında kalsın
      const amp = def.move ? def.move.ay || 0 : 0;
      const minTop = 215 + amp;
      const top = Math.max(def.y, minTop + maxH);

      const move = def.move
        ? { ax: def.move.ax || 0, ay: def.move.ay || 0, period: def.move.period / tpl.speed, phase: def.move.phase || 0 }
        : null;
      plats.push({ cx, top, w, h: PLATFORM_H, move });
      list.forEach((b) => bottles.push(b));
    });

    // Hedef sırası: renklerin karışık sırası
    const order = U.shuffle(colorIds, rnd);

    return { n, template: tpl.key, plats, bottles, order, guide: guidePoints(n), W, H };
  }

  /** Platformun t anındaki konumu ve hızı (hareketsizse sabit). */
  function platformPose(p, t) {
    if (!p.move) return { x: p.cx, y: p.top, vx: 0, vy: 0 };
    const m = p.move, w = (Math.PI * 2) / m.period;
    return {
      x: p.cx + m.ax * Math.sin(w * t + m.phase),
      y: p.top + m.ay * Math.sin(w * t + m.phase),
      vx: m.ax * w * Math.cos(w * t + m.phase),
      vy: m.ay * w * Math.cos(w * t + m.phase)
    };
  }

  SV.Levels = { H, GROUND_Y, SLING, PLATFORM_H, COLORS, BY_ID, build, platformPose, templateFor };
})(typeof window !== 'undefined' ? window : globalThis);
