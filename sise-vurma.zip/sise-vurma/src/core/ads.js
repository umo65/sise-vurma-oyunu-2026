/*
 * ÖDÜLLÜ REKLAM SİSTEMİ
 *
 * AdManager, sağlayıcıdan (provider) bağımsız çalışır:
 *   - MockProvider  : geliştirme için sahte test reklamı (tarayıcıda varsayılan)
 *   - AdMobProvider : Capacitor + @capacitor-community/admob ile gerçek AdMob
 *                     ödüllü reklamı (yerel Android uygulaması içinde)
 *
 * Kurallar (oyun tarafı bunlara güvenir):
 *   - showRewarded() YALNIZCA kullanıcı butona bastığında çağrılır.
 *   - Dönüş durumları: 'rewarded' | 'dismissed' | 'failed' | 'busy'
 *   - 'rewarded' sadece reklam sonuna kadar izlenirse döner.
 *   - Reklam kimlikleri kodda değil, config/ads.config.js içindedir.
 *
 * NOT: AdMob doğrudan tarayıcıdan (düz web sayfasından) reklam sunamaz;
 * gerçek reklam için oyunu Capacitor ile Android uygulamasına sarmak gerekir
 * (README'ye bak).
 */
(function (root) {
  'use strict';
  const SV = (root.SV = root.SV || {});

  const MSG_LOAD = 'Reklam yüklenemedi. Bağlantını kontrol edip tekrar dene.';
  const MSG_SHOW = 'Reklam gösterilemedi. Lütfen tekrar dene.';

  class AdError extends Error {
    constructor(message, userMessage) { super(message); this.userMessage = userMessage || null; }
  }

  /* ------------------------------ Sahte sağlayıcı ------------------------------ */
  class MockProvider {
    /** presenter.showMockAd({durationMs, autoCloseAfterMs}) -> Promise<'completed'|'closed'> */
    constructor(options, presenter) {
      this.name = 'mock';
      this.options = options;
      this.presenter = presenter;
    }
    load() {
      const o = this.options;
      return new Promise((resolve, reject) => {
        setTimeout(() => {
          if (o.forceResult === 'loadfail') reject(new AdError('mock load fail'));
          else resolve();
        }, o.loadDelayMs);
      });
    }
    async show() {
      const o = this.options;
      if (o.forceResult === 'showfail') throw new AdError('mock show fail');
      const result = await this.presenter.showMockAd({
        durationMs: o.durationMs,
        autoCloseAfterMs: o.forceResult === 'early' ? Math.max(120, o.durationMs / 3) : 0
      });
      return { rewarded: result === 'completed' };
    }
  }

  /* ------------------------------ AdMob sağlayıcısı ------------------------------ */

  /**
   * Yerel köprüyü (Capacitor.nativePromise / nativeCallback) eklenti gibi kullanılabilir hâle getirir.
   * Neden gerekli: Bu proje bundler kullanmıyor. Capacitor'da `Capacitor.Plugins.AdMob` yalnızca
   * eklentinin JS paketi içe aktarılıp registerPlugin() çağrılırsa oluşur; düz sayfada oluşmaz.
   * Yerel köprü ise (native-bridge.js) WebView'e her zaman enjekte edilir.
   */
  function bridgeProxy(C, name) {
    const call = (method) => (opts) => C.nativePromise(name, method, opts || {});
    return {
      initialize: call('initialize'),
      prepareRewardVideoAd: call('prepareRewardVideoAd'),
      showRewardVideoAd: call('showRewardVideoAd'),
      addListener(eventName, cb) {
        const callbackId = C.nativeCallback(name, 'addListener', { eventName }, cb);
        return Promise.resolve({
          remove: () => C.nativePromise(name, 'removeListener', { eventName, callbackId })
        });
      }
    };
  }

  let _bridged = null;
  /**
   * Yerel AdMob eklentisini bulur; yoksa null. Sırayla dener:
   *  1) Capacitor.Plugins.AdMob            (paketlenmiş uygulama / eklenti içe aktarılmışsa)
   *  2) Capacitor.registerPlugin('AdMob')  (Capacitor çekirdek çalışma zamanı sayfadaysa)
   *  3) ham yerel köprü                    (bundler'sız düz sayfa — bu proje)
   */
  function getNativeAdMob() {
    const C = root.Capacitor;
    if (!C) return null;
    const native = typeof C.isNativePlatform !== 'function' ? true : C.isNativePlatform();
    if (!native) return null;
    if (C.Plugins && C.Plugins.AdMob) return C.Plugins.AdMob;
    const hasHeader = Array.isArray(C.PluginHeaders) && C.PluginHeaders.some((h) => h && h.name === 'AdMob');
    if (!hasHeader) return null; // yerel tarafta eklenti kurulu değil
    if (_bridged && _bridged.C === C) return _bridged.plugin;
    let plugin = null;
    if (typeof C.registerPlugin === 'function') plugin = C.registerPlugin('AdMob');
    else if (typeof C.nativePromise === 'function' && typeof C.nativeCallback === 'function') plugin = bridgeProxy(C, 'AdMob');
    _bridged = plugin ? { C, plugin } : null;
    return plugin;
  }

  class AdMobProvider {
    constructor(config) {
      this.name = 'admob';
      this.config = config;
      this.initialized = false;
    }
    static available() { return !!getNativeAdMob(); }
    get plugin() { return getNativeAdMob(); }
    _platform() {
      const C = root.Capacitor;
      return (C && typeof C.getPlatform === 'function' && C.getPlatform()) || 'android';
    }
    _unitId() {
      const a = this.config.admob;
      const map = a.useTestAds ? a.testRewardedAdUnitId : a.rewardedAdUnitId;
      return (map && map[this._platform()]) || '';
    }
    async load() {
      const id = this._unitId();
      if (!id) {
        throw new AdError('missing ad unit id',
          'AdMob reklam birimi kimliği yapılandırılmamış (config/ads.config.js).');
      }
      const testing = !!this.config.admob.useTestAds;
      if (!this.initialized) {
        await this.plugin.initialize({ initializeForTesting: testing });
        this.initialized = true;
      }
      await this.plugin.prepareRewardVideoAd({ adId: id, isTesting: testing });
    }
    /** Ödül olayı gelmeden reklam kapatılırsa rewarded:false döner. */
    async show() {
      const P = this.plugin;
      const handles = [];
      let rewarded = false;
      return new Promise((resolve, reject) => {
        let done = false;
        const finish = (fn, value) => {
          if (done) return;
          done = true;
          handles.forEach((h) => { try { h && h.remove && h.remove(); } catch (e) { /* yoksay */ } });
          fn(value);
        };
        Promise.all([
          P.addListener('onRewardedVideoAdReward', () => { rewarded = true; }),
          P.addListener('onRewardedVideoAdDismissed', () => finish(resolve, { rewarded })),
          P.addListener('onRewardedVideoAdFailedToShow', () => finish(reject, new AdError('failed to show')))
        ]).then((hs) => {
          hs.forEach((h) => handles.push(h));
          return P.showRewardVideoAd();
        }).catch((e) => finish(reject, e));
      });
    }
  }

  /* ------------------------------ Yönetici ------------------------------ */
  class AdManager {
    constructor(config, presenter) {
      this.config = config;
      this.presenter = presenter;
      this.busy = false;
      this.loaded = false;
      this._loading = null;
      this.provider = this._pickProvider();
    }

    _query() {
      if (!this.config.allowQueryOverrides || !root.location) return {};
      try {
        const q = new URLSearchParams(root.location.search);
        return { ad: q.get('ad'), adms: q.get('adms') };
      } catch (e) { return {}; }
    }

    _pickProvider() {
      const cfg = this.config;
      const q = this._query();
      const mockOpts = Object.assign({}, cfg.mock);
      if (q.ad) mockOpts.forceResult = q.ad;
      if (q.adms) { mockOpts.durationMs = +q.adms; mockOpts.loadDelayMs = Math.min(mockOpts.loadDelayMs, +q.adms); }
      const wantAdmob = cfg.provider === 'admob' || (cfg.provider === 'auto' && AdMobProvider.available());
      if (wantAdmob) return new AdMobProvider(cfg);
      return new MockProvider(mockOpts, this.presenter);
    }

    get providerName() { return this.provider.name; }

    /** Reklamı arka planda hazırlar (GÖSTERMEZ). */
    preload() {
      if (this.loaded) return Promise.resolve({ ok: true });
      if (this._loading) return this._loading;
      this._loading = Promise.resolve()
        .then(() => {
          if (this.provider instanceof AdMobProvider && !AdMobProvider.available()) {
            throw new AdError('admob plugin missing', 'AdMob eklentisi bulunamadı (yerel Android uygulaması gerekir).');
          }
          return this.provider.load();
        })
        .then(() => { this.loaded = true; return { ok: true }; })
        .catch((e) => ({ ok: false, error: (e && e.userMessage) || MSG_LOAD }))
        .then((r) => { this._loading = null; return r; });
      return this._loading;
    }

    /**
     * Ödüllü reklamı gösterir. Yalnızca kullanıcı butona bastığında çağır.
     * @returns {Promise<{status:'rewarded'|'dismissed'|'failed'|'busy', error?:string, stage?:string}>}
     */
    async showRewarded() {
      if (this.busy) return { status: 'busy' };
      this.busy = true;
      try {
        if (!this.loaded) {
          const r = await this.preload();
          if (!r.ok) return { status: 'failed', error: r.error, stage: 'load' };
        }
        this.loaded = false; // her reklam bir kez gösterilebilir
        let res;
        try {
          res = await this.provider.show();
        } catch (e) {
          this.preload();
          return { status: 'failed', error: (e && e.userMessage) || MSG_SHOW, stage: 'show' };
        }
        this.preload(); // sonraki reklamı hazırla
        return { status: res && res.rewarded ? 'rewarded' : 'dismissed' };
      } finally {
        this.busy = false;
      }
    }
  }

  SV.Ads = { AdManager, MockProvider, AdMobProvider, AdError, getNativeAdMob, bridgeProxy };
})(typeof window !== 'undefined' ? window : globalThis);
