/*
 * ŞİŞE ŞEKİLLERİ (saf veri + geometri)
 * Yerel koordinat: orijin = şişe tabanının orta noktası, y yukarı doğru EKSİ.
 * Hem çizim (bottle.js) hem çarpışma (physics.js) buradaki ölçüleri kullanır.
 */
(function (root) {
  'use strict';
  const SV = (root.SV = root.SV || {});

  // bw: gövde yarı genişliği, bh: gövde yüksekliği, r: köşe yarıçapı,
  // nw: boyun yarı genişliği, nh: boyun yüksekliği, sh: omuz yüksekliği,
  // lw: ağız (dudak) yarı genişliği, lh: dudak yüksekliği
  // Ölçüler 1.15 ile çarpılır: şişeler telefonda parmakla vurulabilecek kadar büyük olsun.
  const BASE = {
    classic: { bw: 42, bh: 92, r: 30, nw: 15, nh: 40, sh: 18, lw: 20, lh: 8 },
    round:   { bw: 46, bh: 92, r: 46, nw: 14, nh: 44, sh: 14, lw: 19, lh: 8 },
    tall:    { bw: 32, bh: 112, r: 20, nw: 13, nh: 30, sh: 20, lw: 18, lh: 8 },
    jar:     { bw: 48, bh: 90, r: 22, nw: 24, nh: 26, sh: 12, lw: 29, lh: 8 }
  };
  const SIZE = 1.15;
  const DEFS = {};
  Object.keys(BASE).forEach((k) => {
    DEFS[k] = {};
    Object.keys(BASE[k]).forEach((f) => { DEFS[k][f] = BASE[k][f] * SIZE; });
  });

  function height(p) { return p.bh + p.sh + p.nh + p.lh; }

  /** Ölçeklenmiş çarpışma dikdörtgenleri (yerel koordinat). */
  function colliders(name, s) {
    const p = DEFS[name];
    const yTop = -(p.bh + p.sh + p.nh + p.lh);
    const list = [];
    // Gövde (yuvarlak köşeli dikdörtgen)
    list.push({ cx: 0, cy: -p.bh / 2, hw: p.bw, hh: p.bh / 2, rad: Math.min(p.r, p.bw, p.bh / 2) });
    // Omuz (gövdeden boyuna geçiş)
    const shTop = -(p.bh + p.sh * 0.85), shBot = -(p.bh - 10);
    list.push({ cx: 0, cy: (shTop + shBot) / 2, hw: p.nw + (p.bw - p.nw) * 0.55, hh: (shBot - shTop) / 2, rad: 8 });
    // Boyun
    const nTop = yTop + p.lh, nBot = -(p.bh - 4);
    list.push({ cx: 0, cy: (nTop + nBot) / 2, hw: p.nw + 1, hh: (nBot - nTop) / 2, rad: 3 });
    // Dudak
    list.push({ cx: 0, cy: yTop + p.lh / 2, hw: p.lw, hh: p.lh / 2, rad: 3 });
    return list.map((c) => ({
      cx: c.cx * s, cy: c.cy * s, hw: c.hw * s, hh: c.hh * s, rad: Math.min(c.rad * s, c.hw * s, c.hh * s)
    }));
  }

  SV.Shapes = {
    DEFS,
    names: Object.keys(DEFS),
    height: (name, s) => height(DEFS[name]) * (s == null ? 1 : s),
    width: (name, s) => DEFS[name].bw * 2 * (s == null ? 1 : s),
    colliders
  };
})(typeof window !== 'undefined' ? window : globalThis);
