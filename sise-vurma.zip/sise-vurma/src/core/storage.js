/* localStorage sarmalayıcı. Depolama kapalıysa (gizli sekme vb.) bellekte çalışır. */
(function (root) {
  'use strict';
  const SV = (root.SV = root.SV || {});
  const PREFIX = 'sv.';
  const mem = {};

  function get(key, fallback) {
    try {
      const raw = root.localStorage.getItem(PREFIX + key);
      if (raw === null) return key in mem ? mem[key] : fallback;
      return JSON.parse(raw);
    } catch (e) {
      return key in mem ? mem[key] : fallback;
    }
  }
  function set(key, value) {
    mem[key] = value;
    try { root.localStorage.setItem(PREFIX + key, JSON.stringify(value)); } catch (e) { /* yoksay */ }
  }

  SV.Storage = { get, set };
})(typeof window !== 'undefined' ? window : globalThis);
