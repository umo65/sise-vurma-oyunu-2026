/*
 * OYUN DURUMU (DOM'dan bağımsız, saf mantık)
 * Puan, bölüm, top hakları ve hedef sırası burada yönetilir.
 *
 * Kurallar:
 *  - Bölüm 2 top hakkıyla başlar.
 *  - Doğru şişe vurulursa top hakkı HARCANMAZ, puan kazanılır ve sıradaki hedefe geçilir.
 *  - Yanlış şişe vurulursa ya da top hiçbir şişeye çarpmadan ıskalanırsa 1 top hakkı gider.
 *  - Top hakkı 0 olunca durum 'outOfBalls' olur (reklam / yeniden başlat penceresi).
 *  - Ödüllü reklam başarıyla bitince grantReward() ile 3 top verilir (tek seferlik).
 */
(function (root) {
  'use strict';
  const SV = (root.SV = root.SV || {});

  const BASE_BALLS = 2;
  const POINTS_CORRECT = 100;
  const POINTS_STREAK = 25;     // üst üste doğru vuruş başına ek puan (en çok 5 kat)
  const POINTS_BALL_BONUS = 50; // bölüm sonunda kalan her top için

  class GameState extends SV.Emitter {
    constructor(opts) {
      super();
      opts = opts || {};
      this.baseBalls = opts.baseBalls || BASE_BALLS;
      this.rewardBalls = opts.rewardBalls || 3;
      this.best = SV.Storage.get('best', 0) | 0;
      this.reset();
    }

    reset() {
      this.level = 1;
      this.score = 0;
      this.levelStartScore = 0;
      this.balls = this.baseBalls;
      this.maxBalls = this.baseBalls;
      this.streak = 0;
      this.mistakes = 0;
      this.targets = [];
      this.targetIndex = 0;
      this.status = 'menu'; // menu | playing | outOfBalls | levelComplete
      this.rewardAvailable = false;
    }

    /** Yeni bölümü başlatır. targets: hedef renk kimliklerinin sırası. */
    startLevel(level, targets) {
      this.level = level;
      this.levelStartScore = this.score;
      this.targets = targets.slice();
      this._resetLevelCounters();
      this.emit('change');
    }

    /** Aynı bölümü baştan başlatır: puan bölüm başındaki değere döner. */
    restartLevel() {
      this.score = this.levelStartScore;
      this._resetLevelCounters();
      this.emit('change');
    }

    _resetLevelCounters() {
      this.balls = this.baseBalls;
      this.maxBalls = this.baseBalls;
      this.streak = 0;
      this.mistakes = 0;
      this.targetIndex = 0;
      this.rewardAvailable = false;
      this.status = 'playing';
    }

    get target() { return this.targets[this.targetIndex] || null; }
    get levelEarned() { return this.score - this.levelStartScore; }
    get stars() { return this.mistakes === 0 ? 3 : this.mistakes === 1 ? 2 : 1; }

    /** Doğru şişe vuruldu. */
    registerCorrect() {
      if (this.status !== 'playing') return null;
      const points = POINTS_CORRECT + Math.min(this.streak, 5) * POINTS_STREAK;
      this.streak++;
      this.score += points;
      this.targetIndex++;
      let bonus = 0;
      const complete = this.targetIndex >= this.targets.length;
      if (complete) {
        bonus = this.balls * POINTS_BALL_BONUS;
        this.score += bonus;
        this.status = 'levelComplete';
        this._saveBest();
        SV.Storage.set('level', this.level + 1);
        SV.Storage.set('score', this.score);
      }
      this.emit('change');
      return { points, bonus, complete, streak: this.streak };
    }

    /** Yanlış şişe vuruldu ya da top ıskalandı. */
    registerWrong() {
      if (this.status !== 'playing') return null;
      this.balls = Math.max(0, this.balls - 1);
      this.streak = 0;
      this.mistakes++;
      const outOfBalls = this.balls === 0;
      if (outOfBalls) {
        this.status = 'outOfBalls';
        this.rewardAvailable = true;
        this._saveBest();
      }
      this.emit('change');
      return { balls: this.balls, outOfBalls };
    }

    /** Ödüllü reklam başarıyla tamamlandı: ekstra top ver (yalnızca bir kez). */
    grantReward() {
      if (this.status !== 'outOfBalls' || !this.rewardAvailable) return false;
      this.rewardAvailable = false;
      this.balls = this.rewardBalls;
      this.maxBalls = Math.max(this.baseBalls, this.rewardBalls);
      this.status = 'playing';
      this.emit('change');
      return true;
    }

    _saveBest() {
      if (this.score > this.best) {
        this.best = this.score;
        SV.Storage.set('best', this.best);
      }
    }
  }

  GameState.BASE_BALLS = BASE_BALLS;
  SV.GameState = GameState;
})(typeof window !== 'undefined' ? window : globalThis);
